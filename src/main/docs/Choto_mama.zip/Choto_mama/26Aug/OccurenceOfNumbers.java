public class OccurenceOfNumbers
{
	public static void main (String [] args)
	{
		String number = "";
		
		if (args.length != 1)
		{
			System.out.println ("You must enter only one argument.");
			System.exit (0);
		}
		
		number = args [0];
		String [] splitString = number.split (",");
		
		int [] intArray = new int [splitString.length];
		int loopCounter = 0, loopCounter1 = 0, counter = 0;
		
		for (loopCounter = 0; loopCounter < splitString.length; loopCounter++)
		{
			intArray [loopCounter] = Integer.parseInt(splitString[loopCounter]);
		}
		
		for (loopCounter1 = 0; loopCounter1 < intArray.length; loopCounter1++)
		{
			int searchNumber = intArray [loopCounter1];
			
			counter = searchNumberOccurence (intArray, searchNumber);
		
			System.out.println (searchNumber + " " + counter);
		}
	}
	
	public static int searchNumberOccurence (int [] intArray, int searchNumber)
	{
		int loopCounter = 0, counter = 0;
		
		for (loopCounter = 0; loopCounter < intArray.length; loopCounter++)
		{
			if (intArray [loopCounter] == searchNumber)
			{  
				counter++;
			}				
		}
		
		return counter;
	}
}