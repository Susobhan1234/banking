import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;

public class TotalMarks
{
	public static void main (String [] args)
	{
		try
		{
			File fileObject = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Aug25\\FileExample.txt");
			FileReader readerObject = new FileReader (fileObject);
			BufferedReader bufferObject = new BufferedReader (readerObject);
			
			String lineText = "";
			String [] name = new String [2];
			int [] marks = new int [2];
			int counter = 0;
			
			while ((lineText = bufferObject.readLine ()) != null)
			{
				System.out.println (lineText);
				
				String nameInLine = lineText.substring (0, 16);
				int marksInLine = Integer.parseInt (lineText.substring (23, 25));
				
				int returnValue = searchString (nameInLine, name);
				
				if (returnValue != -1)
				{
					marks [returnValue] = marks [returnValue] + marksInLine;	
				}
				else
				{
					name [counter] = nameInLine;
		
					//System.out.println (name[counter]);
					
					marks [counter] = marksInLine;
					
					//System.out.println (marks[counter]);
					
					counter++;
				}
			}
			
			for (counter = 0; counter < name.length; counter++)
			{
				System.out.println (name[counter] + " " + marks [counter]);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
	}
	
	public static int searchString (String searchText, String [] searchArray)
	{
		int loopCounter;
		
		for (loopCounter = 0; loopCounter < searchArray.length; loopCounter++)
		{
			if (searchText.equals(searchArray[loopCounter]))
			{
				return loopCounter;
			}
		}
		
		return - 1;
	}
}