public class Argument
{
	public static void main (String [] args)
	{
		if (args.length == 0) // Validation block
		{
			System.out.println("You must provide a parameter when executing the program");
			System.exit (0);
		}
		
		String parameter = args[0];
		System.out.println("Parameter passed = " + parameter );
		
		// Display the length of the value passed in command line argument
		
		int parameterLength = parameter.length(); 
		System.out.println("Parameter length = " + parameterLength); 
		
		// Convert command line argument to uppercase 
		
		String uppercaseValue = parameter.toUpperCase();
		System.out.println("Uppercase value = " + uppercaseValue);
		
		// Convert command line argument to lowercase
		
		String lowerCaseValue = parameter.toLowerCase();
		System.out.println("Lowercase value = " + lowerCaseValue);
		
		// Checking the input value that matching with Computer

		if (parameter.equals ("Computer") )
		{
			System.out.println("You passed Computer as a parameter.");
		}
		else
		{
			System.out.println("You did not pass Computer.");
		}
		
		// Displaying " using escape character
		
		System.out.println("I don't know\"");
	}
}