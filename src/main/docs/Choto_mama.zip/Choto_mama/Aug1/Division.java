public class Division
{
	public static void main (String [] args)
	{
		int num1 = 28, num2 = 5;
		double value;
		if ( num2 == 0)
		{
			System.out.println("Denominator can not be zero");
		}
		else
		{
			value = div (num1, num2);
			System.out.println("Division of " + num1 + " and " + num2 + " is = "  + value);
		}
	}

	public static double div (double number1, double number2)
	{
		double result;
		result = number1 / number2;
		
		return result;
	}
}