public class Multiplication
{
	public static void main (String [] args)
	{
		System.out.println("First parameter = " + args [0] );
		System.out.println("Second parameter = " + args [1] );
		int num1 = 15, num2 = 8, value;
		value = multiply (num1, num2);
		System.out.println("Multiplication of " + num1 + " and " + num2 + " is = " + value);
	}
	
	public static int multiply (int number1, int number2)
	{
		int value;
		value = number1 * number2;
		return value;
	}
}