public class Subtraction
{
	public static void main (String [] args)
	{
		int num1 = 12, num2 = 3, sub;
		sub = doSubtraction ( num1, num2);
		System.out.println ("Subtraction of " + num1 + " and " + num2 + " = " + sub);
	}
	
	public static int doSubtraction ( int number1, int number2 )
	{
		int doSubtraction;
		doSubtraction = number1 - number2;
		return doSubtraction;
	}
}