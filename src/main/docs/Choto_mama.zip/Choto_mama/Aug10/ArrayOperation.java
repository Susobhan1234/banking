public class ArrayOperation
{
	public static void main (String [] args)
	{
		int [] firstArray = new int [5];
		int [] secondArray = new int [5];
		int [] thirdArray = new int [5];
		int loopCounter;
		
		firstArray [0] = 100;
		firstArray [1] = 200;
		firstArray [2] = 300;
		firstArray [3] = 400;
		firstArray [4] = 500;
		secondArray [0] = 10;
		secondArray [1] = 20;
		secondArray [2] = 30;
		secondArray [3] = 40;
		secondArray [4] = 50;
		
		for (loopCounter = 0; loopCounter < thirdArray.length; loopCounter++)
		{
			thirdArray [loopCounter] = firstArray [loopCounter] + secondArray [loopCounter];
			System.out.println (thirdArray [loopCounter]);
		}
	}
}