public class FactorialOfArgument
{
	public static void main (String [] args)
	{
		try
		{
			String number = args [0]; 
			int intNumber = Integer.parseInt(number);
		
			int loopCounter;
			double factValue = 1;
			
			for	(loopCounter = 1; loopCounter <= intNumber; loopCounter++)
			{
				factValue = factValue * loopCounter;
			}
			
			System.out.println ("The factorial of " + intNumber + " is = " + factValue);
		}
		catch (Exception ex)
		{
			System.out.println ("You didn't enter an integer");
		}
	}
}