public class FactorialPractice
{
	public static void main (String [] args)
	{
		try
		{
			// System.out.println (args.length); --> For checking the length of the argumet passing.
			
			if (args.length == 1)	
			{
				String number = args [0];
				int intNumber = Integer.parseInt(number);
				
				if (intNumber < 0)
				{
					System.out.println ("ERROR");
				}
				else
				{
					int loopCounter;
					int factorial = 1;
					
					for (loopCounter = 1; loopCounter <= intNumber; loopCounter++)
					{
						factorial = factorial * loopCounter;
					}
					
					System.out.println (factorial);
				}
			}
			else
			{
				System.out.println ("ERROR");
			}
		}
		catch (Exception ex)
		{
			System.out.println ("ERROR");
		}
	}
}