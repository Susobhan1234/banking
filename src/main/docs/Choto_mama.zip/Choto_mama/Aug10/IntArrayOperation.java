public class IntArrayOperation
{
	public static void main (String [] args)
	{
		int [] firstArray = new int [10];
		int [] secondArray = new int [2];
		int loopCounter;
		
		firstArray [0] = 100;
		firstArray [1] = 200;
		firstArray [2] = 300;
		firstArray [3] = 400;
		firstArray [4] = 500;
		firstArray [5] = 600;
		firstArray [6] = 700;
		firstArray [7] = 800;
		firstArray [8] = 900;
		firstArray [9] = 70;
		
		secondArray [0] = 200;
		secondArray [1] = 300;
		
		boolean isSubset = true;
		
		for (loopCounter = 0; loopCounter < secondArray.length; loopCounter++)
		{
			boolean returnCode;
			returnCode = searchOperation(firstArray, secondArray[loopCounter]);
			
			if (returnCode == false)
			{
				System.out.println ("The second array not a subset of first array.");
				isSubset = false;
			}
		}
		
		if (isSubset == true)
		{
			System.out.println ("Second array is a subset of first array");
		}
	}
	
	//Searching an integer number called searchNumber inside an in
	
	public static boolean searchOperation (int [] intArray, int searchNumber)
	{
		int loopCounter;
		
		for (loopCounter = 0; loopCounter < intArray.length; loopCounter++)
		{
			if (intArray[loopCounter] == searchNumber)
			{
				return true;
			}
		}
		
		return false;
	}
}