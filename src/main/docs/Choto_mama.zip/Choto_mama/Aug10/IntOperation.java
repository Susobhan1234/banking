public class IntOperation
{
	public static void main (String [] args)
	{
		String firstArg = args [0];
		int firstArgInt = Integer.parseInt (firstArg);
		System.out.println ("After converting the command line arguments into a integer value is : " + firstArgInt);
		
		int [] intArray = new int [5];
		int loopCounter;
		
		intArray [0] = 100;
		intArray [1] = 200;
		intArray [2] = 300;
		intArray [3] = 400;
		intArray [4] = 500;
		
		for (loopCounter = 0; loopCounter < intArray.length; loopCounter++)
		{
			System.out.println ("Value of the array is : " + intArray [loopCounter]);
		}
		
		SearchingOperation searchObj = new SearchingOperation();
		searchObj.searchElement (intArray, firstArgInt);
	}
}