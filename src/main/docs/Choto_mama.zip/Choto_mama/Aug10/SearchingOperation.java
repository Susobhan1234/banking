public class SearchingOperation
{
	public static void searchElement (int [] intArray, int firstArgInt)
	{
		int loopCounter;
		for (loopCounter = 0; loopCounter < intArray.length; loopCounter++)
		{
			if (intArray [loopCounter] == firstArgInt)
			{
				System.out.println ("The entered argument " + firstArgInt + " is found in the array index = " + loopCounter);
			}
		}
	}
}