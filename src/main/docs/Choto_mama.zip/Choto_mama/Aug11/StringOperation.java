public class StringOperation
{
	public static void main (String [] cmd)
	{
		if ((cmd.length == 0) || (cmd.length > 1))
		{
			System.out.println ("Error");
			System.exit (1);
		}
		
		String firstString = cmd [0];
		String [] splitData;
		splitData = firstString.split("-"); // For split "-" here
		int loopCounter;
		
		for (loopCounter = 0; loopCounter < splitData.length; loopCounter++)
		{
			System.out.println (splitData[loopCounter]);
		}
		
		int year = Integer.parseInt(splitData [0]);
		
		if ((year % 4 == 0) && (year % 100 == 0) && (year % 400 == 0))
		{
			System.out.println ("Leap Year");
		}
		else
		{
			System.out.println ("Not Leap Year");
		}
		
		String upperCase, lowerCase;
		System.out.println ("First argument is : " + firstString);
		
		upperCase = firstString.toUpperCase();
		System.out.println ("First argument in uppercase : " + upperCase);
		
		lowerCase = upperCase.toLowerCase();
		System.out.println ("First argument in lower case : " + lowerCase);
	}
}
