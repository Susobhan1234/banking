public class MathOperation
{
	public static void addition (String firstValue, String secondValue)
	{
		int firstNumber, secondNumber, addValue;
		
		firstNumber = Integer.parseInt (firstValue);
		
		try
		{
			secondNumber = Integer.parseInt (secondValue);
		}
		catch (Exception e)
		{
			secondNumber = 0;
		}
		
		addValue = firstNumber + secondNumber;
		System.out.println("After adding the two value result is = " + addValue);
	}
}