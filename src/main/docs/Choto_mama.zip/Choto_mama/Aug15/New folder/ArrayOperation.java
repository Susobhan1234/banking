public class ArrayOperation
{
	public static void main (String [] args)
	{
		int [] firstArray = new int [5];
		int [] secondArray = new int [5];
		int [] addArray = new int [5];
		
		firstArray [0] = 5;
		firstArray [1] = 6;
		firstArray [2] = 7;
		firstArray [3] = 8;
		firstArray [4] = 9;
		
		secondArray [0] = 50;
		secondArray [1] = 60;
		secondArray [2] = 70;
		secondArray [3] = 80;
		secondArray [4] = 90;
		
		addOperation (firstArray, secondArray, addArray);
	}
	
	public static void addOperation (int [] firstArray, int [] secondArray, int [] addArray)
	{
		int loopCounter;
		
		for (loopCounter = 0; loopCounter < addArray.length; loopCounter++)
		{
			addArray [loopCounter] = firstArray  [loopCounter] + secondArray [loopCounter];
			System.out.println (addArray [loopCounter]);
		}
	}
}