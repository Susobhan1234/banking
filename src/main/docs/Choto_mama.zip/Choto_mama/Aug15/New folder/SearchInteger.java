public class SearchInteger
{
	public static void main (String args[])
	{
		String searchArgument = args [0];
		System.out.println ("Entered argument is : " + searchArgument);
		int searchNumber = Integer.parseInt (searchArgument);
		
		int [] arrayList = new int [5];
		int loopCounter;
		boolean returnType = true;
		
		arrayList [0] = 10;
		arrayList [1] = 20;
		arrayList [2] = 30;
		arrayList [3] = 40;
		arrayList [4] = 50;
		
		for (loopCounter = 0; loopCounter < arrayList.length; loopCounter++)
		{
			System.out.println (arrayList [loopCounter]);
		}
		
		returnType = searchOperation (arrayList, searchNumber); // 
		
		if (returnType == true)
		{
			System.out.println ("The number found in this array.");
			System.exit (0);
		}
		else
		{
			System.out.println ("The number not found in this array.");
		}
	}
	
	public static boolean searchOperation (int [] allArray, int numberSearch)
	{
		int loopCounter;
		
		for (loopCounter = 0; loopCounter < allArray.length; loopCounter++)
		{			
			if (allArray [loopCounter] == numberSearch)
			{
				return true;
			}
		}
		
		return false;
	}
}