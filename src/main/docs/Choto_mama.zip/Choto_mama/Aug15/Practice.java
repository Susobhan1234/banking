public class Practice
{
	public static void main (String [] args)
	{
		String firstValue = "";
		String secondValue = "";
		
		try
		{
			if (args.length != 2)
			{
				System.out.println("Error");
				System.exit(0);
			}
			
			firstValue = args [0];
			secondValue = args [1];
			
			System.out.println("The first argument is = " + firstValue);
			System.out.println("The second argument is = " + secondValue);
			
			MathOperation addObject = new MathOperation ();
			addObject.addition (firstValue, secondValue);
		}
		catch (Exception ex)
		{
			System.out.println("Input argument is not an integer number.");
			int loopCounter;
			char [] firstCharValue = new char [10];
			char [] secondCharValue = new char [10];
			firstCharValue = firstValue.toCharArray ();
			secondCharValue = secondValue.toCharArray ();
			
			StringOperation stringObject = new StringOperation ();
			stringObject.reverseOperation (firstCharValue, secondCharValue); // Actual parameter
			stringObject.splitOperation (firstValue, secondValue);
		}
	}
}