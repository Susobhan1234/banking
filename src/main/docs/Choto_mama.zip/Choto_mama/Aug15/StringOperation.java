public class StringOperation
{
	public static void splitOperation (String firstArrayValue, String secondArrayValue)
	{
		int loopCounter;
		String [] firstSplitData;
		firstSplitData = firstArrayValue.split("A");
			
		for (loopCounter = 0; loopCounter < firstSplitData.length; loopCounter++)
		{
			System.out.println(firstSplitData [loopCounter]);
		}
		
		String [] secondSplitData;
		secondSplitData = secondArrayValue.split("54");
		
		for (loopCounter = 0; loopCounter < secondSplitData.length; loopCounter++)
		{
			System.out.println(secondSplitData [loopCounter]);
		}
	}
	
	public static void reverseOperation (char [] firstCharArray, char [] secondCharArray) // Formal parameter
	{
		int loopCounter;
		
		for (loopCounter = firstCharArray.length - 1; loopCounter >= 0; loopCounter--)
		{
			System.out.print(firstCharArray[loopCounter]);
		}
			
		System.out.println("");
			
		for (loopCounter = secondCharArray.length - 1; loopCounter >= 0; loopCounter--)
		{
			System.out.print(secondCharArray[loopCounter]);
		}
	}
}