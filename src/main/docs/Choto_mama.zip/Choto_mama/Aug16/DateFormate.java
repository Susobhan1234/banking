public class DateFormate
{
	public static void main (String [] args)
	{
		String date = ""; //
		
		try
		{	
			date = args [0];
			
			System.out.println ("You have enter : " + date);
			
			validateDate (date); // calling method
			
			String [] split;
			int loopCounter;
			
			split = date.split ("/");
			
			for (loopCounter = 0; loopCounter < split.length; loopCounter++)
			{
				System.out.println("After split it value is : " + split [loopCounter]);
			}
		
			int intSplit = Integer.parseInt (split [0]);
			
			if ((intSplit % 4 == 0) && (intSplit % 100 == 0) && (intSplit % 400 == 0))
			{
				System.out.println ("The year is a leap year");
				System.exit (0);
			}
			
			System.out.println ("The year is not a leap year");
		}
		catch (Exception ex)
		{
			System.out.println ("You must enter year as a number");
			ex.printStackTrace ();
		}
	}
	
	public static void validateDate (String date)
	{
		
		// 2020/12

		String [] stringArray;
		stringArray = date.split ("/");
		
		if (stringArray.length != 3)
		{
			System.out.println ("You did not enter date in right format");
			System.exit (0);
		}
		
		// 12/2000/15	
		
		if (stringArray [0].length () != 4) // Length method should be used for string variable.
		{
			System.out.println ("You did not enter year in right format.");
			System.exit (0);
		}
		
		// 2000/13/25
		// 2000/11/35

		int intArray = Integer.parseInt (stringArray [1]);
				
		if ((intArray < 1) || (intArray > 12))
		{
			System.out.println ("You did not enter month in right format.");
			System.exit (0);
		}
		
		int intDate = Integer.parseInt (stringArray [2]);

		if ((intDate < 1) || (intDate > 31))
		{
			System.out.println ("You did not enter date in right format.");
			System.exit (0);
		}
	}
}