public class FactorialPractice
{
	public static void main (String [] args)
	{
		String number = "";
			
		if (args.length != 1)
		{
			System.out.println ("You must enter only one number");
			System.exit (0);
		}
		
		number = args [0];
			
		try
		{
			int integerNumber = Integer.parseInt(number);
			int loopCounter, fact = 1;
			
			if (integerNumber <= 0)
			{
				System.out.println ("Number can not be 0 or a negetive number");
				System.exit (0);
			}
			
			for (loopCounter = 1; loopCounter <= integerNumber; loopCounter++)
			{
				fact = fact * loopCounter;
			}
			
			System.out.println (fact);
		}
		catch (Exception ex)
		{
			System.out.println ("You must enter an integer number to calculate factorial");
			System.out.println ("However you have entered the value as " + number);
		}
	}
}