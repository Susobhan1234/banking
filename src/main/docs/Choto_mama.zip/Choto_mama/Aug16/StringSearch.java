public class StringSearch
{
	public static void main (String [] args)
	{
		String searchingString = "";
		
		if (args.length != 1)
		{
			System.out.println ("Enter only one string to search");
			System.exit (0);
		}
		
		searchingString = args [0];
		
		System.out.println ("The string which you wanted to search is : " + searchingString);
		
		String [] stringArray = new String [5];
		int loopCounter;
		
		stringArray [0] = "d";
		stringArray [1] = "e";
		stringArray [2] = "f";
		stringArray [3] = "g";
		stringArray [4] = "hello";
		
		for (loopCounter = 0; loopCounter < stringArray.length; loopCounter++)
		{
			System.out.println (stringArray [loopCounter]);
		}
		
		for (loopCounter = 0; loopCounter < stringArray.length; loopCounter++)
		{
			if (stringArray [loopCounter].equals (searchingString))
			{
				System.out.println ("The string " + searchingString + " found in this array");
				System.exit (0);
			}
		}
		
		System.out.println ("The string not found in this array");
	}
}