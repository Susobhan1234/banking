public class DateCompare
{
	public static void main (String [] args)
	{
		// The date should be in DD/MM/YYYY format.
		
		String firstDate = args [0];
		String secondDate = args [1];
		
		System.out.println ("Two dates are " + firstDate + " and " + secondDate);
		
		String [] firstSplit;
		firstSplit = firstDate.split ("/");
		String [] secondSplit;
		secondSplit = secondDate.split ("/");
		
		validate (firstSplit); // calling the validate method
		validate (secondSplit);
		
		int loopCounter;
		
		for (loopCounter = 0; loopCounter < firstSplit.length; loopCounter++)
		{
			System.out.println ("After split firstDate " + firstSplit [loopCounter]);
		}
		
		for (loopCounter = 0; loopCounter < secondSplit.length; loopCounter++)
		{
			System.out.println ("After split secondDate " + secondSplit [loopCounter]);
		}
		
		String firstDateYYYYMMDD = ( firstSplit [2] + firstSplit [1] + firstSplit [0]);
		int firstDateInt = Integer.parseInt (firstDateYYYYMMDD);
		
		String secondDateYYYYMMDD = ( secondSplit [2] + secondSplit [1] + secondSplit [0]);
		int secondDateInt = Integer.parseInt (secondDateYYYYMMDD);
		
		if (firstDateInt != secondDateInt)
		{
			if (firstDateInt > secondDateInt)
			{
				System.out.println ("First date is bigger.");
				System.exit (0);
			}
			
			System.out.println ("Second date is bigger.");
			System.exit(0);
		}
		
		System.out.println ("The two dates are same.");
	}
	
	public static void validate (String [] date)
	{
		// The date should be in DD/MM/YYYY format.
		
		if (date [2].length () != 4)
		{
			System.out.println ("You must enter year as four digits.");
			System.exit (0);
		}
						
		int intFirstDate = Integer.parseInt (date [0]);
				
		if ((intFirstDate < 1) || (intFirstDate > 31))
		{
			System.out.println ("Date should within 1 to 31");
			System.exit(0);
		}
						
		int intFirstMonth = Integer.parseInt (date [1]);
				
		if ((intFirstMonth < 1) || (intFirstMonth > 12))
		{
			System.out.println ("Month should within 1 to 12");
			System.exit(0);
		}	
	}
}