public class CheckDate
{
	public static void main (String [] args)
	{
		String date = args [0];
		
		System.out.println ("The date is : " + date);  // 22/03/2020
		
		String [] splitDate = date.split ("/"); // Split the date.
		
		String dateString = splitDate [0];
		String monthString = splitDate [1];
		String yearString = splitDate [2];
		int loopCounter;
		
		for (loopCounter = 0; loopCounter < splitDate.length; loopCounter++)
		{
			System.out.println (splitDate [loopCounter]);
		}
		
		isDateValid(yearString, monthString, dateString); 
	}
	
	public static void isDateValid (String yearString, String monthString, String dateString)
	{
		int month;
		
		month = Integer.parseInt (monthString);
		
		if ((month < 1) || (month > 12))
		{
			System.out.println ("You did not enter a valid month.");
			System.exit (0);
		}
		
		int intDate = Integer.parseInt (dateString);
		
		// jan, mar, may, jal, aug, oct, dec
		// 1, 3, 5, 7, 8, 10, 12
		
		if ((month == 1) || (month == 3) || (month == 5) || (month == 7) || (month == 8) || (month == 10) || (month == 12))
		{
			if ((intDate < 1) || (intDate > 31))
			{
				System.out.println ("You must enter date within 1 to 31.");
				//System.exit (0);
			}
		}
		
		// apr, jun, sep, nov
		// 4, 6, 9, 11
		
		else if ((month == 4) || (month == 6) || (month == 9) || (month == 11))
		{
			if ((intDate < 1) || (intDate > 30))
			{
				System.out.println ("You must enter date within 1 to 30.");
				//System.exit (0);
			}
		}
		
		else if (month == 2)
		{
			int year = Integer.parseInt (yearString);
			
			if ((year % 4 == 0) && (year % 100 == 0) && (year % 400 == 0))
			{
				if ((intDate < 1) || (intDate > 29))
				{
					System.out.println ("You must enter date within 1 to 29.");
				}
			}
			else
			{
				if ((intDate < 1) || (intDate > 28))
				{
					System.out.println ("You must enter date within 1 to 28.");
				}
			}
		}
	}
}