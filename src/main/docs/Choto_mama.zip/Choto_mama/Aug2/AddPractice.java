public class AddPractice
{
	public static void main( String [] args)
	{
		int num1 =91, num2 = 549, value;
		value = addNumber (num1, num2);
		System.out.println ("Addition of " +num1 + " and " + num2 + " = " +value);
	}
	
	public static int addNumber( int number1, int number2 )
	{
		int addNumber;
		addNumber =number1 + number2;
		return addNumber;
	}
}