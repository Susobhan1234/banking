public class ArithmeticOperation
{
	public static int addNumber (int number1, int number2)
	{
		int addition;
		addition = number1 + number2;
		return addition;
	}
	
	public static int subNumber (int number1, int number2)
	{
		int subtract;
		subtract = number1 - number2;
		return subtract;
	}
	
	public static int multNumber (int number1, int number2)
	{
		int multi;
		multi = number1 * number2;
		return multi;
	}
	
	public static double divNumber (int number1, int number2)
	{
		double div;
		
		// Typecasting integer value to double
		
		div = (double) number1 / number2;
		return div;
	}
	
	// Define the same method addNumber but using dataType double.
	// This is an example of method overloading.
	// Means same method name but dataType are different.
	
	public static double addNumber (double number1, double number2)
	{
		double addition;
		addition = number1 + number2;
		return addition;
	}
	
	public static double subNumber (double number1, double number2)
	{
		double subtraction;
		subtraction = number1 - number2;
		return subtraction;
	}
	
	public static double multNumber (double number1, double number2)
	{
		double multiplication;
		multiplication = number1 * number2;
		return multiplication;
	}
	
	public static double divNumber (double number1, double number2)
	{
		double division;
		division = number1 / number2;
		return division;
	}
}