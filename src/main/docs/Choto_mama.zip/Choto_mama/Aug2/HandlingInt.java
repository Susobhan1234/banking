public class HandlingInt
{
	
	/* 
	Getting two input through command line and print them. 
	Next convert them to an integer. 
	Next I checked that the entered number odd or even. 
	Then I do addition, subtraction, multiplication and division of the entered number.
	Then I did typecasting an integer to double.
	I also created four seperate methods for addition, subtraction, multiplication and division.
	*/
	
	public static void main(String [] args)
	{
		// dataType variableName = Initial Value
		
		String firstInputData = args [0]; // How to capture command line argument in a variable.
		System.out.println("The first argument you entered : " + firstInputData);
		String secondInputData = args [1]; 
		System.out.println("The second argument you entered : " + secondInputData);
		
		// Converting a string to an integer
		
		int firstInputNumber = Integer.parseInt (firstInputData);
		System.out.println("After converting first InputNumber to an integer value will be : " + firstInputNumber);
		int secondInputNumber = Integer.parseInt (secondInputData);
		System.out.println("After converting second InputNumber to an integer value will be : " + secondInputNumber);
		
		// Converting input integer number to double
		
		double firstInputNumberDouble = (double) firstInputNumber;
		double secondInputNumberDouble = (double) secondInputNumber;
		
		checkingOddEven(firstInputNumber, secondInputNumber);
		
		performIntegerOperation(firstInputNumber, secondInputNumber);
		
		performDoubleOperation(firstInputNumber, secondInputNumber);
	}
	
	
	// Moving the code from main method to this method for integer operation
	
	public static void checkingOddEven (int firstInputNumber, int secondInputNumber)
	{
		// Checking the number you have entered odd or even number 
		
		if (firstInputNumber % 2 == 0)
		{
			System.out.println("The first entered number is a even number");
		}
		else
		{
			System.out.println("The first entered number is a odd number");
		}
		
		if (secondInputNumber % 2 == 0)
		{
			System.out.println("The second entered number is a even number");
		}
		else
		{
			System.out.println("The second entered number is a odd number");
		}
	}
	
	public static void performIntegerOperation (int firstInputNumber, int secondInputNumber)
	{
		addIntegerNumber (firstInputNumber, secondInputNumber);
		
		subIntegerNumber (firstInputNumber, secondInputNumber);
		
		multIntegerNumber (firstInputNumber, secondInputNumber);
		
		divIntegerNumber (firstInputNumber, secondInputNumber);
	}
	
	public static void performDoubleOperation (double firstInputNumberDouble, double secondInputNumberDouble)
	{
		// Now perform the arithmetic operation using the double variables.
		
		addDoubleNumber (firstInputNumberDouble, secondInputNumberDouble);
		subDoubleNumber (firstInputNumberDouble, secondInputNumberDouble);
		multDoubleNumber (firstInputNumberDouble, secondInputNumberDouble);
		divDoubleNumber (firstInputNumberDouble, secondInputNumberDouble);	
	}
	
	public static void addIntegerNumber( int firstInputNumber, int secondInputNumber)
	{
		int add;
		add = firstInputNumber + secondInputNumber;
		System.out.println("After adding two integer value will be = " + add);
		
		// Creating an object of class ArithmeticOperation
		
		ArithmeticOperation arithmetic = new ArithmeticOperation();
		add = arithmetic.addNumber(firstInputNumber, secondInputNumber);
		System.out.println("After calling addNumber value will be = " + add);
	}
	
	public static void subIntegerNumber( int firstInputNumber, int secondInputNumber)
	{
		int subtract;
		subtract = firstInputNumber - secondInputNumber;
		System.out.println("After subtract two integer value will be = " + subtract);
		
		// Creating an object of class ArithmeticOperation
		
		ArithmeticOperation arithmetic = new ArithmeticOperation();
		subtract = arithmetic.subNumber(firstInputNumber, secondInputNumber);
		System.out.println("After calling subNumber value will be = " + subtract);
	}
	
	public static void multIntegerNumber( int firstInputNumber, int secondInputNumber)
	{
		int multiplication;
		multiplication = firstInputNumber * secondInputNumber;
		System.out.println("After multiplication of two integer value will be = " + multiplication);
		
		// Creating an object of class ArithmeticOperation
		
		ArithmeticOperation arithmetic = new ArithmeticOperation();
		multiplication = arithmetic.multNumber(firstInputNumber, secondInputNumber);
		System.out.println("After calling multNumber value will be = " + multiplication);
	}
	
	public static void divIntegerNumber( int firstInputNumber, int secondInputNumber)
	{
		double division;
		
		// Typecasting integer value to double
		
		division = (double) firstInputNumber / secondInputNumber;
		System.out.println("After division of two integer value will be = " + division);
		
		// Creating an object of class ArithmeticOperation
		
		ArithmeticOperation arithmetic = new ArithmeticOperation();
		division = arithmetic.divNumber(firstInputNumber, secondInputNumber);
		System.out.println("After calling divNumber value will be = " + division);
	}
	
	public static void addDoubleNumber( double firstInputNumberDouble, double secondInputNumberDouble)
	{
		double addDouble;
		addDouble = firstInputNumberDouble + secondInputNumberDouble;
		System.out.println("After adding two double value will be = " + addDouble);
		
		// Creating an object of class ArithmeticOperation
		
		ArithmeticOperation arithmetic = new ArithmeticOperation();
		addDouble = arithmetic.addNumber(firstInputNumberDouble, secondInputNumberDouble);
		System.out.println("After calling addNumber for double value will be = " + addDouble);
	}
	
	public static void subDoubleNumber( double firstInputNumberDouble, double secondInputNumberDouble)
	{
		double subDouble;
		subDouble = firstInputNumberDouble - secondInputNumberDouble;
		System.out.println("After subtract two double value will be = " + subDouble);
		
		// Creating an object of class ArithmeticOperation
		
		ArithmeticOperation arithmetic = new ArithmeticOperation();
		subDouble = arithmetic.subNumber(firstInputNumberDouble, secondInputNumberDouble);
		System.out.println("After calling subNumber for double value will be = " + subDouble);
	}
	
	public static void multDoubleNumber( double firstInputNumberDouble, double secondInputNumberDouble)
	{
		double multDouble;
		multDouble = firstInputNumberDouble * secondInputNumberDouble;
		System.out.println("After multiplication of two double value will be = " + multDouble);
		
		// Creating an object of class ArithmeticOperation
		
		ArithmeticOperation arithmetic = new ArithmeticOperation();
		multDouble = arithmetic.multNumber(firstInputNumberDouble, secondInputNumberDouble);
		System.out.println("After calling multNumber for double value will be = " + multDouble);
	}
	
	public static void divDoubleNumber( double firstInputNumberDouble, double secondInputNumberDouble)
	{
		double divDouble;
		divDouble = firstInputNumberDouble / secondInputNumberDouble;
		System.out.println("After division of two double value will be = " + divDouble);
		
		// Creating an object of class ArithmeticOperation
		
		ArithmeticOperation arithmetic = new ArithmeticOperation();
		divDouble = arithmetic.divNumber(firstInputNumberDouble, secondInputNumberDouble);
		System.out.println("After calling divNumber for double value will be = " + divDouble);
	}
}