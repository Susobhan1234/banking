public class Practice
{
	public static void main (String [] args)
	{
		String inputNumber = args [0];
		System.out.println("The argument you passed through command line is = " + inputNumber);
	}
}