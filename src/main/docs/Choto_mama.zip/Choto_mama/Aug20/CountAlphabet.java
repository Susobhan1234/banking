public class CountAlphabet
{
	public static void main (String [] args)
	{
		String word = args [0];
		System.out.println ("You entered : " + word);
		
		char [] wordCharArray = word.toCharArray (); // Converting String to a char array
		
		int loopCounter, loopCounter2, counter = 0;
		
		for (loopCounter = 0; loopCounter < wordCharArray.length; loopCounter++)
		{
			System.out.println (wordCharArray[loopCounter]);
		}
		
		for (loopCounter = 0; loopCounter < wordCharArray.length; loopCounter++)
		{
			counter = 0; 
			
			for (loopCounter2 = 0; loopCounter2 < wordCharArray.length; loopCounter2++)
			{
				if (wordCharArray [loopCounter] == wordCharArray [loopCounter2])
				{
					counter++;
				}
			}
			
			System.out.println (wordCharArray[loopCounter] + " " + counter);
		}
	}
}
