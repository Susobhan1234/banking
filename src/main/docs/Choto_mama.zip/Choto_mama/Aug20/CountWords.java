public class CountWords
{
	public static void main (String [] args)
	{
		String sentence = "";
		
		if (args.length != 1)
		{
			System.out.println ("You must enter only one argument");
			System.exit(0);
		}
		
		sentence = args [0];
		
		System.out.println ("You entered :" + sentence);
		
		String [] splitSentence = sentence.split (" ");
		
		int countWord = splitSentence.length;
		
		System.out.println ("Number of word in the sentence is : " + countWord);
		
		int loopcounter;
		
		for (loopcounter = splitSentence.length -1; loopcounter >= 0; loopcounter--)	
		{
			System.out.println ("After reverse the sentence : " + splitSentence[loopcounter]);
		}
	}
}