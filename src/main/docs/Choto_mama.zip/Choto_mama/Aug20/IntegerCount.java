/*Input:
{1, 1, 2, 2, 3, 4, 4, 5, 5, 5}
Output:
3*/

public class IntegerCount
{
	public static void main (String [] args)
	{
		String number = args [0];
		System.out.println ("You entered : " + number);
		
		String [] splitNumber = number.split (",");
		
		int loopCounter, loopCounter1, loopCounter2,count = 0;
		
		int [] intSplitNumber = new int [splitNumber.length]; // converting String array to int array
		
		for (loopCounter = 0; loopCounter < splitNumber.length; loopCounter++)
		{
			intSplitNumber [loopCounter] = Integer.parseInt (splitNumber [loopCounter]);
		}
		
		for (loopCounter1 = 0; loopCounter1 < intSplitNumber.length; loopCounter1++)
		{
			count = 0;
			
			for (loopCounter2 = 0; loopCounter2 < intSplitNumber.length; loopCounter2++)
			{
				if (intSplitNumber [loopCounter1] == intSplitNumber [loopCounter2])
				{
					count++;
				}
			}
			
			if ( count == 1)
			{
				System.out.println (intSplitNumber [loopCounter1]);
			}
		}
	}
}