public class IntegerToWord
{
	public static void main (String [] args)
	{
		String number = "";
		
		if (args.length != 1)
		{
			System.out.println ("You must enter only one argument");
			System.exit(0);
		}
		
		number = args [0];
		int loopCounter;
		
		char charNumber [] = number.toCharArray ();
		
		System.out.println ("You entered : " + number);
		
		for (loopCounter = 0; loopCounter < charNumber.length; loopCounter++)
		{
			if (charNumber [loopCounter] == '0')
			{
				System.out.print ("ZERO ");
			}
			else if (charNumber [loopCounter] == '1')
			{
				System.out.print ("ONE ");
			}
			else if (charNumber [loopCounter] == '2')
			{
				System.out.print ("TWO ");
			}
			else if (charNumber [loopCounter] == '3')
			{
				System.out.print ("THREE ");
			}
			else if (charNumber [loopCounter] == '4')
			{
				System.out.print ("FOUR ");
			}
			else if (charNumber [loopCounter] == '5')
			{
				System.out.print ("FIVE ");
			}
			else if (charNumber [loopCounter] == '6')
			{
				System.out.print ("SIX ");
			}
			else if (charNumber [loopCounter] == '7')
			{
				System.out.print ("SEVEN ");
			}
			else if (charNumber [loopCounter] == '8')
			{
				System.out.print ("EIGHT ");
			}
			else if (charNumber [loopCounter] == '9')
			{
				System.out.print ("NINE ");
			}
		}
	}
}