// Create two int array each length 5
// Assign Some number into both the array.
// Add them through index value and store it a new array

public class AddInt
{
	public static void main (String [] args)
	{
		int [] firstArray = new int [5];
		int [] secondArray = new int [8];
		int [] thirdArray = new int [13];
		int loopCounter =  0, loopCounter2 = 0;
		
		firstArray [0] = 5;
		firstArray [1] = 6;
		firstArray [2] = 7;
		firstArray [3] = 8; 
		firstArray [4] = 9;
		
		secondArray [0] = 100;
		secondArray [1] = 200;
		secondArray [2] = 300;
		secondArray [3] = 400;
		secondArray [4] = 500;
		secondArray [5] = 600;
		secondArray [6] = 700;
		secondArray [7] = 800;
		
		for (loopCounter = 0; loopCounter < firstArray.length; loopCounter++)
		{
			thirdArray [loopCounter] = firstArray [loopCounter];
		}
		
		for (loopCounter2 = 0; loopCounter2 < secondArray.length; loopCounter2++)
		{
			thirdArray [loopCounter] = secondArray [loopCounter2]; 
			loopCounter++;
		}
		
		for (loopCounter = 0; loopCounter < thirdArray.length; loopCounter++)
		{
			System.out.println (thirdArray [loopCounter]); 
		}
	}
}