public class CharToInt
{
	public static void main (String [] args)
	{
		// ASCII (American Standard Code for Information Interchange) value
		
		convertCharToInt ('a');
		convertCharToInt ('A');
		convertCharToInt ('=');
		convertCharToInt (';');
		
		convertIntToChar (97);
		convertIntToChar (65);
		convertIntToChar (100);
	}
	
	public static void convertCharToInt (char charValue)
	{
		int intValue;
		
		intValue = charValue;
		
		System.out.println (charValue + "=" + intValue);
	}
	
	public static void convertIntToChar (int intValue)
	{
		char charValue;
		
		charValue = (char) intValue;
		
		System.out.println (intValue + " = " + charValue);
	}
}