// dd/mm/yyyy

public class CheckValidDate
{
	public static void main (String [] args)
	{
		String inputDate = args [0];
		
		System.out.println ("You entered : " + inputDate);
		
		String [] splitDate = inputDate.split ("/");
		
		String date = splitDate [0];
		String month = splitDate [1];
		String year = splitDate [2];
		
		int intMonth = Integer.parseInt (month);
		
		if ((intMonth < 1) || (intMonth > 12))
		{
			System.out.println ("Month should within 1 to 12");
			System.exit (0);
		}
		
		int intDate = Integer.parseInt (date);
		
		// 1,3,5,7,8,10,12
		
		if ((intMonth == 1) || (intMonth == 3) || (intMonth == 5) || (intMonth == 7) || (intMonth == 8) || (intMonth == 10) || (intMonth == 12))
		{
			if ((intDate < 1) || (intDate > 31))
			{
				System.out.println ("Date should within 1 to 31");
			}
		}
		
		// 4,6,9,11
		
		else if ((intMonth == 4) || (intMonth == 6) || (intMonth == 9) || (intMonth == 11))
		{
			if ((intDate < 1) || (intDate > 30))
			{
				System.out.println ("Date should within 1 to 30");
			}
		}
		
		if (intMonth == 2)
		{
			int intYear = Integer.parseInt(year);
			
			if ((intYear % 4 == 0) && (intYear % 100 == 0) && (intYear % 400 == 0))
			{
				if ((intDate < 1) || (intDate > 29))
				{
					System.out.println ("Date should within 1 to 29");
				}
			}
			else
			{
				if ((intDate < 1) || (intDate > 28))
				{
					System.out.println ("Date should within 1 to 28");
				}
			}
		}
	}
}