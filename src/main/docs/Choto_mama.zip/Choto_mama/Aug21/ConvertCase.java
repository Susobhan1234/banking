public class ConvertCase
{
	public static void main (String [] args)
	{
		String name = "";
		
		if (args.length != 1)
		{
			System.out.println ("You must enter only one argument.");
			System.exit (0);
		}
		
		name = args [0];
		
		char [] charArray = name.toCharArray();
		
		int loopCounter;
		
		for (loopCounter = 0; loopCounter < charArray.length; loopCounter++)
		{
			char charValue = charArray [loopCounter];
			int intValue = (int) charValue;
			
			if ((intValue >= 65) && (intValue <= 90))
			{
				String stringValue = "" + charValue; // Converting char to string.
				String stringLowerCase = stringValue.toLowerCase(); // Converting Uppercase to lower case.
				
				System.out.print (stringLowerCase);
			}
			else if ((intValue >= 97) && (intValue <= 122))
			{
				String stringValue = "" + charValue; // Converting char to string.
				String stringUpperCase = stringValue.toUpperCase(); // Converting Uppercase to lower case.
				
				System.out.print (stringUpperCase);
			}
		}
	}
}