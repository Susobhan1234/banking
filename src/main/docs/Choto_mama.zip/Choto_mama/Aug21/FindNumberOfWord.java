public class FindNumberOfWord
{
	public static void main (String [] args)
	{
		String sentence = "";
		
		if (args.length != 1)
		{
			System.out.println ("You must pass one argument");
			System.exit (0);
		}
		
		sentence = args [0];
		System.out.println ("You entered : " + sentence);
		
		String [] splitSentence = sentence.split (" ");
		int wordCount = splitSentence.length;
		System.out.println (wordCount);
	}
}