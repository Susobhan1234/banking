/*
Input: Super Man Bat Man Spider Man
Output: Man: 3
*/
public class NumberOfOccurrence
{
	public static void main (String [] args)
	{
		String sentence = "";
		
		if (args.length != 1)
		{
			System.out.println ("You must enter only one argument.");
			System.exit (0);
		}
		
		sentence = args [0];
		
		System.out.println ("You entered : " + sentence);
		
		int loopCounter = 0, loopCounter1 = 0, count = 0;
		
		String [] splitSentence = sentence.split (" ");
		
		for (loopCounter = 0; loopCounter < splitSentence.length; loopCounter++)
		{
			count = 0;
			
			for (loopCounter1 = 0; loopCounter1 < splitSentence.length; loopCounter1++)
			{
				if (splitSentence[loopCounter].equals (splitSentence[loopCounter1]))
				{
					count++;
				}
			}
			
			System.out.println (splitSentence[loopCounter] + ":" + count);
		}
	}
}