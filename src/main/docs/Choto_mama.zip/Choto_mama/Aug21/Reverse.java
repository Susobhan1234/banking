/*
Input: Computer Science
Output: ecneicS retupmoC
*/
public class Reverse
{
	public static void main (String [] args)
	{
		String firstString = "";
		
		if (args.length != 1)
		{
			System.out.println("You must enter only one argument.");
			System.exit (0);  
		}
		
		firstString = args [0];
		int loopCounter = 0;
		
		char [] charFirstString = firstString.toCharArray ();
		
		for (loopCounter = charFirstString.length - 1; loopCounter >= 0; loopCounter--)
			
		{
			System.out.print(charFirstString [loopCounter]);
		}
	}
}