/*firstInput--1,2,3,4,5,6
secondInput--5*/

public class NumberSearch
{
	public static void main (String [] args)
	{
		String firstString = "";
		String secondString = "";
		
		if (args.length != 2)
		{
			System.out.println ("You must enter only two strings.");
			System.exit (0);
		}
		
		firstString = args [0];
		secondString = args [1];
		
		String [] splitFirstString = firstString.split (",");
		
		int [] intArray = new int [splitFirstString.length]; 
		
		int loopCounter = 0;
		
		for (loopCounter = 0; loopCounter < splitFirstString.length; loopCounter++)
		{
			intArray[loopCounter] = Integer.parseInt (splitFirstString[loopCounter]);
		}
		
		int searchedNumber = 0;
		
		try
		{
			searchedNumber = Integer.parseInt (secondString);
		}
		catch (Exception ex)
		{
			System.out.println ("Second number is not a valid number.");
			System.exit (0);
		}
		
		// Calling the search method //
		
		boolean returnValue = searchOperation (intArray, searchedNumber);
		
		if (returnValue == true)
		{
			System.out.println ("Number found in this array.");
			System.exit (0);
		}
		
		System.out.println ("Number not found in this array.");
	}
	
	// Search Method //
		
	public static boolean searchOperation (int [] intArray, int searchedNumber)   
	{
		int loopCounter = 0;
		
		for (loopCounter = 0; loopCounter < intArray.length; loopCounter++)
		{
			if (intArray [loopCounter] == searchedNumber)
			{
				return true;
			}
		}
	
		return false;
	}
}