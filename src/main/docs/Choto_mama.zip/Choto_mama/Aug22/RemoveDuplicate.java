// 2,5,5,7,1,8,2,7,10,11,5,3,2,1

// 2 5 7 1 8 10 11 3

public class RemoveDuplicate
{
	public static void main (String [] args)
	{
		String inputString = "";
		
		if (args.length != 1) // Check the length Of the entered argument
		{
			System.out.println ("You must enter only one string.");
			System.exit (0);
		}
		
		inputString = args [0];
		
		String [] splitInputString = inputString.split (","); // Split by ","
		
		int [] intInputArray = new int [splitInputString.length] ; // Converting into an int array
		
		int loopCounter = 0, loopCounter2 = 0, loopCounter3 = 0, loopCounter4 = 0;
		
		for (loopCounter = 0; loopCounter < splitInputString.length; loopCounter++)
		{
			intInputArray [loopCounter] = Integer.parseInt(splitInputString [loopCounter]); // For Converting StringArray to an IntegerArray
		}
		
		int [] newIntArray = new int [intInputArray.length];
		
		for (loopCounter2 = 0; loopCounter2 < intInputArray.length; loopCounter2++)
		{
			int returnValue = searchNumberInAnArray (intInputArray [loopCounter2], newIntArray);
			
			if (returnValue == 0)
			{
				newIntArray [loopCounter4] = intInputArray [loopCounter2];
				loopCounter4++;
			}
		}
		
		for (loopCounter3 = 0; loopCounter3 < loopCounter4; loopCounter3++)
		{
			System.out.println (newIntArray [loopCounter3]);
		}
	}
	
	public static int searchNumberInAnArray (int numberToSearch, int [] newIntArray)
	{
		int loopCounter = 0, numberFound = 0;
		
		// 2,5,5,7,1,8,2,7,10,11,5,3,2,1
		
		for (loopCounter = 0; loopCounter < newIntArray.length; loopCounter++)
		{
			if (newIntArray [loopCounter] == numberToSearch)
			{
				numberFound = 1;
				break;
			}
		}
		
		return numberFound;
	}
}