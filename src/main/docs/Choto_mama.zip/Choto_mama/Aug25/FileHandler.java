import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;

public class FileHandler
{
	
	public static void main (String [] args)
	{
		try
		{
			File fileObject = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Aug25\\FileExample.txt");
			FileReader readerObject = new FileReader (fileObject);
			BufferedReader bufferObject = new BufferedReader (readerObject);
			
			String lineString = "";
			
			while ((lineString = bufferObject.readLine ()) != null)
			{
				System.out.println (lineString);
				
				String mathNumber = "";
				mathNumber = lineString.substring (23, 25);
				System.out.println(mathNumber);					
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
	}
}
