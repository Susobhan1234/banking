import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;

public class FileProcessing
{
	public static void main (String [] arg)
	{
		try
		{
			File fileObject = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Data\\Numbers.txt"); // Full path of the fileObject
			FileReader readerObject = new FileReader (fileObject); // Opening the file 
			BufferedReader bufferObject = new BufferedReader (readerObject); // Getting ready to Read the file 
			
			String fileLine = "";
			
			while ((fileLine = bufferObject.readLine ()) != null)
			{
				System.out.println (fileLine);
				
				String [] splitFileLine = fileLine.split (",");
				int [] intFileLine = new int [splitFileLine.length];
				int loopCounter = 0, sum = 0;
				
				for (loopCounter = 0; loopCounter < splitFileLine.length; loopCounter++)
				{
					intFileLine [loopCounter] = Integer.parseInt(splitFileLine [loopCounter]);
					sum = sum + intFileLine[loopCounter];
				}
				
				System.out.println (sum);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
	}
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      