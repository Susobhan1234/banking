// SusobhanMasanta
// 012345678912345

public class SubstringExample
{
	public static void main (String [] args)
	{
		String name = "";
		
		if (args.length != 1)
		{
			System.out.println ("You must enter only one argument.");
			System.exit (0);
		}
		
		name = args [0];
		
		String partOfTheName = "";
		
		partOfTheName = name.substring (8, (name.length()) - 3); 
		
		System.out.println (partOfTheName);
	}
}