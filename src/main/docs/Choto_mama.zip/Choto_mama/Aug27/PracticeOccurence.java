public class PracticeOccurence
{
	public  static void main (String [] args)
	{
		String number = "";
		
		if (args.length  != 1)
		{
			System.out.println ("You must enter ");
			System.exit (0);
		}
		
		number = args [0];
		String [] splitNumber = number.split (",");
		int loopCounter = 0, loopCounter2 = 0, numberOfOccurence = 0;
		
		int [] numberArray = new int [splitNumber.length];
		
		for (loopCounter = 0; loopCounter < numberArray.length; loopCounter++)
		{
			numberArray[loopCounter] = Integer.parseInt (splitNumber[loopCounter]);
		}
		
		for (loopCounter2 = 0; loopCounter2 < numberArray.length; loopCounter2++)
		{
			int numberToSearch = numberArray [loopCounter2];
			
			numberOfOccurence = searchMethod (numberArray, numberToSearch);
			
			System.out.println (numberToSearch + " " + numberOfOccurence);
		}
	}
	
	public static int searchMethod (int [] searchArray, int searchNumber)
	{
		int counter = 0, loopCounter = 0;
		
		// 10 20 30 10 20
		
		for (loopCounter = 0; loopCounter < searchArray.length; loopCounter++)
		{
			if (searchArray[loopCounter] == searchNumber)
			{
				counter++;
			}
		}
		
		return counter;
	}
}