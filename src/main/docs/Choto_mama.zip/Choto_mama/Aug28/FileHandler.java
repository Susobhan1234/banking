import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;

public class FileHandler
{
	public static void main (String [] args)
	{
		try
		{
			File fileObject = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Aug28\\FileExample.txt");
			FileReader readerObject = new FileReader (fileObject);
			BufferedReader bufferObject = new BufferedReader (readerObject);
			
			String lineText = "";
			int sum = 0;
			int counter = 0, counter2 = 0, loopCounter = 0;
			String [] subjectArray = new String [5];
			String [] studentArray = new String [2];
			
			// Susobhan Masanta024    80Computer Science
            // Madhusudan Rana 142    99Computer Science
			
			while ((lineText = bufferObject.readLine ()) != null)  
			{
				// System.out.println (lineText);
				
				String marks = lineText.substring (23, 25);
				
				int intMarks = Integer.parseInt (marks);
				
				sum = sum + intMarks;
				
				String subjectName = lineText.substring (25, lineText.length ());
				
				// System.out.println (subjectName);
							
				boolean returnValue = searchStudentDetails(subjectArray, subjectName);
				
				if ( returnValue == false)
				{
					subjectArray [counter] = subjectName;
					
					counter++;
				}
				
				String studentName = lineText.substring (0, 16);
				
				// System.out.println (studentName);
				
				boolean returnValue2 = searchStudentDetails (studentArray, studentName);
				
				if (returnValue2 == false)
				{
					studentArray [counter2] = studentName;
					
					counter2++;
				}				
			}
			
			for (loopCounter = 0; loopCounter < studentArray.length; loopCounter++)
			{
				System.out.println (studentArray [loopCounter]);
				convertMixedCase (studentArray [loopCounter]);
				System.out.println ("");
			}
			
			for (loopCounter = 0; loopCounter < subjectArray.length; loopCounter++)
			{
				System.out.println (subjectArray [loopCounter]);
				convertMixedCase (subjectArray [loopCounter]);
				System.out.println ("");
			}
			
			System.out.println (sum);
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		} 
	}
	
	public static boolean searchStudentDetails (String [] studentDetails, String student)
	{
		int loopCounter = 0;
		
		for (loopCounter = 0; loopCounter < studentDetails.length; loopCounter++)
		{
			if (student.equals (studentDetails[loopCounter]))
			{
				
				return true;
			}
		}
		
		return false;
	}
	
	public static void convertMixedCase (String stringName)
	{
		char [] nameArray = stringName.toCharArray (); 
		int loopCounter = 0;
		
		for (loopCounter = 0; loopCounter < nameArray.length; loopCounter++)
		{
			char eachCharacter = nameArray [loopCounter];
			int intValue = eachCharacter; // Converting a character to an integer variable.
			
			if ((intValue >= 65) && (intValue <= 90))
			{
				String stringValue = "" + eachCharacter;
				String lowerCasevalue = stringValue.toLowerCase();
				
				System.out.print (lowerCasevalue);
			}
			
			else if ((intValue >= 97) && (intValue <= 122))
			{
				String stringValue = "" + eachCharacter;
				String upperCasevalue = stringValue.toUpperCase();
				
				System.out.print (upperCasevalue);
			}
		}
	}
}