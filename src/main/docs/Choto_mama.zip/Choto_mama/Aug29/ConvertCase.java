// First I take input through commad line.
// Next I checked that how many arguments I entered through command line and then initialize the argument;
// Next I convert the string to an character array. by using for loop go through e

public class ConvertCase
{
	public static void main (String [] args)
	{
		String name = "";
		
		if (args.length != 1)
		{
			System.out.println ("You must enter only one argument.");
			System.exit (0);
		}
		
		name = args [0];
		
		convertMixedCase(name);
	}
	
	public static void convertMixedCase (String stringName)
	{
		char [] nameArray = stringName.toCharArray (); 
		int loopCounter = 0;
		
		for (loopCounter = 0; loopCounter < nameArray.length; loopCounter++)
		{
			char eachCharacter = nameArray [loopCounter];
			int intValue = eachCharacter; // Converting a character to an integer variable.
			
			if ((intValue >= 65) && (intValue <= 90))
			{
				String stringValue = "" + eachCharacter;
				String lowerCasevalue = stringValue.toLowerCase();
				
				System.out.print (lowerCasevalue);
			}
			
			else if ((intValue >= 97) && (intValue <= 122))
			{
				String stringValue = "" + eachCharacter;
				String upperCasevalue = stringValue.toUpperCase();
				
				System.out.print (upperCasevalue);
			}
		}
	}
}