import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;

public class EatchStudentTotalMarks
{
	public static void main (String [] args)
	{
		try 
		{
			File fileObject = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Aug29\\FileExample.txt");
			FileReader readerObject = new FileReader (fileObject);
			BufferedReader bufferObject = new BufferedReader (readerObject);
			
			String lineReader = "";
			String [] nameArray = new String [2];
			int [] numberArray = new int [2];
			int addNumber = 0, counter = 0, loopCounter = 0;
			
			for (loopCounter = 0; loopCounter < nameArray.length; loopCounter++)
			{
				nameArray [loopCounter] = "";
				numberArray [loopCounter] = 0;
			}
			
			while ((lineReader = bufferObject.readLine ()) != null)
			{
				// System.out.println (lineReader);
				
				String name = lineReader.substring (0, 16);
				String number = lineReader.substring (23, 25);
				int intNumber = Integer.parseInt (number);
				
				int returnValue = searchOperation(nameArray, name);
								
				// Masanta 79
				// Rana 99
				// Masanta 80
				
				if ( returnValue != -1)
				{
					numberArray [returnValue] = numberArray [returnValue] + intNumber;
				}
				else 
				{
					nameArray [counter] = name;
					numberArray [counter] = intNumber;
					
					counter++;
				}
			}
			
			for (counter = 0; counter < nameArray.length; counter++)
			{
				System.out.println (nameArray[counter] + " " + numberArray [counter]);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
	}
	
	// name = Masanta
	// nameArray [0] = Masanta
	// nameArray [1]= Rana
	
	public static int searchOperation (String [] nameArray, String name)
	{
		int loopCounter = 0;
		
		for (loopCounter = 0; loopCounter < nameArray.length; loopCounter++)
		{
			if (nameArray[loopCounter].equals (name))
			{
				return loopCounter;
			}
		}
		
		return -1;
	}
}
