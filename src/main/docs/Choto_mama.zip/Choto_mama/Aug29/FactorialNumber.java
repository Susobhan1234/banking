public class FactorialNumber
{
	public static void main (String [] args)
	{
		String number = "";
		
		// System.out.println (args.length);
		
		if (args.length != 1)
		{
			System.out.println ("You must enter only one argument.");
			System.exit (0);
		}
		
		number = args [0];
		
		int intValue = Integer.parseInt (number);
		int loopCounter = 1, fact = 1;
		
		for (loopCounter = 1; loopCounter <= intValue; loopCounter++)
		{
			fact = fact * loopCounter;
		}
		
		System.out.println (fact);
	}
}