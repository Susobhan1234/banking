// 10,12,13,15,24,10,13,15,13,10,24

public class OccurencOfNumber
{
	public static void main (String [] args)
	{
		String firstString = "";
		
		if (args.length != 1)
		{
			System.out.println ("You must enter only one argument.");
			System.exit (0);
		}
		
		firstString = args [0];
		String [] splitString = firstString.split (",");
		
		int loopCounter = 0;
		
		for (loopCounter = 0; loopCounter < splitString.length; loopCounter++)
		{
			String searchingNumber = splitString [loopCounter];
			
			int returnCounterNumber = searchingOperation (splitString, searchingNumber);
			System.out.println (searchingNumber + " " + returnCounterNumber);
		}
	}
	
	// searchedArray = "10" "12" "13" "15" "24" "10";
	// searchedNumber = "10";
	
	public static int searchingOperation (String [] searchedArray, String searchedNumber)
	{
		int loopCounter = 0, counter= 0;
		
		for (loopCounter = 0; loopCounter < searchedArray.length; loopCounter++)
		{
			if (searchedArray [loopCounter].equals (searchedNumber))
			{
				counter++;
			}
		}
		
		return counter;
	}
}