
// dd/mm/yyyy

// 1, 3, 

public class Practice
{
	public static void main (String [] args)
	{
		String dateString = "";
		
		if (args.length != 1)
		{
			System.out.println ("You must enter only one argument.");
			System.exit (0);
		}
		
		dateString = args [0];
		
		String [] splitDate = dateString.split ("/");
		int date = Integer.parseInt (splitDate[0]);
		int month = Integer.parseInt (splitDate [1]);
		int year = Integer.parseInt (splitDate [2]);
		
		if ((month < 1) || (month > 12))
		{
			System.out.println ("ERROR");
			System.exit (0);
		}
		
		if ((month == 1) || (month == 3) || (month == 5) || (month == 7) || (month == 8) || (month == 10) || (month == 12))
		{
			if ((date < 1) || (date > 31))
			{
				System.out.println ("ERROR");
			}
		}
		
		else if ((month == 4) || (month == 6) || (month == 9) || (month == 11))
		{
			if((date < 1) || (date > 30))
			{
				System.out.println ("ERROR");
			}
		}
		
		else if (month == 2)
		{
			if ((year % 4 == 0) && (year % 100 == 0) && (year % 400 == 0))
			{
				if ((date < 1) || (date > 29))
				{
					System.out.println ("ERROR");
				}
			}
			else
			{
				if ((date < 1) || (date > 28))
				{
					System.out.println ("ERROR");
				}
		
			}
		}
	}
}

