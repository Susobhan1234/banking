public class DoubleOperation
{
		public static void addDoubleNumber (double firstDoubleNumber, double secondDoubleNumber)
	{
		// Adding two double numbers
		
		double add;
		add = firstDoubleNumber + secondDoubleNumber;
		System.out.println("After adding two numbers result will be = " + add);
		
		double afterAdd = addDouble (firstDoubleNumber, secondDoubleNumber);		
		System.out.println("After calling from the method add value will be = " + afterAdd);
		
		// After adding the value will be checked here for odd or even number
		
		if (afterAdd % 2 == 0)
		{
			System.out.println("Addition value is an even number");
		}
		else
		{
			System.out.println("Addition value is an odd number");
		}
	}
	
	public static void subDoubleNumber (double firstDoubleNumber, double secondDoubleNumber)
	{
		// Subtract two double numbers
		
		double sub;
		sub = firstDoubleNumber - secondDoubleNumber;
		System.out.println("After subtracting two numbers result will be = " + sub);
		
		double afterSub = subDouble (firstDoubleNumber, secondDoubleNumber);		
		System.out.println("After calling from the method sub value will be = " + afterSub);
		
		// After subtracting the value will be checked here for odd or even number
		
		if (afterSub % 2 == 0)
		{
			System.out.println("Subtracting value is an even number");
		}
		else
		{
			System.out.println("Subtracting value is an odd number");
		}
	}
	
	public static void multDoubleNumber (double firstDoubleNumber, double secondDoubleNumber)
	{
		// Multiply two double numbers
		
		double mult;
		mult = firstDoubleNumber * secondDoubleNumber;
		System.out.println("After multiplying two numbers result will be = " + mult);
		
		double afterMult = multDouble (firstDoubleNumber, secondDoubleNumber);		
		System.out.println("After calling from the method mult value will be = " + afterMult);
		
		// After subtracting the value will be checked here for odd or even number
		
		if (afterMult % 2 == 0)
		{
			System.out.println("Multiplication value is an even number");
		}
		else
		{
			System.out.println("Multiplication value is an odd number");
		}
	}
	
	public static void divDoubleNumber (double firstDoubleNumber, double secondDoubleNumber)
	{
		// Division two double numbers
		
		double div;
		div = firstDoubleNumber / secondDoubleNumber;
		System.out.println("After division two numbers result will be = " + div);
		
		double afterDiv = divDouble (firstDoubleNumber, secondDoubleNumber);		
		System.out.println("After calling from the method div value will be = " + afterDiv);
		
		// After subtracting the value will be checked here for odd or even number
		
		if (afterDiv % 2 == 0)
		{
			System.out.println("Division value is an even number");
		}
		else
		{
			System.out.println("Division value is an odd number");
		}
	}
	
	// This method for add two numbers
	
	public static double addDouble (double firstDoubleNumber, double secondDoubleNumber)
	{
		double add = firstDoubleNumber + secondDoubleNumber;
		return add;
	}
	
	// This method for add two numbers
	
	public static double subDouble (double firstDoubleNumber, double secondDoubleNumber)
	{
		double sub = firstDoubleNumber - secondDoubleNumber;
		return sub;
	}
	
	// This method for multiply two numbers
	
	public static double multDouble (double firstDoubleNumber, double secondDoubleNumber)
	{
		double mult = firstDoubleNumber * secondDoubleNumber;
		return mult;
	}
	
	// This method for multiply two numbers

	public static double divDouble (double firstDoubleNumber, double secondDoubleNumber)
	{
		double div = firstDoubleNumber / secondDoubleNumber;
		return div;
	}
}