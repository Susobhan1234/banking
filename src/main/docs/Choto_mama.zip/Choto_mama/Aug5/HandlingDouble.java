public class HandlingDouble
{
	public static void main(String [] args)
	{
		String firstNumber = args [0];
		System.out.println("The first arguments you entered = " + firstNumber);
		String secondNumber = args [1];
		System.out.println("The second arguments you entered = " + secondNumber);
		
		double firstDoubleNumber, secondDoubleNumber;
		
		firstDoubleNumber = Double.parseDouble (firstNumber);
		System.out.println("First argument after converting into a double = " + firstDoubleNumber);
		secondDoubleNumber = Double.parseDouble (secondNumber);
		System.out.println("Second argument after converting into a double = " + secondDoubleNumber);
		
		DoubleOperation arithmeticOperation = new DoubleOperation();
		
		arithmeticOperation.addDoubleNumber (firstDoubleNumber, secondDoubleNumber);	
		arithmeticOperation.subDoubleNumber (firstDoubleNumber, secondDoubleNumber);
		arithmeticOperation.multDoubleNumber (firstDoubleNumber, secondDoubleNumber);
		arithmeticOperation.divDoubleNumber (firstDoubleNumber, secondDoubleNumber);	
	}	
}