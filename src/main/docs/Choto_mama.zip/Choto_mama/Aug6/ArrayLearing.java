public class ArrayLearing
{
	public static void main (String [] args)
	{
		String name = args [0];
		System.out.println ("The entered string through commandline is : " + name);
		char nameChar[10];
	}
}