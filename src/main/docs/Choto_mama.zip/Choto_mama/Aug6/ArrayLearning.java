public class ArrayLearning
{
	public static void main (String [] args)
	{
		String name = args [0], upperCase, lowerCase;
		System.out.println ("The entered string through commandline is : " + name);
		char[] nameChar;
		nameChar = name.toCharArray();
		Vowel vowelCount = new Vowel();
		vowelCount.getVowelCount (name, nameChar);
		
		// For converting the entered string into uppercase
		
		upperCase = name.toUpperCase();
		System.out.println ("After do the uppercase string will be : " + upperCase);
		
		// For converting the entered string into lowercase
		
		lowerCase = name.toLowerCase();
		System.out.println ("After do the lowercase string will be : " + lowerCase);
		
		// For count the number of s
		
		valueCounter(name, nameChar);
	}
	
	public static void valueCounter (String name, char[] nameChar)
	{
		int loopCounter = 0, valueCounter = 0;
		
		for (loopCounter = 0; loopCounter < name.length(); loopCounter++)
		{
			if ((nameChar [loopCounter] == 's') ||
			   (nameChar [loopCounter] == 'S'))
			{
				valueCounter++;
			}	
		}
		
		System.out.println ("Number of s in the input string is = " + valueCounter);
	}
}