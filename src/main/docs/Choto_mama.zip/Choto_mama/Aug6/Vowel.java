public class Vowel
{
	public static void getVowelCount (String name, char[] nameChar)
	{
		int loopCounter = 0;
		
		for (loopCounter = 0; loopCounter < name.length(); loopCounter++)
		{
			System.out.print (nameChar [loopCounter]);
		}
		
		System.out.println ("");
		
		int vowelCounter = 0; 
		
		for (loopCounter = 0; loopCounter < name.length(); loopCounter++)
		{
			if ((nameChar [loopCounter] == 'a') ||
			   (nameChar [loopCounter] == 'e') ||
			   (nameChar [loopCounter] == 'i') ||
			   (nameChar [loopCounter] == 'o') ||
			   (nameChar [loopCounter] == 'u'))
			{
				vowelCounter++;
			}
			
			if ((nameChar [loopCounter] == 'A') ||
			   (nameChar [loopCounter] == 'E') ||
			   (nameChar [loopCounter] == 'I') ||
			   (nameChar [loopCounter] == 'O') ||
			   (nameChar [loopCounter] == 'U'))
			{
				vowelCounter++;
			}
		}
		
		System.out.println ("Number of vowel is = " + vowelCounter);
	}
}