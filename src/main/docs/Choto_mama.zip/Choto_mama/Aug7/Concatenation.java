public class Concatenation
{
	public static void main (String [] args)
	{
		String firstValue, secondValue, result;
		firstValue = args [0];
		System.out.println("First argument is : " + firstValue);
		secondValue = args [1];
		System.out.println("Second argument is : " + secondValue);
		result = firstValue.concat(secondValue);
		System.out.println("After concatination value is : " + result);
		System.out.println("Another way to concatenate : " + firstValue + secondValue );
	}
}