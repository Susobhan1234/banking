public class CostCalculation
{
	public static void main (String [] args)
	{
		String cost = args [0];
		String tax = args [1];
		
		// Converting string to double
		
		double costDoubleNumber, taxDoubleNumber, value;
		costDoubleNumber = Double.parseDouble (cost);
		System.out.println("First argument after converting into a double = " + costDoubleNumber);
		taxDoubleNumber = Double.parseDouble (tax);
		System.out.println("Second argument after converting into a double = " + taxDoubleNumber);	
		
		value = (costDoubleNumber + (( costDoubleNumber * taxDoubleNumber) / 100));
		System.out.println("value is = " + value);
	}
}
