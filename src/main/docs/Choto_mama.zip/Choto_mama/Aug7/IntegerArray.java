public class IntegerArray
{
	public static void main (String [] args)
	{
		int [] numberArray = new int [4]; // How to declear an integer array.
		int i = 0;
		numberArray [0] = 145; // Assigning value to an element of integer array
		numberArray [1] = 1256;
		numberArray [2] = 456;
		// numberArray [3] = 987;
		
		for (i = 0; i < numberArray.length; i++) // numberArray.length for number of element in the array
		{
			System.out.println ("Numbers are = " + numberArray [i]);
			System.out.println ("");
		}
	}
}