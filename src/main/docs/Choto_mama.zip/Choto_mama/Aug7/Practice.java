public class Practice
{
	public static void main (String [] args)
	{
		String value = args [0];
		int loopCounter;
		System.out.println ("Entered string is : " + args [0]);
		char [] reverseValue = value.toCharArray ();
		
		for (loopCounter = value.length() - 1; loopCounter >= 0; loopCounter--)
		{
			System.out.print (reverseValue[loopCounter]);
		}
	}
}