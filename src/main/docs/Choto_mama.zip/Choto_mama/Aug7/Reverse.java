public class Reverse
{
	public static void main (String [] args)
	{
		String value = args [0]; // Cpture command line argument into the string
		int loopCounter;
		System.out.println ("The entered argument is : " + value);
		char [] charValue = value.toCharArray(); // Converting the entered string into a charecter array
		
		for (loopCounter = value.length() - 1; loopCounter >= 0; loopCounter--)
			
		// value.length() for finding the length of the string
		
		{
			char reverseValue = charValue [loopCounter];
			System.out.print (reverseValue);
		}
	}
}