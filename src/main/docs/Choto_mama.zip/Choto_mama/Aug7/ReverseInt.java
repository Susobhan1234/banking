public class ReverseInt
{
	public static void main (String [] args)
	{
		int intValue [] = new int [5];
		intValue [0] = 8;
		intValue [1] = 7;
		intValue [2] = 6;
		intValue [3] = 5;
		intValue [4] = 4;
		int loopCounter;
		
		for (loopCounter = intValue.length - 1; loopCounter >= 0; loopCounter--)
		{
			System.out.print (intValue [loopCounter]);
		}
	}
}