public class ArrayOperation
{
	public static void arrayOperation ()
	{
		char charValue [] = new char [10];
		int intValue [] = new int [10];
		int loopCounter;
		charValue [0] = 'x';
		intValue [0] = 8;
		System.out.println ("Char value is : " + charValue [0]);
		System.out.println ("Int value is : " + intValue [0]);
		
		charValue [6] = 'g';
		intValue [6] = 9;
		System.out.println ("Char value is : " + charValue [6]);
		System.out.println ("Int value is : " + intValue [6]);
		
		for (loopCounter = 0; loopCounter < charValue.length ; loopCounter++)
		{
			System.out.println ("Char values are : " + charValue [loopCounter]);
		}
		
		for (loopCounter = 0; loopCounter < intValue.length ; loopCounter++)
		{
			System.out.println ("Int values are : " + intValue [loopCounter]);
		}
		
		for (loopCounter = charValue.length - 1; loopCounter >= 0; loopCounter--)
		{
			System.out.println ("Char values are in reverse order : " + charValue [loopCounter]);
			System.out.println ("Int values are in reverse order : " + intValue [loopCounter]);	
		}
		
		double doubleValue [] = new double [10];
		doubleValue [0] = 8.56;
		System.out.println ("Double value is : " + doubleValue [0]);

		for (loopCounter = 0; loopCounter < doubleValue.length ; loopCounter++)
		{
			System.out.println ("Double values are : " + doubleValue [loopCounter]);
		}
		
		for (loopCounter = doubleValue.length - 1; loopCounter >= 0; loopCounter--)
		{
			System.out.println ("Double values are in reverse order : " + doubleValue [loopCounter]);
		}
	}
}