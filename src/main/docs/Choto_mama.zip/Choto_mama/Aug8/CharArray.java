public class CharArray
{
	public static void main (String [] args)
	{
		char [] value = new char [5];
		
		value [0] = 'a';
		
		int [] intValue = new int [5];
		
		intValue [0] = 12345;
	}
}