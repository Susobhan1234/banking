public class Practice
{
	public static void main (String [] args)
	{
		ArrayOperation object = new ArrayOperation();
		object.arrayOperation ();
	}
	
	public static int main (String [] args)
	{
		
	}
}