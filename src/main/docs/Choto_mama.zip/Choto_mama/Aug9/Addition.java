public class Addition
{
	public static void main (String [] args)
	{
		String number1, number2, number3, number4, number5;
		number1 = args [0];
		number2 = args [1];
		number3 = args [2];
		number4 = args [3];
		number5 = args [4];
		int intNumber1 = Integer.parseInt (number1);
		int intNumber2 = Integer.parseInt (number2);
		int intNumber3 = Integer.parseInt (number3);
		int intNumber4 = Integer.parseInt (number4);
		int intNumber5 = Integer.parseInt (number5);
		int loopCounter;
		
		for (loopCounter = 5 - 1; loopCounter >= 0; loopCounter--)
		{
			System.out.println ("After reverseing the input number : " + args [loopCounter]);
		}
		
		ArithmeticOperation arithmeticObject = new ArithmeticOperation();
		arithmeticObject.calculateAddAndAverage(intNumber1, intNumber2, intNumber3, intNumber4, intNumber5);
	}
}