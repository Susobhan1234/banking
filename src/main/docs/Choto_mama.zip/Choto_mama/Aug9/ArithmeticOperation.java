public class ArithmeticOperation
{
	public static void calculateAddAndAverage (int intNumber1, int intNumber2, int intNumber3, int intNumber4, int intNumber5)
	{
		int addValue;
		double avg;
		addValue = intNumber1 + intNumber2 + intNumber3 + intNumber4 + intNumber5;
		System.out.println ("After adding five numbers value is = " + addValue);
		avg = (double)addValue / 5;
		System.out.println ("Average of five numbers is = " + avg);
	}
}