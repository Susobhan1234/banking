public class GetNumber
{
	public static void main (String [] args)
	{
		String number = args [0];
		
		try
		{
			int intNumber = Integer.parseInt (number);
			System.out.println ("The number is = " + number);
		}
		catch (Exception ex)
		{
			System.out.println ("You entered " + number + " not an integer number");
			ex.printStackTrace();
		}
	}
}