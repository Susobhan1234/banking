public class MergeArrays
{
	public static void main (String [] args)
	{
		int [] firstArray = new int [5];
		int [] secondArray = new int [2];
		int [] allArray = new int [7];
		
		firstArray [0] = 200;
		firstArray [1] = 100;
		firstArray [2] = 100;
		firstArray [3] = 300;
		firstArray [4] = 100;
		
		secondArray [0] = 100;
		secondArray [1] = 100;
		
		AddAndAvgIntArray operations = new AddAndAvgIntArray();
		operations.arrayOperation (firstArray, secondArray, allArray);
	}
}