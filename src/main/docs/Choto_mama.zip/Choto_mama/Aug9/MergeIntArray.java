public class MergeIntArray
{
	public static void main (String [] args)
	{
		int [] firstArray = new int [5];
		int [] secondArray = new int [2];
		int [] allArray = new int [7];
		
		firstArray [0] = 100;
		firstArray [1] = 200;
		firstArray [2] = 300;
		firstArray [3] = 400;
		firstArray [4] = 500;
		
		secondArray [0] = 600;
		secondArray [1] = 799;
		
		UpdateAddAvg operations = new UpdateAddAvg();
		operations.arrayOperation (firstArray, secondArray, allArray);
	}
}