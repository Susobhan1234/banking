public class UpdateAddAvg
{
	public static void arrayOperation (int [] firstArray, int [] secondArray, int [] allArray)
	{
		int loopCounter, secondLoopCounter, addValue = 0;
		double avg;
		
		for (loopCounter = 0; loopCounter < firstArray.length; loopCounter++)
		{
			allArray [loopCounter] = firstArray [loopCounter];
		}
		
		for (secondLoopCounter = 0; secondLoopCounter < secondArray.length; secondLoopCounter++)
		{
			allArray [loopCounter] = secondArray [secondLoopCounter];
			loopCounter++;
		}
		
		for (loopCounter = 0; loopCounter < allArray.length; loopCounter++)
		{
			System.out.println ("Updated allArray values : " + allArray[loopCounter]);
		}
		
		for (loopCounter = allArray.length - 1; loopCounter >= 0; loopCounter--)
		{
			System.out.println ("All array values in reverse order : " + allArray[loopCounter]);
		}
		
		for (loopCounter = 0; loopCounter < allArray.length; loopCounter++)
		{
			addValue = addValue + allArray[loopCounter];
		}
		
		System.out.println ("After adding all allArray value result = " + addValue);
		avg = (double) addValue / allArray.length;
		System.out.println ("Average of allArray value is = " + avg);
	}
}