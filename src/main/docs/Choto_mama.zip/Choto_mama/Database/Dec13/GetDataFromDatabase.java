import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;

// Connection is the class name and java.sql is the package name.

public class GetDataFromDatabase
{
	public static void main (String [] args)
	{
		Connection connectionObject = null;
		Statement statementObject = null;
		ResultSet resultSetObject = null;
		
		try
		{
			// Connect to the database
			
			Class.forName ("org.postgresql.Driver");
			connectionObject = DriverManager.getConnection ("jdbc:postgresql://localhost/", "postgres", "Smc@1234");
			
			// Define the query to execute
			
			String query = "SELECT myCollege.student_name, myCollege.student_address, mySubject.subject_name " + 
			" FROM my_college myCollege, my_subject mySubject, student_subject studentSubject " + 
			" WHERE myCollege.student_roll = studentSubject.student_roll " + 
			" AND studentSubject.subject_id = mySubject.subject_id ";

			// Prepare the query to execute
			
			statementObject = connectionObject.createStatement ();
			
			// Execute the query
			
			resultSetObject = statementObject.executeQuery (query);
			
			// Loop through the data return by the query
			
			while (resultSetObject.next ()) 
			{
				// Get the data of the column student_name
				
				String studentName = resultSetObject.getString ("student_name");
				
				// Get the data of the column student_address
								
				String studentAddress = resultSetObject.getString ("student_address");
				
				// Get the data of the column subject_name
				
				String subjectName = resultSetObject.getString ("subject_name");
				
				System.out.println (studentName.trim () + " " + studentAddress.trim () + " " + subjectName.trim ());
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
		finally
		{
			// Close the database resource
			try
			{
				resultSetObject.close ();
				statementObject.close ();
				connectionObject.close ();
			}
			catch (Exception ex)
			{
				ex.printStackTrace ();
			}
		}
	}
}

// set CLASSPATH=C:\\Temp\\postgresql-42.2.18.jar;%CLASSPATH%;.