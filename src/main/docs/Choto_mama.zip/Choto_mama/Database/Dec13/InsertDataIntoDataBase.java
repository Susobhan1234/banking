public class InsertDataIntoDataBase
{
	public static void main (String [] args)
	{
		Connection connectionObject = null;
		Statement statementObject = null;
		ResultSet resultObject = null;
		
		try
		{
			classforName ("org.postgresql.Driver");
			connectionObject = DriverManager.getConnection ("jdbc:postgresql://localhost/", "postgres", "Smc@1234");
			
			String query = "INSERT INTO my_college VALUES " +
			" ( " +
			" 1, " +
			" 'Susobhan', " +
			" 'Chandkuri' " + 
			" ) ";
			statementObject = connectionObject.createStatement ();
			resultObject = statementObject.executeQuery (query);
			
			while (resultObject.next ())
			{
				
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
		finally
		{
			resultObject.close ();
			
			
			
			
			
			
			
			
			
			statementObject.close ();
			connectionObject.close ();
		}
	}
}