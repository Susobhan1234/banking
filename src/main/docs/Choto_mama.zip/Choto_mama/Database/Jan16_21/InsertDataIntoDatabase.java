import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

// Connection is the class name and java.sql is the package name.

public class InsertDataIntoDatabase
{
	public static void main (String [] args)
	{
		Connection connectionObject = null;
		Statement statementObject = null;
		int loopCounter = 1;
		
		try
		{
			// Connect to the database
			
			Class.forName ("org.postgresql.Driver");
			connectionObject = DriverManager.getConnection ("jdbc:postgresql://localhost/", "postgres", "Smc@1234");
			
			for (loopCounter = 403; loopCounter <= 100000; loopCounter++)
			{	
				// Define the query to execute
				
				String query = "insert into customer_info values" + 
				" ( " +
				loopCounter + "," + 
				loopCounter + "," + 
				"'" + loopCounter + "-Ritam Rana'" + 
				")";
				
				System.out.println (query);

				// Prepare the query to execute
				
				statementObject = connectionObject.createStatement ();
				
				// Execute the query
				
				statementObject.executeUpdate (query);
			}

		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
		finally
		{
			// Close the database resource
			try
			{
				statementObject.close ();
				connectionObject.close ();
			}
			catch (Exception ex)
			{
				ex.printStackTrace ();
			}
		}
	}
}

// set CLASSPATH=C:\\Temp\\postgresql-42.2.18.jar;%CLASSPATH%;.