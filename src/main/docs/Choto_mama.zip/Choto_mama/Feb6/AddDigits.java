public class AddDigits
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		
		for (;;)
		{
			String [] arr = inputString.split("");
			int returnValue = sum (arr);
			
			if (returnValue < 10)
			{
				System.out.println (returnValue);
				break;
			}
			else
			{
				String newString = "";
				newString = newString + returnValue;
				inputString = newString;
			}
		}
	}
	public static int sum(String [] arr)
	{
		int sum = 0;
		for (int loopCounter = 0; loopCounter < arr.length; loopCounter++)
		{
			int number = Integer.parseInt(arr[loopCounter]);
			sum = sum + number;
		}
		
		return sum;
	}
}
