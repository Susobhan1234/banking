public class CalculateSum
{
	public static void main (String [] args)
	{
		int num1 = 56897, num2 = 899999, sum;
		sum = getTotal (num1, num2);
		System.out.println("The sum of " + num1 + " and " + num2 + " is = " + sum);		
		
		num1 = 120;
		num2 = 254;
		sum = getTotal (num1, num2);
		System.out.println("The sum of " + num1 + " and " + num2 + " is = " + sum);	
		
		num1 = -15;
		num2 = 25;
		sum = getTotal (num1, num2);
		System.out.println("The sum of " + num1 + " and " + num2 + " is = " + sum);				
	}
	
	// This method will return sum of two integers
	public static int getTotal (int number1, int number2) 
	{
		int sum = 0;
		sum = number1 + number2;
		return sum;
	}
}