public class HandlingInteger
{
	public static void main (String [] args)
	{
		int rollNo = 41;
		System.out.println("Your Roll Number is:" + rollNo);
		
		if ( rollNo % 2 == 0)
		{
			System.out.println("Your Roll Number is a Even Number");
		}
		else
		{
			System.out.println("Your Roll Number is a Odd Number");
		}
	}
}