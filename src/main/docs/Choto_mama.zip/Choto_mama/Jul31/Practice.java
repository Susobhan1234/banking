import java.util.Scanner;

public class Practice 
{
	public static void main (String []args)
	{
		System.out.println("Enter your name:");
		
		// ClassName variableName = new ClassName();  // Empty constructor 
		Scanner sc = new Scanner(System.in);
		String sm = sc.nextLine ();
		System.out.println("Your name is:" + sm );		
	}
}