import java.util.Scanner;

public class UserInput
{
	public static void main (String [] args)
	{
		String [] arr = new String [10];
		int loopCounter = 0, loopCounter2 = 0;
		 
		for (; ;)
		{
			Scanner sc = new Scanner (System.in);
			String myName = sc.nextLine ();
			
			arr [loopCounter] = myName;
			loopCounter++;
			
			if (loopCounter == 10)
			{
				break;
			}
		}
		
		for (loopCounter2 = 0; loopCounter2 < loopCounter; loopCounter2++)
		{
			System.out.println (arr [loopCounter2]);
		}			
	}
}