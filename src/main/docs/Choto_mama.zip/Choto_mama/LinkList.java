public void deleteLastNode (List list)
{
	int listSize = getNumberOfNode (list);
	
	if (listSize == 0)
	{
		print ("There is nothing to deleted");
		return;
	}
	
	if (listSize == 1)
	{
		free (list);
		return;
	}
	
	for (int loopCounter = 1; loopCounter < listSize; loopCounter++)
	{
		list = list.next;
	}
}