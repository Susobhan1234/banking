import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;

public class DisplayNameAndMarks
{
	public static void main (String [] args)
	{
		FileReader readerObj = null;
		BufferedReader bufferObj = null;
		
		try
		{
			File fileObj = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Nov1\\StudentDetails.txt");
			readerObj = new FileReader (fileObj);
			bufferObj = new BufferedReader (readerObj);
			
			String lineString = "";
			
			ArrayList studentList = new ArrayList ();
			
			while ((lineString = bufferObj.readLine ()) != null)
			{
				String [] lineStringArray = lineString.split (",");
				
				String name = lineStringArray [1];
				
				String result = lineStringArray [3];
				int marks = Integer.parseInt (result);
				
				Student studentObj = new Student ();
				
				studentObj.setStudentName (name);
				studentObj.setStudentMarks (marks);
				
				studentList.add (studentObj);
			}
			
			studentList.remove (5); // Remove a lie
			studentList.set (1, studentList.get (15)); // Replace a line 
			
			// ** add a line what you want
			
			Student obj1 = new Student ();
			obj1.setStudentName ("Soumya");
			obj1.setStudentMarks (75);
			
			studentList.add (1, obj1);
			
			studentList.add (obj1);
			
			obj1.setStudentName ("Roshita");
			
			// studentList.clear (); // Remove everything from the ArrayList
			
			Student obj2 = new Student ();
			obj2.setStudentName ("Rohan");
			obj2.setStudentMarks (90);
			studentList.add (obj2);
			
			boolean foundFlag = studentList.contains (obj2);
			System.out.println ("Found = " + foundFlag);
			
			int indexNumber = studentList.indexOf (obj2);
			System.out.println ("Index Number = " + indexNumber);
			
			for (int loopCounter = 0; loopCounter < studentList.size (); loopCounter++)
			{
				Student studentObj = (Student) studentList.get (loopCounter);
				
				System.out.println ((loopCounter + 1) + ". " + "Name : " + studentObj.getStudentName () + " " + "Marks : " + studentObj.getStudentMarks ());
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
		finally
		{
			try
			{
				bufferObj.close ();
				readerObj.close ();
			}
			catch (Exception ex)
			{
				ex.printStackTrace ();
			}
		}
	}
}