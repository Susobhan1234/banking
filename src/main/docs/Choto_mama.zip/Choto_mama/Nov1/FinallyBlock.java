public class FinallyBlock
{
	public static void main (String [] args)
	{
		try
		{			
			System.out.println ("Susobhan");
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
		finally
		{
			System.out.println ("I'm in finally block");
		}
	}
}