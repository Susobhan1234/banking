public class Student
{
	String studentName;
	int studentMarks;
	
	public void setStudentName (String name)
	{
		studentName = name;
	}
	
	public String getStudentName ()
	{
		return studentName;
	}
	
	public void setStudentMarks (int marks)
	{
		studentMarks = marks;
	}
	
	public int getStudentMarks ()
	{
		return studentMarks;
	}
	
}


// this class named as POJO(Plain Old Java Object) or BEAN 