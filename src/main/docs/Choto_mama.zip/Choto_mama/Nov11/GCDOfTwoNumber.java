public class GCDOfTwoNumber
{
	public static void main (String [] args)
	{
		String firstInputString = args [0];
		String secondInputString = args [1];
		int [] firstArray = new int [10];
		int [] secondArray = new int [10];
		int [] thirdArray = new int [10];

		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, gcd = 1;
		
		int firstNumber = Integer.parseInt (firstInputString);
		factor (firstNumber, firstArray);
		
		int secondNumber = Integer.parseInt (secondInputString);
		factor (secondNumber, secondArray);
		
		for (loopCounter1 = 0; loopCounter1 < firstArray.length; loopCounter1++)
		{
			int searchingNumber = firstArray [loopCounter1];
			boolean returnValue = searchingInArray (secondArray, searchingNumber);
			
			if (returnValue == true)
			{
				thirdArray [loopCounter2] = searchingNumber;
				loopCounter2++;
			}
		}
		
		for (loopCounter3 = 0; loopCounter3 < thirdArray.length; loopCounter3++)
		{
			if (thirdArray [loopCounter3] != 0)
			{
				gcd = gcd * thirdArray [loopCounter3];
			}
		}
		
		System.out.println (gcd);
	}
	
	public static void factor (int number, int [] array)
	{
		int loopCounter = 0, counter = 0;
		
		for (loopCounter = 2; loopCounter < number; loopCounter++)
		{
			if (number % loopCounter == 0)
			{
				int result = number / loopCounter;
				int remainder = number % loopCounter;
				
				array [counter] = loopCounter;
				counter++;
				
				loopCounter = 1;
				number = result;
			}
		}
		
		array [counter] = number;
	}
	
	public static boolean searchingInArray (int [] whereToSearch, int whatToSearch)
	{
		int loopCounter1 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < whereToSearch.length; loopCounter1++)
		{
			if (whereToSearch [loopCounter1] == whatToSearch)
			{
				return true;
			}
		}
		
		return false;
	}
}