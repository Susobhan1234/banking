public class LCMOfTwoNumber
{
	public static void main (String [] args)
	{
		try
		{
			String firstInputString = args [0];
			String secondInputString = args [1];
			int [] firstArray = new int [10];
			int [] secondArray = new int [10];
			int [] thirdArray = new int [20];

			int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, lcm = 1, loopCounter4 = 0;
			
			int firstNumber = Integer.parseInt (firstInputString);
			factor (firstNumber, firstArray);
			
			int secondNumber = Integer.parseInt (secondInputString);
			factor (secondNumber, secondArray);
			
			for (loopCounter3 = 0; loopCounter3 < firstArray.length; loopCounter3++)
			{
				if (firstArray [loopCounter3] != 0)
				{
					lcm = lcm * firstArray [loopCounter3];
				}
			}
			
			System.out.println ("");
			
			int [] newArray = new int [10];
			
			for (loopCounter4 = 0; loopCounter4 < secondArray.length; loopCounter4++)
			{
				int loopCounter = 0;
				
				int searchingNumber = secondArray [loopCounter4];
				int numberOfOccurence2 = searchingOccurence (secondArray, searchingNumber);
				
				int numberOfOccurence1 = searchingOccurence (firstArray, searchingNumber);	
				
				boolean returnValue = searching (newArray, searchingNumber);
				newArray [loopCounter] = searchingNumber;
				loopCounter++;
				
				if (returnValue == false)
				{
					if (numberOfOccurence1 < numberOfOccurence2)
					{
						int difference = numberOfOccurence2 - numberOfOccurence1;
						int counter = 0;
						
						for (counter = 1; counter <= difference; counter++)
						{
							if (searchingNumber != 0)
							{
								lcm = lcm * searchingNumber;
							}
						}
					}
				}
			}
			
			System.out.println (lcm);
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
	}
	
	
	public static void factor (int number, int [] array)
	{
		int loopCounter = 0, counter = 0;
		
		for (loopCounter = 2; loopCounter < number; loopCounter++)
		{
			if (number % loopCounter == 0)
			{
				int result = number / loopCounter;
				int remainder = number % loopCounter;
				
				array [counter] = loopCounter;
				counter++;
				
				loopCounter = 1;
				number = result;
			}
		}
		
		array [counter] = number;
	}
	
	public static boolean searching (int [] whereToSearch, int whatToSearch)
	{
		int loopCounter1 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < whereToSearch.length; loopCounter1++)
		{
			if (whereToSearch [loopCounter1] == whatToSearch)
			{
				return true;
			}
		}
		
		return false;
	}
	
	public static int searchingOccurence (int [] whereToSearch, int whatToSearch)
	{
		int loopCounter1 = 0, counter = 0;
		
		for (loopCounter1 = 0; loopCounter1 < whereToSearch.length; loopCounter1++)
		{
			if (whereToSearch [loopCounter1] == whatToSearch)
			{
				counter++;
			}
		}
		
		return counter;
	}
}