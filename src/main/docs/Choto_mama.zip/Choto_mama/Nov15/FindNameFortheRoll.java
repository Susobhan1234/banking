import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;

public class FindNameFortheRoll
{
	public static void main (String [] args)
	{
		FileReader readerObj = null;
		BufferedReader bufferObj = null;
		
		try
		{
			File fileobj = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Nov15\\StudentDetails.txt");
			readerObj = new FileReader (fileobj);
			bufferObj = new BufferedReader (readerObj);
			
			String lineString = "";
			
			HashMap studentMap = new HashMap ();
			
			while ((lineString = bufferObj.readLine ()) != null)
			{
				String [] arr = lineString.split (",");
				
				String rollno = arr [0];
				int roll = Integer.parseInt (rollno);
				String name = arr [1];
				String subject = arr [2];
				String number = arr [3];
				int marks = Integer.parseInt (number);
								
				studentMap.put (roll, name);
			}
			
			Iterator itr = studentMap.entrySet ().iterator ();
			
			while (itr.hasNext ())
			{
				Map.Entry entry = (Map.Entry) itr.next ();
				int key = (int) entry.getKey ();
				String value = (String) entry.getValue ();
					
				System.out.println (key + " " + value);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
		finally
		{
			try
			{
				bufferObj.close ();
				readerObj.close ();
			}
			catch (Exception ex)
			{
				ex.printStackTrace ();
			}
		}
	}
}