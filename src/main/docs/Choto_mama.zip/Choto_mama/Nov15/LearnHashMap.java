import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;

public class LearnHashMap
{
	public static void main (String [] args)
	{
		FileReader readerObj = null;
		BufferedReader bufferObj = null;
		
		try
		{
			File fileObj = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Nov15\\StudentDetails.txt");
			readerObj = new FileReader (fileObj);
			bufferObj = new BufferedReader (readerObj);
			
			String lineString = "";
			HashMap studentMap = new HashMap ();
			
			while ((lineString = bufferObj.readLine ()) != null)
			{
				String [] newArr = lineString.split (",");
				
				String rollNumber = newArr [0];
				int roll = Integer.parseInt (rollNumber);
				String name = newArr [1];
				String subject = newArr [2];
				String number = newArr [3];
				int marks = Integer.parseInt (number);
				
				Student studentObj = new Student ();
				
				studentObj.setRollNumber (roll);
				studentObj.setStudentMarks (marks);
				studentObj.setStudentName (name);
				studentObj.setSubjectName (subject);
				
				ArrayList studentList = (ArrayList) studentMap.get (roll);
				
				if (studentList == null)
				{
					studentList = new ArrayList ();
					studentList.add (studentObj);
					studentMap.put (roll, studentList);
				}
				else
				{
					studentList.add (studentObj);
				}
			}

			Iterator itr = studentMap.entrySet ().iterator ();

			while (itr.hasNext ())
			{
				Map.Entry entry = (Map.Entry) itr.next ();
				int key = (int) entry.getKey ();
				ArrayList value = (ArrayList) entry.getValue ();
				
				for (int loopCounter = 0; loopCounter < value.size (); loopCounter++)
				{
					Student studentObj = (Student) value.get (loopCounter);
					
					System.out.print (studentObj.getRollNumber () + ",");
					System.out.print (studentObj.getStudentName () + ",");
					System.out.print (studentObj.getSubjectName () + ",");
					System.out.println (studentObj.getStudentMarks ());
				}
			}
		}
		catch (Exception ex)
		{
			 ex.printStackTrace ();
		}
		finally
		{
			try
			{
				bufferObj.close ();
				readerObj.close ();
			}
			catch (Exception ex)
			{
				 ex.printStackTrace ();
			}
		}
	}
}