public class Student
{
	int rollNumber;
	int studentMarks;
	String studentName;
	String subjectName;
	
	public void setRollNumber (int roll)
	{
		rollNumber = roll;
	}
	
	public int getRollNumber ()
	{
		return rollNumber;
	}
	
	public void setStudentMarks (int marks)
	{
		studentMarks = marks;
	}
	
	public int getStudentMarks ()
	{
		return studentMarks;
	}
	
	public void setStudentName (String name)
	{
		studentName = name;
	}
	
	public String getStudentName ()
	{
		return studentName;
	}
	
	public void setSubjectName (String subject)
	{
		subjectName = subject;
	}
	
	public String getSubjectName ()
	{
		return subjectName;
	}
}