/*

Given a string AcadEmy Of TechNologY, convert upper case to lower case and lower case to upper case. Take input from command line.
Example:
Input: AcadEmy Of TechNologY
Output: aCADeMY oF tECHnOLOGy
Test Cases:
1. VALID INPUT:
a) Only one argument will be given as input.
2. INVALID inputs:
a) No argument b) Two or more than two arguments.
3. You should generate output as follows:
a) Print to the STDOUT without any additional text.
b) If error print 'ERROR' to the STDOUT without any additional text.

*/

public class ChangeCase
{
	public static void main (String [] args)
	{
		String inputString = "";
		
		if (args.length != 1)
		{
			System.out.println ("ERROR");
			return;
		}
		
		inputString = args [0];
		
		char [] charArr = inputString.toCharArray ();
		
		int loopCounter = 0;
		
		for (loopCounter = 0; loopCounter < charArr.length; loopCounter++)  // SuSoBhan
		{
			int asciiValue = charArr [loopCounter];
			
			if ((asciiValue >= 65) && (asciiValue <= 90))
			{
				String newString = "" + charArr [loopCounter];
				String lowerCase = newString.toLowerCase ();
				System.out.print (lowerCase);
			}
			
			else if ((asciiValue >= 97) && (asciiValue <= 122))
			{
				String newString2 = "" + charArr [loopCounter];
				String upperCase = newString2.toUpperCase ();
				System.out.print (upperCase);
			}
			
			else
			{
				System.out.print (charArr [loopCounter]);
			}
		}
	}
}
