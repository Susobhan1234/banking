import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;

public class FindMarksFortheName
{
	public static void main (String [] args)
	{
		FileReader readerObj = null;
		BufferedReader bufferObj = null;
		
		try
		{
			File fileobj = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Nov21\\Details.txt");
			readerObj = new FileReader (fileobj);
			bufferObj = new BufferedReader (readerObj);
			
			String lineString = "";
			int totalMarks = 0;
			
			HashMap studentMap = new HashMap ();
			
			while ((lineString = bufferObj.readLine ()) != null)
			{
				String [] arr = lineString.split (",");

				String name = arr [1];

				String number = arr [3];
				int marks = Integer.parseInt (number);
				
				Integer value = (Integer) studentMap.get (name);
				 
				if (value == null)
				{
					studentMap.put (name, marks);
				}
				else
				{
					marks = marks + value.intValue ();
					studentMap.put (name, marks);
				}
			}
			
			Iterator itr = studentMap.entrySet ().iterator ();
			
			while (itr.hasNext ())
			{
				Map.Entry entry = (Map.Entry) itr.next ();
				String key = (String) entry.getKey ();
				int value = (int) entry.getValue ();
				
				System.out.println (key + " " + value);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
		finally
		{
			try
			{
				bufferObj.close ();
				readerObj.close ();
			}
			catch (Exception ex)
			{
				ex.printStackTrace ();
			}
		}
	}
}