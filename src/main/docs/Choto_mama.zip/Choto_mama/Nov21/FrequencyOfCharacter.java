/*
Given a string, find the second most frequent character in it. Take input from STDIN.
For Example:
Input:
str = "aabababa";
Output:
Second most frequent character is 'b'
*/

public class FrequencyOfCharacter
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		char [] inputChar = inputString.toCharArray ();
		int loopCOunter1 = 0, loopCOunter2 = 0, counter = 0;
		
		for (loopCOunter1 = 0; loopCOunter1 < inputChar.length; loopCOunter1++)
		{
			counter = 0;
			
			for (loopCOunter2 = loopCOunter1 + 1; loopCOunter2 < inputChar.length; loopCOunter2++)
			{
				if (inputChar [loopCOunter1] == inputChar [loopCOunter2])
				{
					counter++;
				}
			}
			
			System.out.println (inputChar [loopCOunter1] + "=" + counter);
		}
	}
}