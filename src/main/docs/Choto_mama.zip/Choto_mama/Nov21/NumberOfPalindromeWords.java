/*

3. Given a sentence, write a program to count the number of 
palindrome words in it. Take input from command line argument.

*/

public class NumberOfPalindromeWords
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		String [] stringArr = inputString.split (" ");
		int loopCounter = 0, count = 0;
		
		for (loopCounter = 0; loopCounter < stringArr.length; loopCounter++)
		{
			boolean returnValue = palindrome (stringArr [loopCounter]);
			
			if (returnValue == true)
			{
				count++;
			}
		}
		
		System.out.println (count);
	}
	
	public static boolean palindrome (String newString)
	{
		char [] charArray = newString.toCharArray ();
		String reverseString = "";
		int loopCounter1 = 0;
		
		for (loopCounter1 = charArray.length - 1; loopCounter1 >= 0; loopCounter1--)
		{
			reverseString = reverseString + charArray [loopCounter1];
		}
		
		if (newString.equals (reverseString))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
