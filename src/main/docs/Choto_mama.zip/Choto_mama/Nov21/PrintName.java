import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;

public class PrintName
{
	public static void main (String [] args)
	{
		FileReader readerObj = null;
		BufferedReader bufferObj = null;
		
		try
		{
			File fileobj = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Nov21\\StudentDetails.txt");
			readerObj = new FileReader (fileobj);
			bufferObj = new BufferedReader (readerObj);
			
			String lineString = "";
			String [] newArr = new String [100];
			int counter = 0;
			
			while ((lineString = bufferObj.readLine ()) != null)
			{
				String name = lineString;
				boolean returnValue = searchInArray (newArr, name);
				
				if (returnValue == false)
				{
					newArr [counter] = name;
					counter++;
				}
			}
			
			for (int loopCounter = 0; loopCounter < newArr.length; loopCounter++)
			{
				if (newArr [loopCounter] != null)
				{
					System.out.println (newArr [loopCounter]);
				}
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
		finally
		{
			try
			{
				bufferObj.close ();
				readerObj.close ();
			}
			catch (Exception ex)
			{
				ex.printStackTrace ();
			}
		}
	}
	
	public static boolean searchInArray (String [] whereToSearch, String whatToSearch)
	{
		int loopCounter = 0;
		
		for (loopCounter = 0; loopCounter < whereToSearch.length; loopCounter++)
		{	
			if (whereToSearch[loopCounter] != null)
			{
			
				if (whereToSearch [loopCounter].equals (whatToSearch))
				{
					return true;
				}
			}
		}
		
		return false;
	}
}