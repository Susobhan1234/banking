import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;

public class PrintOnlyName
{
	public static void main (String [] args)
	{
		FileReader readerObj = null;
		BufferedReader bufferObj = null;
		
		try
		{
			File fileobj = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Nov21\\StudentDetails.txt");
			readerObj = new FileReader (fileobj);
			bufferObj = new BufferedReader (readerObj);
			
			String lineString = "";
			
			HashMap studentMap = new HashMap ();
			
			while ((lineString = bufferObj.readLine ()) != null)
			{
				String name = lineString;
				studentMap.put (name, name);
			}
			
			Iterator itr = studentMap.entrySet ().iterator ();
			
			while (itr.hasNext ())
			{
				Map.Entry entry = (Map.Entry) itr.next ();
				String key = (String) entry.getKey ();
				
				System.out.println (key);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
		finally
		{
			try
			{
				bufferObj.close ();
				readerObj.close ();
			}
			catch (Exception ex)
			{
				ex.printStackTrace ();
			}
		}
	}
}