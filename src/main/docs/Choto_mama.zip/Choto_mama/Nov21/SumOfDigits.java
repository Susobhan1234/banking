/*

Find out sum of digits of a number using recursion. Take input from STDIN and display output to STDOUT without any additional text.
Examples:
Input:
648
Output:
18
Input:
123
Output:
6

*/

public class SumOfDigits
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		char [] charArr = inputString.toCharArray ();
		int loopCounter1 = 0, sum = 0;
		
		for (loopCounter1 = 0; loopCounter1 < charArr.length; loopCounter1++)
		{
			String newString = "" + charArr [loopCounter1];
			int number = Integer.parseInt (newString);
			sum = sum + number;
		}
		
		System.out.println (sum);
	}
}