import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;

public class Practice
{
	public static void main (String [] args)
	{
		FileReader readerObj = null;
		BufferedReader bufferObj = null;
		
		try 
		{
			File fileObj = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Nov6\\StudentDetails.txt");
			readerObj = new FileReader (fileObj);
			bufferObj = new BufferedReader (readerObj);
			
			String lineString = "";
			ArrayList studentList = new ArrayList ();
			
			while ((lineString = bufferObj.readLine ()) != null)
			{
				String [] lineStringArray = lineString.split (",");
				
				String name = lineStringArray [1];
				String marksValue = lineStringArray [3];
				int marks = Integer.parseInt (marksValue);
				
				Student studentObj = new Student ();
				
				studentObj.setStudentName (name);
				studentObj.setStudentMarks (marks);
				
				studentList.add (studentObj);
			}
			
			Student whatToSearchObj = new Student ();
				
			whatToSearchObj.setStudentName ("xyz");
			whatToSearchObj.setStudentMarks (90);
			
			boolean returnValue = searchStudentRecord (studentList, whatToSearchObj);
			System.out.println (returnValue);
			
			sortByStudentMarks (studentList);
			
			for (int loopCounter = 0; loopCounter < studentList.size (); loopCounter++)
			{
				Student newTemp = (Student) studentList.get (loopCounter);
				System.out.println (newTemp.getStudentName () + " " + newTemp.getStudentMarks ());
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
		finally
		{
			try
			{
				bufferObj.close ();
				readerObj.close ();
			}
			catch (Exception ex)
			{
				ex.printStackTrace ();
			}
		}
	}
	
	public static boolean searchStudentRecord (ArrayList whereToSearch, Student whatToSearch)
	{
		for (int loopCounter = 0; loopCounter < whereToSearch.size (); loopCounter++)
		{
			Student temp = (Student) whereToSearch.get (loopCounter);
			
			String whereToSearchStudentName = temp.getStudentName ();
			int whereToSearchStudentMarks = temp.getStudentMarks ();
			
			String whatToSearchStudentName = whatToSearch.getStudentName ();
			int whatToSearchStudentMarks = whatToSearch.getStudentMarks ();
			
			if  (
					(whereToSearchStudentName.equals (whatToSearchStudentName)) && 
					(whereToSearchStudentMarks == whatToSearchStudentMarks)
				)
			{
				return true;
			}
		}
		
		return false;
	}
	
	public static void sortByStudentMarks (ArrayList studentList)
	{
		int loopCounter = 0, loopCounter1 = 0;
		
		for (loopCounter = 0; loopCounter < studentList.size (); loopCounter++)
		{
			for (loopCounter1 = loopCounter + 1; loopCounter1 < studentList.size (); loopCounter1++)
			{
				Student object1 = (Student) studentList.get (loopCounter);
				Student object2 = (Student) studentList.get (loopCounter1);
				
				int marks1 = object1.getStudentMarks ();
				int marks2 = object2.getStudentMarks ();
				
				if (marks1 > marks2)
				{
					Student temp = object1;
					studentList.set (loopCounter, object2);
					studentList.set (loopCounter1, temp);
				}
			}
		}
	}
}

// 1.38 hour