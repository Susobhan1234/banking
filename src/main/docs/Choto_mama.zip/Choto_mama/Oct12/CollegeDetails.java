import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;


public class CollegeDetails
{
	public static void main (String [] args)
	{
		try
		{
			File fileObject = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Oct12\\MyCollege.txt");
			FileReader readerObject = new FileReader (fileObject);
			BufferedReader bufferObject = new BufferedReader (readerObject);
			
			String lineString = "";
			
			ArrayList studentList = new ArrayList ();
			
			while ((lineString = bufferObject.readLine ()) != null)
			{
				String [] arr = lineString.split (",");
				
				String roll = arr [0];
				int rollNo = Integer.parseInt (roll);
				String name = arr [1];
				String subject = arr [2];
				String marks = arr [3];
				int marksValue = Integer.parseInt (marks);
								
				Student studentObject = new Student ();
				
				studentObject.setRollNumber (rollNo);
				studentObject.setStudentName (name);
				studentObject.setSubjectName (subject);
				studentObject.setStudentMarks (marksValue);
				
				studentList.add (studentObject);
			}
			
			sortArrayList (studentList);
			
			for (int loopCounter = 0; loopCounter < studentList.size (); loopCounter++)
			{
				// int number = arr [loopCounter];
				
				Student studentData = (Student)studentList.get (loopCounter);
				
				System.out.print (studentData.getRollNumber () + " ");
				System.out.print (studentData.getStudentName () + " ");
				System.out.print (studentData.getSubjectName () + " ");
				System.out.println (studentData.getStudentMarks ());
			}
		}
		
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
	}
	
	public static void sortArrayList (ArrayList arr)
	{
		int loopCounter1 = 0, loopCounter2 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < arr.size (); loopCounter1++)
		{
			for (loopCounter2 = loopCounter1 + 1; loopCounter2 < arr.size (); loopCounter2++)
			{
				Student student1 = (Student) arr.get (loopCounter1);
				Student student2 = (Student) arr.get (loopCounter2);
				
				if (student1.getStudentMarks () > student2.getStudentMarks ())
				{
					Student temp = student1;
					arr.set (loopCounter1, student2);
					arr.set (loopCounter2, temp);
				}
			}
		}
	}
}