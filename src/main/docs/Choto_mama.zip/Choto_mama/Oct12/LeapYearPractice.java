/*
4. C program to check leap year. Input should be taken from command line.
Test Cases:
-----------
1. VALID INPUT:
a) Only one argument will be given as input. (E.g. 1989 or 2018)
2. INVALID INPUT:
a) More than one argument or no argument.
b) Negative number as year.
c) Fraction Number as year.
d) String (E.g. 2a56 or 19,0)
e) Number which is out of the range of maximum unsigned integer.
3. OUTPUT:
a) Print Yes to the STDOUT without any additional text if the input year is leap year.
b) Print No to the STDOUT without any additional text if the input year is not leap
year.
c) If error print 'ERROR' to the STDOUT without any additional text.
*/

public class LeapYearPractice
{
	public static void main (String [] args)
	{
		String inputString = "";
		
		if (args.length != 1)
		{
			System.out.println ("ERROR");
			return;
		}
		
		try 
		{
			inputString = args [0];
			int year = Integer.parseInt (inputString);
			
			if (((year % 4 == 0) && (year % 100 != 0)) || ((year % 100 == 0) && (year % 400 == 0)))
			{
				System.out.println ("Yes");
			}
			else
			{
				System.out.println ("No");
			}
		}
		catch (Exception ex)
		{
			System.out.println ("ERROR");
		}
	}
}