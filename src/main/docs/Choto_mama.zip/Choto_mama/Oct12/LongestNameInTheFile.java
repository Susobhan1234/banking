import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;


public class LongestNameInTheFile
{
	public static void main (String [] args)
	{
		try
		{
			File fileObj = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Oct12\\MyCollege.txt");
			FileReader readerObj = new FileReader (fileObj);
			BufferedReader bufferObj = new BufferedReader (readerObj);
			
			String lineString = "";
			String [] nameArr = new String [100];
			int loopCounter = 0, loopCounter1= 0, loopCounter2 = 0;
			
			while ((lineString = bufferObj.readLine()) != null)
			{
				String [] arr = lineString.split (",");
				
				String name = arr [1];
				nameArr [loopCounter] = name;
				loopCounter++;
			}
			
			String longestString = "";
			int longestLength = 0;
			
			for (loopCounter1 = 0; loopCounter1 < nameArr.length; loopCounter1++)
			{
				if (nameArr [loopCounter1] != null)
				{
					int nameLength = nameArr [loopCounter1].length ();
					
					if (nameLength > longestLength)
					{
						longestLength = nameLength;
						longestString = nameArr [loopCounter1];
					}
				}
			}
			
			System.out.println (longestString);
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
	}
}