/*
Find the maximum difference between two array elements of an array such that larger
element appears after the smaller number. Take input from STDIN.
Example:
Input: arr = {2, 3, 10, 6, 4, 8, 1}
Output: 8
Explanation: The maximum difference is between 10 and 2.
Input: arr = {7, 9, 5, 6, 3, 2}
Output: 2
Explanation: The maximum difference is between 9 and 7.
*/

public class MaxDifferenceInTwoArray
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		String [] arr = inputString.split (",");
		int [] arr2 = new int [10];
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, loopCounter4 = 0, loopCounter5 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < arr.length; loopCounter1++)
		{
			int number = Integer.parseInt (arr [loopCounter1].trim ());
			arr2 [loopCounter2] = number;
			loopCounter2++;
		}
		
		int [] newArray = new int [100];
		
		for (loopCounter3 = 0; loopCounter3 < arr2.length; loopCounter3++)
		{
			for (loopCounter4 = loopCounter3 + 1; loopCounter4 < arr2.length; loopCounter4++)
			{
				if (arr2 [loopCounter3] < arr2 [loopCounter4])
				{
					int difference = arr2 [loopCounter4] - arr2 [loopCounter3];
					newArray [loopCounter5] = difference;
					loopCounter5++;
				}
			}
		}
		
		sort (newArray);
		System.out.println (newArray [0]);
	}
	
	public static void sort (int [] intArray)
	{
		int firstLoopCOunter = 0, secondLoopCOunter = 0;
		
		for (firstLoopCOunter = 0; firstLoopCOunter < intArray.length; firstLoopCOunter++)
		{
			for (secondLoopCOunter = firstLoopCOunter + 1; secondLoopCOunter < intArray.length; secondLoopCOunter++)
			{
				if (intArray [firstLoopCOunter] < intArray [secondLoopCOunter])
				{
					int temp = intArray [firstLoopCOunter];
					intArray [firstLoopCOunter] = intArray [secondLoopCOunter];
					intArray [secondLoopCOunter] = temp;
				}
			}
		}
	}
}