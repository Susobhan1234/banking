import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;

public class NameAndTotalMarks
{
	public static void main (String [] args)
	{
		try
		{
			File fileObj = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Oct12\\MyCollege.txt");
			FileReader readerObj = new FileReader (fileObj);
			BufferedReader bufferObj = new BufferedReader (readerObj);
			
			String lineString = "";
			int loopCounter = 0;
			
			ArrayList studentList = new ArrayList ();
			
			while ((lineString = bufferObj.readLine ()) != null)
			{
				String [] array = lineString.split (",");
				
				String name = array [1];
				String marksString = array [3];
				int marks = Integer.parseInt (marksString);
				
				NameMarks studentObj = new NameMarks ();
				studentObj.setStudentName (name);
				studentObj.setStudentMarks (marks);
				
				studentList.add (studentObj);
			}
			
			for (loopCounter = 0; loopCounter < studentList.size (); loopCounter++)
			{
				NameMarks student = (NameMarks) studentList.get (loopCounter);
				String name = student.getStudentName ();
				
				int index = searchName (studentList, name);
				if (index != -1)
				{
					NameMarks student2 = (NameMarks) studentList.get (index);
					int totalMarks = student2.getTotalMarks ();
					totalMarks = totalMarks + student2.getStudentMarks ();
					student2.setTotalMarks (totalMarks);
				}
			}
			
			for (int loopCounter1 = 0; loopCounter1 < studentList.size (); loopCounter1++)
			{
				NameMarks student = (NameMarks) studentList.get (loopCounter1);
				String name = student.getStudentName ();
				int totalMarks = student.getTotalMarks ();
				
				if (totalMarks != 0)
				{
					System.out.println (name + " " + totalMarks);
				}
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
	}
	
	public static int searchName (ArrayList whereToSearch, String whatToSearch)
	{
		int loopCounter1 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < whereToSearch.size (); loopCounter1++)
		{
			NameMarks temp = (NameMarks) whereToSearch.get (loopCounter1);
			
			if (temp.getStudentName ().equals (whatToSearch))
			{
				return loopCounter1;
			}
		}
		
		return -1;
	}
}