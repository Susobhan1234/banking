public class NameMarks
{
	String studentName;
	int studentMarks;
	int totalMarks;
	
	public void setStudentName (String name)
	{
		studentName = name;
	}
	public String getStudentName ()
	{
		return studentName;
	}
	
	public void setStudentMarks (int marks)
	{
		studentMarks = marks;
	}
	public int getStudentMarks ()
	{
		return studentMarks;
	}
	
	public void setTotalMarks (int totalMarksValue)
	{
		totalMarks = totalMarksValue;
	}
	public int getTotalMarks ()
	{
		return totalMarks;
	}
}