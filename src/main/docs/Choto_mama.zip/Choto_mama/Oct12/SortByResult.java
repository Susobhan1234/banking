import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;

public class SortByResult
{
	public static void main (String [] args)
	{
		try
		{
			File fileObj = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Oct12\\MyCollege.txt");
			FileReader readerObj = new FileReader (fileObj);
			BufferedReader bufferObj = new BufferedReader (readerObj);
			
			String lineString = "";
			ArrayList studentList = new ArrayList ();
			
			while ((lineString = bufferObj.readLine ()) != null)
			{
				String [] arr = lineString.split (",");
				String rollString = arr [0];
				int rollNo = Integer.parseInt (rollString);
				String name = arr [1];
				String subject = arr [2];
				String resultString = arr [3];
				int result = Integer.parseInt (resultString);
				
				StudentDetails studentObj = new StudentDetails ();
				studentObj.setRollNumber (rollNo);
				studentObj.setName (name);
				studentObj.setSubject (subject);
				studentObj.setResult (result);
				
				studentList.add (studentObj);
			}
			
			sortArrayList (studentList);
			
			for (int loopCounter = 0; loopCounter < studentList.size (); loopCounter++)
			{
				StudentDetails studentObj = (StudentDetails) studentList.get (loopCounter);
				System.out.print (studentObj.getRollNumber () + " ");
				System.out.print (studentObj.getName () + " ");
				System.out.print (studentObj.getSubject () + " ");
				System.out.println (studentObj.getResult () + " ");
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
	}
	
	public static void sortArrayList (ArrayList arr)
	{
		int loopCounter1 = 0;
		int loopCounter2 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < arr.size (); loopCounter1++)
		{
			for (loopCounter2 = loopCounter1 + 1; loopCounter2 < arr.size (); loopCounter2++)
			{
				StudentDetails student1 = (StudentDetails) arr.get (loopCounter1);
				StudentDetails student2 = (StudentDetails) arr.get (loopCounter2);
				
				if (student1.getResult () > student2.getResult ())
				{
					StudentDetails temp = student1;
					arr.set (loopCounter1, student2);
					arr.set (loopCounter2, temp);
				}
			}
		}
	}
}