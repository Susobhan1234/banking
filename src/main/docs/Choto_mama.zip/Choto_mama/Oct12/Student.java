public class Student
{
	int rollNumber;
	String studentName;
	String subjectName;
	int studentMarks;
	
	public void setRollNumber (int number)
	{
		rollNumber = number;
	}
	
	public int getRollNumber ()
	{
		return rollNumber;
	}
	
	public void setStudentName (String name)
	{
		studentName = name;
	}
	
	public String getStudentName ()
	{
		return studentName;
	}
	
	public void setSubjectName (String subject)
	{
		subjectName = subject;
	}
	
	public String getSubjectName ()
	{
		return subjectName;
	}
	
	public void setStudentMarks (int marks)
	{
		studentMarks = marks;
	}
	
	public int getStudentMarks ()
	{
		return studentMarks;
	}
}