public class StudentDetails
{
	int rollNumber;
	String name;
	String subject;
	int result;
	
	public void setRollNumber (int roll)
	{
		rollNumber = roll;
	}
	public int getRollNumber ()
	{
		return rollNumber;
	}
	
	public void setName (String studentName)
	{
		name = studentName;
	}
	public String getName ()
	{
		return name;
	}
	
	public void setSubject (String subjectName)
	{
		subject = subjectName;
	}
	public String getSubject ()
	{
		return subject;
	}
	
	public void setResult (int studentResult)
	{
		result = studentResult;
	}
	public int getResult ()
	{
		return result;
	}
}