/*
Find the total sum of odd frequency elements in an array. Take input from STDIN.
Examples:
Input : arr[] = {1, 1, 2, 2, 3, 3, 3}
Output : 9
Explanation : The odd occurring element is 3, and it's number of occurrence is 3.Therefore
sum of all 3's in the array = 9.
Input : arr[] = {10, 20, 30, 40, 40}
Output : 60
Explanation : Elements with odd frequency are 10, 20 and 30. Sum = 60.
*/

public class SumOfOddFrequency
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		String [] arr = inputString.split (",");
		int [] arr2 = new int [10];
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, loopCounter4 = 0, sum = 0;
		
		for (loopCounter1 = 0; loopCounter1 < arr.length; loopCounter1++)
		{
			int number = Integer.parseInt (arr [loopCounter1]);
			arr2 [loopCounter2] = number;
			loopCounter2++;
		}
		
		for (loopCounter3 = 0; loopCounter3 < arr2.length; loopCounter3++)
		{
			int searchNumber = arr2 [loopCounter3];
			int returnValue = search (arr2, searchNumber);
			
			if (returnValue % 2 != 0)
			{
				for (loopCounter4 = 1; loopCounter4 <= returnValue; loopCounter4++)
				{
					sum = sum + searchNumber;
				}
			}
		}
		
		System.out.println (sum);
	}
	
	public static int search (int [] whereToSearch, int whatToSearch)
	{
		int loopCounter = 0, counter = 0;
		
		for (loopCounter = 0; loopCounter < whereToSearch.length; loopCounter++)
		{
			if (whereToSearch [loopCounter] == whatToSearch)
			{
				counter++;
			}
		}
		
		return counter;
	}
}