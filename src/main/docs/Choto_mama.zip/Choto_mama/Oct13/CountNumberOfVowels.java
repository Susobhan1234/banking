/*
Write a program count the number of vowels from the string. Convert it from lower case to
upper case and then reverse the string.
Example:
Input: Information
Output: 5
INFORMATION
NOITAMROFNI
Test Cases:
-----------
1. VALID INPUT:
a) Only one argument will be given as input.
2. INVALID inputs:
a) No argument
b) Two or more than two arguments.
c) Characters other than alphabet.
3. You should generate output as follows:
a) Print to the STDOUT without any additional text.
b) If error print 'ERROR' to the STDOUT without any additional text
*/

public class CountNumberOfVowels
{
	public static void main (String [] args)
	{
		String inputString = "";
		
		if (args.length != 1)
		{
			System.out.println ("Error");
			return;
		}
		
		inputString = args [0];
		
		char [] inputChar = inputString.toCharArray ();
		int loopCounter1 = 0, counter = 0, loopCounter2 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < inputChar.length; loopCounter1++)
		{
			char workingChar = inputChar [loopCounter1];
			
			if ((workingChar == 'a') || (workingChar == 'e') || (workingChar == 'i') || (workingChar == 'o') || (workingChar == 'u'))
			{
				counter++;
			}
			else if ((workingChar == 'A') || (workingChar == 'E') || (workingChar == 'I') || (workingChar == 'O') || (workingChar == 'U'))
			{
				counter++;
			}
		}
		
		System.out.println (counter);
		
		String uppercase = inputString.toUpperCase ();
		char [] newChar = uppercase.toCharArray ();
		System.out.println (uppercase);
		
		for (loopCounter2 = newChar.length - 1; loopCounter2 >= 0; loopCounter2--)
		{
			System.out.print (newChar [loopCounter2]);
		}
	}
}