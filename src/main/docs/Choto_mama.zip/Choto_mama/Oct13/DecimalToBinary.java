/*
Write a program to count the maximum 0’s between two immediate 1’s 
in any binary representation of a given decimal number. Take input from STDIN.
Example:
Input: n = 47
Output: 1
// binary of n = 47 is 101111 Input: n = 549 Output: 3 // binary of n = 549 is 1000100101
*/

public class DecimalToBinary
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		int n = Integer.parseInt (inputString);
		
		int newArray [] = new int [10];
		int loopCounter1 = 0, loopCounter2 = 0; 
		
		for (;;)
		{
			int divisionResult = n / 2;
			int remainder = n % 2;
			
			newArray [loopCounter1] = remainder;
			loopCounter1++;
			
			n = divisionResult;
			
			if (n == 1) 
			{
				newArray [loopCounter1] = 1;
				break;				
			}
		}
		
		for (loopCounter2 = newArray.length - 1; loopCounter2 >= 0; loopCounter2--)
		{
			System.out.print (newArray [loopCounter2]);
		}
	}
}