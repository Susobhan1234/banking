public class Practice
{
	public static void main (String [] args)
	{		
		int loopCounter = 0, loopCounter1 = 0;
		
		for (; ;)
		{
			if (args [loopCounter].equals ("q"))
			{
				break;
			}
			else
			{
				loopCounter1++;
			}
			
			loopCounter++;
		}
		
		String [] arr = new String [loopCounter1];
		
		for (int loopCounter3 = 0; loopCounter3 < loopCounter1; loopCounter3++)
		{
			arr [loopCounter3] = args [loopCounter3];
		}
		
		for (int loopCounter2 = 0; loopCounter2 < arr.length; loopCounter2++)
		{
				System.out.println (arr [loopCounter2]);
		}
	}
}