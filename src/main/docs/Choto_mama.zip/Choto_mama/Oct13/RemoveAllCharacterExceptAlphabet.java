/*
C Program to Remove all Characters in a String except Alphabet and store the resultant string within the same string. 
Change all lower case letters to upper case and then check whether the string is palindrome or not without using library function.
Input String:
In.form,atio1n Tec?hnol-og=y
Output String:
Information Technology // 65 90  97 122
*/

public class RemoveAllCharacterExceptAlphabet
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		char [] charArray = inputString.toCharArray ();
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, loopCounter4 = 0;
		char [] newArray = new char [40];
		String newString = "";
		
		for (loopCounter1 = 0; loopCounter1 < charArray.length; loopCounter1++)
		{
			int asciiValue = charArray [loopCounter1];
			
			if (((asciiValue >= 65) && (asciiValue <= 90)) || ((asciiValue >= 97) && (asciiValue <= 122)) || (charArray [loopCounter1] == ' '))
			{
				newArray [loopCounter2] = charArray [loopCounter1];
				loopCounter2++;
			}
		}
		
		for (loopCounter3 = 0; loopCounter3 < newArray.length; loopCounter3++)
		{
			System.out.print (newArray [loopCounter3]);
		}
		
		System.out.println ("");
		
		for (loopCounter4 = 0; loopCounter4 < newArray.length; loopCounter4++)
		{
			newString = newString + newArray [loopCounter4];
		}
		
		String upperCase = newString.toUpperCase ();
		System.out.println (upperCase);
		
		boolean returnValue = palindrome (upperCase);
		
		if (returnValue == true)
		{
			System.out.println ("Palindrome");
		}
		else
		{
			System.out.println ("Not Palindrome");
		}
	}
	
	public static boolean palindrome (String upperCase)
	{
		int loopCounter5 = 0;
		char [] newCharArray = upperCase.toCharArray ();
		String reverseString = "";
		
		for (loopCounter5 = newCharArray.length -1; loopCounter5 >= 0; loopCounter5--)
		{
			reverseString = reverseString + newCharArray [loopCounter5];
		}
		
		if (reverseString.equals (upperCase))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}