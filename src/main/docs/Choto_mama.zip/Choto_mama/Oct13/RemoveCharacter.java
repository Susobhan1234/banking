/*
C program to remove characters from the first string which are present in the second string. 
Two string will be given as input from command line as first and second argument. You need to remove 
characters from the first string which are present in the second string print it. Take input from command line.
For example:
If input: morzilla mzi
Output: orlla
Test Cases:
-----------
1. VALID INPUT:
a) Only two string will be given as input through command line argument.
2. INVALID INPUT:
a) no command line argument.
b) More than two command line argument
OUTPUT:
a) Write the output to stdout without any other additional text
b) In case of invalid input print 'ERROR' to the STDOUT without any other additional
text and terminate
*/

public class RemoveCharacter
{
	public static void main (String [] args)
	{
		String firstString = args [0];
		String secondString = args [1];
		
		char [] firstCharArray = firstString.toCharArray ();
		char [] secondCharArray = secondString.toCharArray ();
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0;
		char [] newCharArray = new char [20];
		
		for (loopCounter1 = 0; loopCounter1 < firstCharArray.length; loopCounter1++)
		{
			char searchingChar = firstCharArray [loopCounter1];
			String searchingString = "" + searchingChar;
			
			int returnValue = secondString.indexOf (searchingString);
			
			if (returnValue == -1)
			{
				newCharArray [loopCounter2] = searchingChar;
				loopCounter2++;
			}
		}
		
		for (loopCounter3 = 0; loopCounter3 < newCharArray.length; loopCounter3++)
		{
			System.out.print (newCharArray [loopCounter3]);
		}
	}
}