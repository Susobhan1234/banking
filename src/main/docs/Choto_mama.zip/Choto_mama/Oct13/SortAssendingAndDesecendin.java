/*
Given an array of integers, sort the first half of the array in ascending order 
and second half in descending order. Take input from STDIN. If odd number of 
input is given then second half will have even number of elements.
Examples:
Input: arr[] = {5, 2, 4, 7, 9, 3, 1, 6, 8}
Output: arr[] = {1, 2, 3, 4, 9, 8, 7, 6, 5}
Input: arr[] = {1, 2, 3, 4, 5, 6}
Output: arr[] = {1, 2, 3, 6, 5, 4}
*/

public class SortAssendingAndDesecendin
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		String [] arr = inputString.split (",");
		int [] intArray = new int [arr.length];
				
		int [] newArray = new int [arr.length];
		int  loopCounter = 0, counter1 = 0, loopCounter1 = 0, loopCounter2 = 0, counter2 = 0, loopCounter3 = 0, loopCounter4 = 0;
		
		for (loopCounter = 0; loopCounter < arr.length; loopCounter++)
		{
			int number = Integer.parseInt (arr [loopCounter].trim ());
			intArray [counter1] = number;
			counter1++;
		}
		
		ascendingSort (intArray);
		
		for (loopCounter1 = 0; loopCounter1 < intArray.length / 2; loopCounter1++)
		{
			newArray [counter2] = intArray [loopCounter1];
			counter2++;
		}
		
		descendingSort (intArray);
		
		if (intArray.length % 2 == 0)
		{
			for (loopCounter2 = 0; loopCounter2 < intArray.length / 2; loopCounter2++)
			{
				newArray [counter2] = intArray [loopCounter2];
				counter2++;
			}
		}
		else
		{
			for (loopCounter3 = 0; loopCounter3 <= intArray.length / 2; loopCounter3++)
			{
				newArray [counter2] = intArray [loopCounter3];
				counter2++;
			}
		}
		
		for (loopCounter4 = 0; loopCounter4 < newArray.length; loopCounter4++)
		{
			System.out.print (newArray [loopCounter4] + " ");
		}
	}
	
	public static void ascendingSort (int [] intArray)
	{
		int loopCounter1 = 0, loopCounter2 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < intArray.length; loopCounter1++)
		{
			for (loopCounter2 = loopCounter1 + 1; loopCounter2 < intArray.length; loopCounter2++)
			{
				if (intArray [loopCounter1] > intArray [loopCounter2])
				{
					int temp = intArray [loopCounter1];
					intArray [loopCounter1] = intArray [loopCounter2];
					intArray [loopCounter2] = temp;
				}
			}
		}	
	}	
	
	public static void descendingSort (int [] intArray)
	{
		int loopCounter1 = 0, loopCounter2 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < intArray.length; loopCounter1++)
		{
			for (loopCounter2 = loopCounter1 + 1; loopCounter2 < intArray.length; loopCounter2++)
			{
				if (intArray [loopCounter1] < intArray [loopCounter2])
				{
					int temp = intArray [loopCounter1];
					intArray [loopCounter1] = intArray [loopCounter2];
					intArray [loopCounter2] = temp;
				}
			}
		}	
	}	
}