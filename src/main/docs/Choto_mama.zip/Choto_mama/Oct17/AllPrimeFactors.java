/*
Given a number n, write an efficient function to print all prime factors of n whose multiplication is given number n.
For example, if the input number is n=12, then output should be 2 2 3. And if the input
number is n=315, then output should be 3 3 5 7. Take input from command line argument.
Test Cases:
-----------
1. VALID INPUT:
a) Only one argument will be given as input.
2. INVALID inputs:
a) No argument
b) Two or more than two arguments.
c) Characters other than integer
3. You should generate output as follows:
a) Print to the STDOUT without any additional text.
b) If error print 'ERROR' to the STDOUT without any additional text.
*/

public class AllPrimeFactors
{
	public static void main (String [] args)
	{
		String inputString = "";
		
		if (args.length != 1)
		{
			System.out.println ("ERROR");
			return;
		}
		
		try
		{
			inputString = args [0];
			int [] newArr = new int [10];
			int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0;
			
			int number = Integer.parseInt (inputString);
			
			for (loopCounter1 = 2; loopCounter1 < number; loopCounter1++)
			{
				if (number % loopCounter1 == 0)
				{
					int result = number / loopCounter1;
					newArr [loopCounter2] = loopCounter1;
					loopCounter2++;
					number = result;
					loopCounter1 = 1;
				}		
			}
			
			newArr [loopCounter2] = number;
			
			String outputString = "";
			
			for (loopCounter3 = 0; loopCounter3 < newArr.length; loopCounter3++)
			{
				if (newArr [loopCounter3] != 0)
				{
					outputString = outputString + newArr [loopCounter3] + " ";
				}
			}
			
			System.out.println (outputString.trim ());
		}
		
		catch (Exception ex)
		{
			System.out.println ("ERROR");
		}
	}
}