/*
Write a c program to rotate (anti-clockwise) an array arr[] of size n by d elements. Take input from STDIN.
Example:
Input:
arr[] = {1, 2, 3, 4, 5, 6, 7}
d = 2
Output:
arr[] = {3, 4, 5, 6, 7, 1, 2}
*/

import java.util.Scanner;

public class AntiClockwisePrinting
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String numberString = sc.nextLine ();
		String rotateCounterString = sc.nextLine ();
		
		String [] stringArr = numberString.split (", ");
		int rotateCounter = Integer.parseInt (rotateCounterString);
		int loopCounter = 0, loopCounter2 = 0;
		
		String outputString = "";
		
		for (loopCounter = rotateCounter - 1; loopCounter < stringArr.length; loopCounter++)
		{
			outputString = outputString + stringArr [loopCounter] + ", ";
		}
		
		for (loopCounter2 = 0; loopCounter2 < rotateCounter; loopCounter2++)
		{
			if (loopCounter2 == rotateCounter - 1)
			{
				outputString = outputString + stringArr [loopCounter2];
			}
			else
			{
				outputString = outputString + stringArr [loopCounter2] + ", ";
			}
		}
		
		System.out.println (outputString);
	}
}