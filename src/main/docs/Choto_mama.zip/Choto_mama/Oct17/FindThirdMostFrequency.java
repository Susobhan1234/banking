/*
Given a string, find the third most frequent character in it. 
If two character having the same frequency then print any of them. 
Take input from STDIN.
Examples:
Input: str = "aacbabacba";
Output: 'c'
*/
import java.util.Scanner;

public class FindThirdMostFrequency
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String inputString = sc.nextLine ();
		
		char [] charArray = inputString.toCharArray ();
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, loopCounter = 0, loopCounter5 = 0;
		int [] intArray = new int [10];
		
		for (loopCounter1 = 0; loopCounter1 < charArray.length; loopCounter1++)
		{
			char searchingChar = charArray [loopCounter1]; 
			
			int returnValue = searchCharInCharArray (charArray, searchingChar);
			
			boolean returnType = searchInteger (intArray, returnValue);
			
			if (returnType == false)
			{
				intArray [loopCounter2] = returnValue;
				loopCounter2++;
			}
		}
		
		sortIntArray (intArray); 
		
		for (loopCounter5 = 0; loopCounter5 < charArray.length; loopCounter5++)
		{
			char searchingChar = charArray [loopCounter5];
			
			int returnValue = searchCharInCharArray (charArray, searchingChar);
			
			if (returnValue == intArray [2])
			{
				System.out.println (searchingChar);
				break;
			}
		}		
	}
	
	public static int searchCharInCharArray (char [] whereToSearch, char whatToSearch)
	{
		int loopCounter = 0, counter = 0;
		
		for (loopCounter = 0; loopCounter < whereToSearch.length; loopCounter++)
		{
			if (whereToSearch [loopCounter] == whatToSearch)
			{
				counter++;
			}
		}
		
		return counter;
	}
	
	public static void sortIntArray (int [] intArray)
	{
		int loopCounter1 = 0, loopCounter2 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < intArray.length; loopCounter1++)
		{
			for (loopCounter2 = loopCounter1 + 1; loopCounter2 < intArray.length; loopCounter2++)
			{
				if (intArray [loopCounter1] < intArray [loopCounter2])
				{
					int temp = intArray [loopCounter1];
					intArray [loopCounter1] = intArray [loopCounter2];
					intArray [loopCounter2] = temp;
				}
			}
		}
	}
	
	public static boolean searchInteger (int [] whereToSearch, int whatToSearch)
	{
		int loopCounter = 0;
		
		for (loopCounter = 0; loopCounter < whereToSearch.length; loopCounter++)
		{
			if (whereToSearch [loopCounter] == whatToSearch)
			{
				return true;
			}
		}
		
		return false;
	}
}