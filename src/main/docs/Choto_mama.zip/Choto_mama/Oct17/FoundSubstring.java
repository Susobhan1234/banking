/*
Finding out whether a substring is present in a given string or not. Take input from command line argument.
Example:
Input:
Original string: Abcdabxabxaycdy
Substring: abxay
Output: Present
Input:
Original string: Abcdabxabxaycdy
Substring: abxayd
Output: Not Present
*/


public class FoundSubstring
{
	public static void main (String [] args)
	{
		String firstInputString = args [0];
		String secondInputString = args [1];
		int indexValue = (firstInputString.indexOf (secondInputString));
		
		if (indexValue != -1)
		{
			System.out.println ("Present");
		}
		else
		{
			System.out.println ("Not Present");
		}
	}
}