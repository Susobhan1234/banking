/*
Write a C program to display all the unique (non-redundant) elements of an array. Take input from STDIN.
Example:
Input:
arr[]={2,1,2,3,4,1}
Output:
3, 4
*/

import java.util.Scanner;

public class NonRedundant
{
	public static void main (String [] args)
	{
		int intArr [] = new int [6];
		
		int loopCounter = 0;
		
		for (; ; )
		{
			Scanner sc = new Scanner (System.in);
			String inputString = sc.nextLine ();
			int number = Integer.parseInt (inputString);
			
			intArr [loopCounter] = number;
			loopCounter++;
			
			if (loopCounter == 6)
			{
				break;
			}
		}
		
		for (loopCounter = 0; loopCounter < intArr.length; loopCounter++)
		{
			int searchingNumber = intArr [loopCounter];
			int returnValue = searchingNumberInArray (intArr, searchingNumber);
			
			if (returnValue == 1)
			{
				System.out.println (searchingNumber);
			}
		}
	}
	
	public static int searchingNumberInArray (int [] whereToSearch, int whatToSearch)
	{
		int loopCounter1 = 0, counter = 0;
		
		for (loopCounter1 = 0; loopCounter1 < whereToSearch.length; loopCounter1++)
		{
			if (whereToSearch [loopCounter1] == whatToSearch)
			{
				counter++;
			}
		}
		
		return counter;
	}
}