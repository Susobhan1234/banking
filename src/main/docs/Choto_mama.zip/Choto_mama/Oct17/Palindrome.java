/*
Check whether a given string Palindrome or not. Take input from command line.
Test Cases:
-----------
1. VALID INPUT:
a) Only one string will be given as input through command line argument.
2. INVALID INPUT:
a) No command line argument.
b) More than one command line argument
3. OUTPUT:
a) Write YES to stdout without any other additional text if string is palindrome.
b) Write NO to stdout without any other additional text if string is not palindrome.
c) In case of invalid input print ERROR to the STDOUT without any other additional
text.
*/

public class Palindrome
{
	public static void main (String [] args)
	{
		String inputString = "";
		
		if (args.length != 1)
		{
			System.out.println ("ERROR");
			return;
		}
		
		inputString = args [0];
		char [] charArray = inputString.toCharArray ();
		
		int loopCounter = 0;

		String reverseString = "";
			
		for (loopCounter = charArray.length - 1; loopCounter >= 0; loopCounter--)
		{
			reverseString = reverseString + charArray [loopCounter];
		}
		
		if (reverseString.equals (inputString))
		{
			System.out.println ("Yes");
		}
		else
		{
			System.out.println ("No");
		}
	}
}
