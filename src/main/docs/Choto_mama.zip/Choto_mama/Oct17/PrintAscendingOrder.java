import java.util.Scanner;

public class PrintAscendingOrder
{
	public static void main (String [] args)
	{
		String [] stringArray = new String [10];
		double [] doubleArray = new double [10];
		int loopCounter = 0, loopCounter2 = 0, loopCounter3 = 0, newLoopCounter = 0;
		
		for (; ; )
		{
			Scanner sc = new Scanner (System.in);
			String inputString = sc.nextLine ();
			newLoopCounter++;
			
			if (newLoopCounter == 10)
			{
				break;
			}
			else
			{
				stringArray [loopCounter] = inputString;
				loopCounter++;
			}
		}
		
		for (int loopCounter1 = 0; loopCounter1 < stringArray.length; loopCounter1++)
		{
			if (stringArray [loopCounter1] != null)
			{
				double number = Double.parseDouble (stringArray [loopCounter1]);
				doubleArray [loopCounter2] = number;
				loopCounter2++;
			}
		}
		
		sortingArray (doubleArray);
		
		for (loopCounter3 = 0; loopCounter3 < doubleArray.length; loopCounter3++)
		{
			if (doubleArray [loopCounter3] != 0)
			{
				System.out.println (doubleArray [loopCounter3]);
			}
		}
	}
	
	public static void sortingArray (double [] arr)
	{
		int loopCounter = 0, loopCounter1 = 0;
		
		for (loopCounter = 0; loopCounter < arr.length; loopCounter++)
		{
			for (loopCounter1 = loopCounter + 1; loopCounter1 < arr.length; loopCounter1++)
			{
				if (arr [loopCounter] > arr [loopCounter1])
				{
					double temp = arr [loopCounter];
					arr [loopCounter] = arr [loopCounter1];
					arr [loopCounter1] = temp;
				}
			}
		}
	}
}