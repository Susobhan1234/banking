public class PrintInputArgs
{
	public static void main (String [] args)
	{
		int loopCounter = 0, loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0;
		
		for (; ;)
		{
			if (args [loopCounter].equals ("q"))
			{
				break;
			}
			else
			{
				loopCounter1++;
			}
			
			loopCounter++;
		}
		
		String [] arr = new String [loopCounter1];
		
		for (loopCounter2 = 0; loopCounter2 < loopCounter1; loopCounter2++)
		{
			arr [loopCounter3] = args [loopCounter2];
			loopCounter3++;
		}
		
		for (int loopCounter4 = 0; loopCounter4 < loopCounter1; loopCounter4++)
		{
			System.out.println (arr [loopCounter4]);
		}
	}
}