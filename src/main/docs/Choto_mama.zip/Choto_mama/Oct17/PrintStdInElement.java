import java.util.Scanner;

public class PrintStdInElement
{
	public static void main (String [] args)
	{
		int loopCounter1 = 0;
		String [] arr = new String [10000];
		
		for (; ;)
		{
			Scanner sc = new Scanner (System.in);
			String inputString = sc.nextLine ();
			
			if (inputString.equals ("q"))
			{
				break;
			}
			else
			{
				arr [loopCounter1] = inputString;
				loopCounter1++;
			}
		}
		
		for (int loopCounter2 = 0; loopCounter2 < loopCounter1; loopCounter2++)
		{
			System.out.println (arr [loopCounter2]);
		}
	}
}