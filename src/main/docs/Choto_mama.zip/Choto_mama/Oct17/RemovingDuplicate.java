/*
Write a C program to display all the array elements in ascending order 
after removing duplicate elements. Take input from STDIN.
Example:
Input:
arr[]={2, 1, 2, 3, 4, 1}
Output:
1, 2, 3, 4
*/

import java.util.Scanner;

public class RemovingDuplicate
{
	public static void main (String [] args)
	{		
		int [] intArr = new int [6];
		int [] newArr = new int [6];
		int counter = 0, loopCounter = 0, loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0;
		
		for (; ; )
		{
			Scanner sc = new Scanner (System.in);
			String inputString = sc.nextLine ();
			counter++;
			
			if (counter == 6)
			{
				break;
			}
			else
			{
				intArr [loopCounter] = Integer.parseInt (inputString);
				loopCounter++;
			}
		}
		
		for (loopCounter1 = 0; loopCounter1 < intArr.length; loopCounter1++)
		{
			int searchingNumber = intArr [loopCounter1];
			boolean returnValue = searchInIntArray (newArr, searchingNumber);
			
			if (returnValue == false && searchingNumber != 0)
			{
				newArr [loopCounter3] = searchingNumber;
				loopCounter3++;
			}
		}
		
		sortIntArray (newArr);
		
		String outputString = "";
		
		for (loopCounter2 = 0; loopCounter2 < newArr.length; loopCounter2++)
		{
			if (newArr [loopCounter2] != 0)
			{
				if (loopCounter2 == newArr.length - 1)
				{
					outputString = outputString + (newArr [loopCounter2]);
				}
				else
				{
					outputString = outputString + (newArr [loopCounter2] + ", ");
				}
			}
		}
		
		System.out.println (outputString);
	}
	
	public static boolean searchInIntArray (int [] whereToSearch, int whatToSearch)
	{
		int loopCounter1 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < whereToSearch.length; loopCounter1++)
		{
			if (whereToSearch [loopCounter1] == whatToSearch)
			{
				return true;
			}
		}
		
		return false;
	}
	
	public static void sortIntArray (int [] arr)
	{
		int loopCounter = 0, loopCounter1 = 0;
		
		for (loopCounter = 0; loopCounter < arr.length; loopCounter++)
		{
			for (loopCounter1 = loopCounter + 1; loopCounter1 < arr.length; loopCounter1++)
			{
				if (arr [loopCounter] > arr [loopCounter1])
				{
					int temp = arr [loopCounter];
					arr [loopCounter] = arr [loopCounter1];
					arr [loopCounter1] = temp;
				}
			}
		}
	}
}
