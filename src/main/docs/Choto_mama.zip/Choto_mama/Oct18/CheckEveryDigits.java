/*
Write a program to check for a given integer, every digit and its neighbor digit differs by +1 or -
1. Take input from STDIN and display output Yes or No to STDOUT without any additional
text.
Examples:
Input:
7878
Output:
Yes
Input:
4554
Output:
No
*/

import java.util.Scanner;

public class CheckEveryDigits
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String inputString = sc.nextLine ();
		char [] charArr = inputString.toCharArray ();
		int [] intArr = new int [charArr.length];
		int loopCounter1 = 0, loopCounter2 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < charArr.length; loopCounter1++)
		{
			String newString = "" + charArr [loopCounter1];
			int newInt = Integer.parseInt (newString);
			intArr [loopCounter2] = newInt;
			loopCounter2++;
		}
		
		boolean returnValue = checkEveryNumberInArray (intArr);
		
		if (returnValue == true)
		{
			System.out.println ("Yes");
		}
		else
		{
			System.out.println ("No");
		}
	}
	
	public static boolean checkEveryNumberInArray (int [] intArr)
	{
		int loopCounter1 = 0;
		
		for (loopCounter1 = 1; loopCounter1 < intArr.length - 1; loopCounter1++)
		{
			int nextDigit = intArr [loopCounter1 + 1];
			int previousDigit = intArr [loopCounter1 - 1];
			
			if (((nextDigit == intArr [loopCounter1] + 1) || (nextDigit == intArr [loopCounter1] - 1)) && 
		    ((previousDigit == intArr [loopCounter1] + 1) || (previousDigit == intArr [loopCounter1] - 1)))
			{
				return true;
			}
		}
		
		return false;
	}
}

//55min