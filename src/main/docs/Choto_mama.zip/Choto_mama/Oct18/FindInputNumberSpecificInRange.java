/*
Write a program to find all the numbers within a specific range which contain the given digit d.
Take input from STDIN and display output to STDOUT without any additional text.
Example:
Input:
n1=5 n2=50 d=5
Output:
5 15 25 35 45 50
*/

import java.util.Scanner;

public class FindInputNumberSpecificInRange
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String firstInputString = sc.nextLine ();
		int n1 = Integer.parseInt (firstInputString);
		
		String secondInputString = sc.nextLine ();
		int n2 = Integer.parseInt (secondInputString);
		
		/*
		String thirdInputString = sc.nextLine ();
		int number = Integer.parseInt (thirdInputString);
		char d = (char)number;
		*/
		
		char d = '5';
		
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, loopCounter4 = 0;
		int [] intArr = new int [1000];
		
		boolean returnValue = false;
		
		for (loopCounter1 = n1; loopCounter1 <= n2; loopCounter1++)
		{
			String newString = "" + loopCounter1;
			char [] charArr = newString.toCharArray ();
			
			for (loopCounter2 = 0; loopCounter2 < charArr.length; loopCounter2++)
			{
				returnValue = search (charArr, d);
			}
			
			if (returnValue == true)
			{
				intArr [loopCounter4] = loopCounter1;
				loopCounter4++;
			}
		}
		
		for (loopCounter3 = 0; loopCounter3 < intArr.length; loopCounter3++)
		{
			if (intArr [loopCounter3] != 0)
			{
				System.out.print (intArr [loopCounter3] + " ");
			}
		}
	}
	
	public static boolean search (char [] whereToSearch, char whatToSearch)
	{
		int loopCounter1 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < whereToSearch.length; loopCounter1++)
		{
			if (whereToSearch [loopCounter1] == whatToSearch)
			{
				return true;
			}
		}
		
		return false;
	}
}

//1.20 hour