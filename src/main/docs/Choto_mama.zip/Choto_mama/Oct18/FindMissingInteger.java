/*
You are given a list of n-1 integers and these integers are in the range of 1 to n. There are no
duplicates in list. One of the integers is missing in the list. Write an efficient code to find the
missing integer. Take input from STDIN and display output to STDOUT without any additional
text.
Example:
Input:
{1, 2, 5, 6, 3, 4, 8}
Output:
7
*/

import java.util.Scanner;
import java.util.Arrays;

public class FindMissingInteger
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String inputString = sc.nextLine ();
		
		String [] stringArr = inputString.split (", ");
		
		int loopCounter = 0, counter = 0, loopCounter1 = 0, loopCounter2 = 0;
		String newString = "";
		
		int [] intArray = new int [stringArr.length];
		
		for (loopCounter = 0; loopCounter < stringArr.length; loopCounter++)
		{
			newString = stringArr [loopCounter];
			int number = Integer.parseInt (newString);
			intArray [counter] = number;
			counter++;
		}
		
		Arrays.sort (intArray);
		int lastNumber = intArray [intArray.length - 1];
		int firstNumber = intArray [0];
		int counters = 0;
		
		for (loopCounter1 = firstNumber; loopCounter1 < lastNumber; loopCounter1++) // 124
		{
			if (intArray [counters] != loopCounter1)
			{
				System.out.println (loopCounter1);
			}
			
			counters++;
		}
	}
}