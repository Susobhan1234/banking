/*
Write a program to count the number of prime numbers formed by removing digits from that
number from the back. (Including the number itself) Take input from STDIN and display output
to STDOUT without any additional text.
Example:
Input:
135
Output:
1
Explanation: 135 is not prime, 13 (by removing 5 from last) is prime, but 1 is not prime
*/

import java.util.Scanner;

public class FoundPrimeNumber
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String inputString = sc.nextLine ();
		char [] charArr = inputString.toCharArray ();
		int loopCounter1 = 0, loopCounter2 = 0;
		String newString = "";
		int counter = 0;
		
		for (loopCounter1 = 0; loopCounter1 < charArr.length; loopCounter1++)
		{
			newString = "";
			
			for (loopCounter2 = 0; loopCounter2 < charArr.length - loopCounter1; loopCounter2++)
			{
				newString = newString + charArr [loopCounter2];
			}
			
			int number = Integer.parseInt (newString);
			boolean returnValue = primeCheck (number);
			
			if (returnValue == false)
			{
				//System.out.print (number + " ");
				
				counter++;
			}
		}
		
		System.out.println (counter);
	}
	
	public static boolean primeCheck (int number)
	{
		if (number == 1)
		{
			return true;
		}
		
		for (int loopCounter1 = 2; loopCounter1 < number; loopCounter1++)
		{
			if (number % loopCounter1 == 0)
			{
				return true;
			}
		}
		
		return false;
	}
}