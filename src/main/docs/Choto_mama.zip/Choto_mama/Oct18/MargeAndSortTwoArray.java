/*
Write a C program to merge two sorted array such that the output will be in sorted order. Take input from STDIN.
Example:
Input:
arr1[] = {1,3,4,5}
arr2[] = {-5,0,2,4}
Output:
{-5,0,1,2,3,4,4,5}
*/

import java.util.Scanner;
import java.util.Arrays;

public class MargeAndSortTwoArray
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String firstInputString = sc.nextLine ();
		String [] firstInputArr = firstInputString.split (",");
		String secondInputString = sc.nextLine ();
		String [] secondInputArr = secondInputString.split (",");
		String outputString = "";
		
		int [] newArray = new int [firstInputArr.length + secondInputArr.length];
		int loopCounter1 = 0, loopCounter2 = 0, counter = 0, loopCounter3 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < firstInputArr.length; loopCounter1++)
		{
			int number = Integer.parseInt (firstInputArr [loopCounter1]);
			newArray [counter] = number;
			counter++;
		}
		
		for (loopCounter2 = 0; loopCounter2 < secondInputArr.length; loopCounter2++)
		{
			int number = Integer.parseInt (secondInputArr [loopCounter2]);
			newArray [counter] = number;
			counter++;
		}
		
		Arrays.sort (newArray);
		
		for (loopCounter3 = 0; loopCounter3 < newArray.length; loopCounter3++)
		{
			if (loopCounter3 == newArray.length - 1)
			{
				outputString = outputString + newArray [loopCounter3];
			}
			else
			{
				outputString = outputString + newArray [loopCounter3] + ",";
			}
		}
		
		System.out.println (outputString);
	}
}