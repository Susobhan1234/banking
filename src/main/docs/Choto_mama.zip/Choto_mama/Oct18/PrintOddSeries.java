import java.util.Scanner;

public class PrintOddSeries
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String inputString = sc.nextLine ();
		
		int number = Integer.parseInt (inputString);
		int loopCounter = 0, value = 0;
		
		for (loopCounter = 1; loopCounter <= number; loopCounter++)
		{
			value = (2 * loopCounter) - 1;
			
			if (loopCounter == number)
			{
				System.out.println (value);
			}
		}
	}
}