// A number series reperesented as 0,2,4,6,8,....... take input from std in, print the the n th term n is accepte from the user

import java.util.Scanner;

public class PrintSeries
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String inputString = sc.nextLine ();
		
		int number = Integer.parseInt (inputString);
		int loopCounter = 0, value = 0, counter = 0;
		
		for (loopCounter = 1; loopCounter <= number; loopCounter++)
		{
			value = counter * 2;
			counter++;
			
			if (loopCounter == number)
			{
				System.out.print (value);
			}
		}
	}
}