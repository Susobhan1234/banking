/*
Given two arrays, print all elements in sorted order that are not common of these arrays. 
Take input from STDIN and display output to STDOUT without any additional text.
Example:
Input:
arr1[] = {3, 1, 5, 6, 11}
arr2[] = {5, 3, 7, 8}
Output:
{1, 6, 7, 8, 11}
*/

import java.util.Scanner;

public class SortTwoArrayWithoutCommon
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String firstInputString = sc.nextLine ();
		String [] firstInputStringArray = firstInputString.split (", ");
		String secondInputString = sc.nextLine ();
		String [] secondInputStringArray = secondInputString.split (", ");
		String outputString = "";
		
		int [] newIntArray = new int [firstInputStringArray.length + secondInputStringArray.length];
		int loopCounter1 = 0, loopCounter2 = 0, counter = 0;
		
		for (loopCounter1 = 0; loopCounter1 < firstInputStringArray.length; loopCounter1++)
		{
			int number = Integer.parseInt (firstInputStringArray [loopCounter1]);
			
			boolean returnValue = searchNumber (newIntArray, number);
			
			if (returnValue == false)
			{
				newIntArray [counter] = number;
				counter++;
			}
		}
		
		for (loopCounter2 = 0; loopCounter2 < secondInputStringArray.length; loopCounter2++)
		{
			int number = Integer.parseInt (secondInputStringArray [loopCounter2]);
			
			boolean returnValue = searchNumber (newIntArray, number);
			
			if (returnValue == false)
			{
				newIntArray [counter] = number;
				counter++;
			}
		}
		
		sortIntArray (newIntArray);
		
		for (int loopCounter3 = 0; loopCounter3 < newIntArray.length; loopCounter3++)
		{
			if (newIntArray [loopCounter3] != 0)
			{
				if (loopCounter3 == newIntArray.length - 1)
				{
					outputString = outputString + newIntArray [loopCounter3];
				}
				else
				{
					outputString = outputString + newIntArray [loopCounter3] + ", ";
				}
			}
		}
		
		System.out.println (outputString);
	}
	
	public static boolean searchNumber (int [] whereToSearch, int whatToSearch)
	{
		for (int loopCounter1 = 0; loopCounter1 < whereToSearch.length; loopCounter1++)
		{
			if (whereToSearch [loopCounter1] == whatToSearch)
			{
				return true;
			}
		}
		
		return false;
	}
	
	public static void sortIntArray (int [] arr)
	{
		int loopCounter1 = 0, loopCounter2 =0;
		
		for (loopCounter1 = 0; loopCounter1 < arr.length; loopCounter1++)
		{
			for (loopCounter2 = loopCounter1 + 1; loopCounter2 < arr.length; loopCounter2++)
			{
				if (arr [loopCounter1] > arr [loopCounter2])
				{
					int temp = arr [loopCounter1];
					arr [loopCounter1] = arr [loopCounter2];
					arr [loopCounter2] = temp;
				}
			}
		}
	}
}