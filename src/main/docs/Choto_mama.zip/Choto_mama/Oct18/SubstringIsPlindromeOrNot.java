/*
You are given a string S, and a number K. Write a c code to find all K length substrings which
are palindrome. Take input from command line.
Constraint:
2 <= K <= Length(S)
Example:
Input:
academy
3
Output:
aca
Test Cases:
-----------
1. VALID INPUT:
a) Only two arguments will be given as input.
2. INVALID inputs:
a) No argument
b) One or more than two arguments.
c) Non-integer second argument
3. You should generate output as follows:
a) Print to the STDOUT without any additional text.
b) If error print 'ERROR' to the STDOUT without any additional text.
*/

public class SubstringIsPlindromeOrNot
{
	public static void main (String [] args)
	{
		String firstInputString = "";
		String secondInputString = "";
		
		if (args.length != 2)
		{
			System.out.println ("ERROR");
			return;
		}
		
		firstInputString = args [0];
		char [] charArray = firstInputString.toCharArray ();
		
		secondInputString = args [1];
		int lengthOfSubstring = Integer.parseInt (secondInputString);
		int loopCounter1 = 0, loopCounter2 = 0;
		String newString = "";
		
		for (loopCounter1 = 0; loopCounter1 <= charArray.length - lengthOfSubstring; loopCounter1++)
		{
			newString = "";
			
			for (loopCounter2 = loopCounter1; loopCounter2 < loopCounter1 + lengthOfSubstring; loopCounter2++)
			{
				newString = newString + charArray [loopCounter2];
			}
		
			boolean returnValue = palindromeCheck (newString);
			
			if (returnValue == true)
			{
				System.out.println (newString);
			}
		}
	}
	
	public static boolean palindromeCheck (String newString)
	{
		char [] newCharArray = newString.toCharArray ();
		int loopCounter = 0;
		String reverseString = "";
		
		for (loopCounter = newCharArray.length - 1; loopCounter >= 0; loopCounter--)
		{
			reverseString = reverseString + newCharArray [loopCounter];
		}
		
		if (reverseString.equals (newString))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}