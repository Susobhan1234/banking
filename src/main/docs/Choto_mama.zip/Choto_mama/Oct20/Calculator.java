import java.util.Scanner;

public class Calculator
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String firstInput = sc.nextLine ();
		double x = Double.parseDouble (firstInput);
		String secondInput = sc.nextLine ();
		double y = Double.parseDouble (secondInput);
		System.out.println ("Sum of two no. is : " + (x+y));
		System.out.println ("Sub of two no. is : " + (x-y));
		System.out.println ("Mult of two no. is : " + (x*y));
		System.out.println ("Div of two no. is : " + (x/y));
	}
}