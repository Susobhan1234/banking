/*
program to display characters from A to Z using loop
*/

public class DisplayAToZ
{
	public static void main (String [] args)
	{
		int loopCounter = 0;
		
		for (loopCounter = 65; loopCounter <= 90; loopCounter++)
		{
			int ascciValue = loopCounter;
			char charValue = (char) ascciValue;
			System.out.println (charValue + " ");
		}
	}
}