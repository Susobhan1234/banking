/*
program to display the sequence 1, 2, 2, 4, 8, 32, 256,……………….
*/

import java.util.Scanner;

public class DisplaySequence
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String inputString = sc.nextLine ();
		int range = Integer.parseInt (inputString);

		int loopCounter = 0, firstNumber = 1, secondNumber = 2;
		
		System.out.print (firstNumber + " " + secondNumber + " ");
		
		for (loopCounter = 3; loopCounter <= range; loopCounter++)
		{
			int number = firstNumber * secondNumber;
			firstNumber = secondNumber; 
			secondNumber = number;
			
			System.out.print (number + " ");
		}
	}
}