/*
C program to display the sequence 1, 4, 9, 16, 25, 36, 49,………………
*/

import java.util.Scanner;

public class DisplaySequence2
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String inputString = sc.nextLine ();
		int range = Integer.parseInt (inputString);
		
		int loopCounter = 0;
		
		for (loopCounter = 1; loopCounter <= range; loopCounter++)
		{
			int number = loopCounter * loopCounter;
			if (loopCounter == range)
			{
				System.out.print (number);
			}
			else
			{
				System.out.print (number + ", ");
			}
		}
	}
}