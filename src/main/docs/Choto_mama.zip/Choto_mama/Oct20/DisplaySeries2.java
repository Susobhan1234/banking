/*
program to display the series 0,0,2,1,4,2,6,3,8,4
*/
import java.util.Scanner;

public class DisplaySeries2
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String inputString = sc.nextLine ();
		int range = Integer.parseInt (inputString);

	
		int loopCounter1 = 0, loopCounter2 = 0, value1 = 1, value2 = 1;
		
		System.out.print ("0 ");
		System.out.print ("0 ");
		
		for (loopCounter1 = 1; loopCounter1 <= range; loopCounter1++)
		{
			value1 = loopCounter1 * 2;
			value2 = loopCounter1 * 1;
			System.out.print (value1 + " " + value2 + " ");
		}
	}
}x