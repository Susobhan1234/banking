/*
program to find factorial of a number.
*/

import java.util.Scanner;

public class Factorial
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String inputString = sc.nextLine ();
		
		int number = Integer.parseInt (inputString);
		
		int loopCounter = 0, factorial = 1;
		
		for (loopCounter = 1; loopCounter <= number; loopCounter++)
		{
			factorial = factorial * loopCounter;
		}
		
		System.out.println (factorial);
	}
}