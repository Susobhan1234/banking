import java.util.Scanner;

public class FactorialPractice
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String inputString = sc.nextLine ();
		
		int number = Integer.parseInt (inputString);
		
		int factorial = 1;
		
	}
	
	public static void factorial (int number, int factorial)
	{
		int loopCounter = 0;
		
		for (loopCounter = 1; loopCounter <= number; loopCounter++)
		{
			factorial = factorial * loopCounter;
		}
	}
}