/*
program to calculate the power of a number
*/

import java.util.Scanner;

public class PowerOfANumber
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String firstInputString = sc.nextLine ();
		int firstNumber = Integer.parseInt (firstInputString);
		
		String secondInputString = sc.nextLine ();
		int secondNumber = Integer.parseInt (secondInputString);
		
		int power = 1;
		
		int loopCounter = 0;
		
		for (loopCounter = 1; loopCounter <= secondNumber; loopCounter++)
		{
			power = power * firstNumber;
		}
		
		System.out.println (power);
	}
}