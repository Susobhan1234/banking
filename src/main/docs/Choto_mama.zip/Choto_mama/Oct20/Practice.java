public class Practice
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		String [] stringArr = inputString.split (" ");
		System.out.println ("Number of word is : " + stringArr.length);
		char [] inputChar = inputString.toCharArray ();
		int loopCounter = 0, counter = 0;
		int ascciValue = ' ';
		
		for (loopCounter = 0; loopCounter < inputChar.length; loopCounter++)
		{
			int newValue = inputChar [loopCounter];
			
			if (newValue == ascciValue)
			{
				counter++;
			}
		}
		
		System.out.println ("Number of space is : " + counter);
	}
}