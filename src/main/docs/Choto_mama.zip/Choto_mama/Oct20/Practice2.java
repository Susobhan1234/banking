import java.util.Scanner;

public class Practice2
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String inputString = sc.nextLine ();
		
		String [] stringArr = inputString.split (" ");
		System.out.println ("Number of word is : " + stringArr.length);
		
		char [] inputChar = inputString.toCharArray ();
		int loopCounter = 0, counter = 0;
		
		for (loopCounter = 0; loopCounter < inputChar.length; loopCounter++)
		{			
			if (inputChar [loopCounter] == ' ')
			{
				counter++;
			}
		}
		
		System.out.println ("Number of space is : " + counter);
	}
}