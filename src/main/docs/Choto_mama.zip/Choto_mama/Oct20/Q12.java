/*
program to display the sequence 7, 10, 8, 11, 9, 12,
*/

import java.util.Scanner;

public class Q12
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String inputString = sc.nextLine ();
		int range = Integer.parseInt (inputString);
		
		int loopCounter = 0, firstNumber = 7;
		
		for (loopCounter = 1; loopCounter <= range / 2; loopCounter++)
		{
			firstNumber = firstNumber;
			int secondNumber = firstNumber + 3;
			
			System.out.print (firstNumber + " "+ secondNumber + " ");
			firstNumber = firstNumber + 1;
		}
	}
}