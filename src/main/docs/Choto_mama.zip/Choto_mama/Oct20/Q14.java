// program to display the sequence 1, 1, 5, 5, 9, 9, 13, 13, ………………………


import java.util.Scanner;

public class Q14
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String inputString = sc.nextLine ();
		int range = Integer.parseInt (inputString);
		
		int loopCounter = 0, number = 1;
		System.out.print (number + " " + number + " ");
		
		for (loopCounter = 2; loopCounter <= range / 2; loopCounter++)
		{
			number = number + 4;
			System.out.print (number + " " + number + " ");
		}
	}
}