import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;

public class CompareTwoFile
{
	public static void main (String [] args)
	{
		try 
		{
			File firstFileObj = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Oct31\\StudentDetails.txt");
			File secondFileObj = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Oct31\\StudentOutput.txt");
			FileReader readerObj = new FileReader (firstFileObj);
			FileReader firstReaderObj = new FileReader (firstFileObj);
			FileReader secondReaderObj = new FileReader (secondFileObj);
			BufferedReader firstBufferObj = new BufferedReader (firstReaderObj);
			BufferedReader secondBufferObj = new BufferedReader (secondReaderObj);
			
			String firstLineString = "";
			String secondLineString = "";
			boolean flag = false;
			String [] firstFileDataArray = new String [1000];
			String [] secondFileDataArray = new String [1000];
			int counter = 0,counter1 = 0, loopCounter = 0;
			
			while ((firstLineString = firstBufferObj.readLine ()) != null)
			{
				firstFileDataArray [counter] = firstLineString;
				counter++;
			}
			
			while ((secondLineString = secondBufferObj.readLine ()) != null)
			{
				secondFileDataArray [loopCounter] = secondLineString;
				loopCounter++;
			}
			
			for (int loopCounter2 = 0; loopCounter2 < firstFileDataArray.length; loopCounter2++)
			{
				if (firstFileDataArray[loopCounter2] != null)
				{
					boolean returnValue = searchInsideArray (secondFileDataArray, firstFileDataArray[loopCounter2]);
					
					if (returnValue == false)
					{
						counter1++;
					}
				}
			}
			
			if (counter1 > 0)
			{
				System.out.print ("Data not mached");
			}
			else
			{
				System.out.print ("Data mached");
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
	}
	
	public static boolean searchInsideArray (String [] whereToSearch, String whatToSearch)
	{
		int loopCounter1 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < whereToSearch.length; loopCounter1++)
		{
			if (whereToSearch [loopCounter1] != null)
			{
				if (whereToSearch [loopCounter1].equals (whatToSearch))
				{
					return true;
				}
			}
		}
		
		return false;
	}
}