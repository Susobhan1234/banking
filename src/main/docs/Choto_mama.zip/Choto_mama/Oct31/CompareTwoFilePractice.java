import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;


public class CompareTwoFilePractice
{
	public static void main (String [] args)
	{
		try
		{
			File firstFileObj = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Oct31\\StudentDetails.txt");
			FileReader firstReaderObj = new FileReader (firstFileObj);
			BufferedReader firstBufferObj = new BufferedReader (firstReaderObj);
			
			File secondFileobj = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Oct31\\StudentOutput.txt");
			FileReader secondReaderObj = new FileReader (secondFileobj);
			BufferedReader secondBufferObj = new BufferedReader (secondReaderObj);
			
			String firstLineString = "";
			String secondLineString = "";
			
			String [] firstFileDataArray = new String [100];
			String [] secondFileDataArray = new String [100];
			
			int counter1 = 0, counter2 = 0, counter3 = 0;
			
			while ((firstLineString = firstBufferObj.readLine ()) != null)
			{
				firstFileDataArray [counter1] = firstLineString;
				counter1++;
			}
			
			while ((secondLineString = secondBufferObj.readLine ()) != null)
			{
				secondFileDataArray [counter2] = secondLineString;
				counter2++;
			}
			
			for (int loopCounter = 0; loopCounter < firstFileDataArray.length; loopCounter++)
			{
				if (firstFileDataArray [loopCounter] != null)
				{
					boolean returnValue = searchStringInsideArray (secondFileDataArray, firstFileDataArray [loopCounter]);
					
					if (returnValue == false)
					{
						counter3++;
					}
				}
			}
			
			if (counter3 > 0)
			{
				System.out.print ("Value don't mached");
			}
			else
			{
				System.out.print ("Value mached");
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
	}
	
	public static boolean searchStringInsideArray (String [] whereToSearch, String whatToSearch)
	{
		for (int loopCounter = 0; loopCounter < whereToSearch.length; loopCounter++)
		{
			if (whereToSearch [loopCounter] != null)
			{
				if (whereToSearch [loopCounter].equals (whatToSearch))
				{
					return true;
				}
			}
		}
		
		return false;
	}
} 