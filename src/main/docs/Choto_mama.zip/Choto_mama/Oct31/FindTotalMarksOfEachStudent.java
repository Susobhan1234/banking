import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;

public class FindTotalMarksOfEachStudent
{
	public static void main (String [] args)
	{
		try
		{
			File fileObj = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Oct31\\StudentDetails.txt");
			FileReader readerObj = new FileReader (fileObj);
			BufferedReader bufferObj = new BufferedReader (readerObj);
			
			String lineString = "";
			
			ArrayList studentList = new ArrayList ();
			
			while ((lineString = bufferObj.readLine ()) != null)
			{
				// parse the line and get marks and name
				 
				String [] lineStringArray = lineString.split (",");
				
				String name = lineStringArray [1];
				
				String marksValue = lineStringArray [3];
				int marks = Integer.parseInt (marksValue);
				
				// Create an object of Student class
				
				Student studentObject = new Student ();
				
				// Populate name and marks from file into studentObject
				
				studentObject.setStudentName (name);
				studentObject.setStudentMarks (marks);
				
				// Add studentObject to the ArrayList
				
				studentList.add (studentObject);
			}
			
			for (int loopCounter = 0; loopCounter < studentList.size (); loopCounter++)
			{
				// Get elements from the studentList and assighn into Student class
				
				Student studentObject = (Student) studentList.get (loopCounter);
				
				System.out.println (studentObject.getStudentName () + " " + studentObject.getStudentMarks ());
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
	}
}