/*
Write program to find number of eatch vowel in a String and then print the String Without vowel.

1. only one argument is input 
2. if there any int number print  0;
*/

public class FindVowelCounter
{
	public static void main (String [] args)
	{
		String inputString = "";
		
		if (args.length != 1)
		{
			System.out.println ("Error");
			return;
		}
		
		inputString = args [0];
		char [] charArr = inputString.toCharArray ();
		int va = 0, ve = 0, vi = 0, vo = 0, vu = 0, counter = 0; 
		
		char [] newArr = new char [100];
		
		for (int loopCounter = 0; loopCounter < charArr.length; loopCounter++)
		{
			if ((charArr [loopCounter] == '0') ||
			(charArr [loopCounter] == '1') ||
			(charArr [loopCounter] == '2') ||
			(charArr [loopCounter] == '3') ||
			(charArr [loopCounter] == '4') ||
			(charArr [loopCounter] == '5') ||
			(charArr [loopCounter] == '6') ||
			(charArr [loopCounter] == '7') ||
			(charArr [loopCounter] == '8') ||
			(charArr [loopCounter] == '9'))
			{
				System.out.println ("0");
			}
			
			else
			{
				if (charArr [loopCounter] == 'a')
				{
					va++;
				}
				else if (charArr [loopCounter] == 'e')
				{
					ve++;
				}
				else if (charArr [loopCounter] == 'i')
				{
					vi++;
				}
				else if (charArr [loopCounter] == 'o')
				{
					vo++;
				}
				else if (charArr [loopCounter] == 'u')
				{
					vu++;
				}
				else
				{
					newArr [counter] = charArr [loopCounter];
					counter++;
				}
			}
		}
		
		System.out.println ("a:" + va);
		System.out.println ("e:" + ve);
		System.out.println ("i:" + vi);
		System.out.println ("o:" + vo);
		System.out.println ("u:" + vu);
		
		for (int loopCounter1 = 0; loopCounter1 < newArr.length; loopCounter1++)
		{
			System.out.print (newArr [loopCounter1]);
		}
	}
}