import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;

public class StudentDetails
{
	public static void main (String [] args)
	{
		BufferedWriter bufferWriterObj = null;
		FileWriter writerObj = null;
		
		try
		{
			File fileObj = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Oct31\\StudentDetails.txt");
			FileReader readerObj = new FileReader (fileObj);
			BufferedReader bufferObj = new BufferedReader (readerObj);
			
			File fileObjOutput = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Oct31\\StudentOutput.txt");
			writerObj = new FileWriter (fileObjOutput);
			bufferWriterObj = new BufferedWriter (writerObj);
			
			String lineString = "";
			int counter = 0;
			
			while ((lineString = bufferObj.readLine ()) != null)
			{
				if (counter == 3)
				{
					throw new Exception ("Error");
				}
				
				bufferWriterObj.write (lineString);
				bufferWriterObj.write ("\n");	
				counter++;
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
		finally 
		{
			try
			{
				bufferWriterObj.close ();
				writerObj.close ();
			}
			catch (Exception ex)
			{
				ex.printStackTrace ();
			}
		}
	}
}