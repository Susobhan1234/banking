import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;

// Print the student name who got the maximum marks

public class CollegeDetails
{
	public static void main (String [] args)
	{
		try
		{
			File fileObject = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Oct7\\MyCollege.txt");
			FileReader readerObject = new FileReader (fileObject);
			BufferedReader bufferObject = new BufferedReader (readerObject);
			
			String lineString = "";
			
			// Defining an ArrayList
			
			ArrayList studentList = new ArrayList (); // ArrayList is a java provided class 
			
			System.out.println (studentList.size ());
			
			while ((lineString = bufferObject.readLine ()) != null)
			{
				String [] arr = lineString.split (",");
				
				String roll = arr [0];
				int rollNo = Integer.parseInt (roll);
				String name = arr [1];
				String subject = arr [2];
				String marks = arr [3];
				int marksValue = Integer.parseInt (marks);
				
				// Defining an object of Studen class
				
				Student studentObject = new Student ();  // This a default constractor for Student class
				
				// populating four field in the object
				
				studentObject.setRollNumber (rollNo);
				studentObject.setStudentName (name);
				studentObject.setSubject (subject);
				studentObject.setMarks (marksValue);
				
				// Adding the object to the ArrayList.
				
				studentList.add (studentObject);
			}
			
			System.out.println (studentList.size ());
			
			sortList (studentList);
			
			// Looping through the element in ArrayList, each element is an object
			
			for (int loopCounter = 0; loopCounter < studentList.size (); loopCounter++)
			{
				
				// Getting element from ArrayList and typecast to Student class 
				
				Student studentObject = (Student) studentList.get (loopCounter);

				// Getting the values from student object and printing.
				
				System.out.print (studentObject.getRollNumber () + " ");
				System.out.print (studentObject.getStudentName () + " ");
				System.out.print (studentObject.getSubject () + " ");
				System.out.println (studentObject.getMarks ());
			}
		}
		
		catch (Exception ex)
		{
			ex.printStackTrace ();
		}
	}
	
	public static void sortList (ArrayList arr)
	{
		int loopCounter = 0, loopCounter1 = 0;
		
		for (loopCounter = 0; loopCounter < arr.size (); loopCounter++)
		{
			for (loopCounter1 = loopCounter + 1; loopCounter1 < arr.size (); loopCounter1++)
			{
				Student arr1 = (Student) arr.get (loopCounter);
				Student arr2 = (Student) arr.get (loopCounter1);
				
				if (arr1.getMarks() >= arr2.getMarks ())
				{
					/*
					int temp = a [loopCounter];
					a [loopCounter] = a [loopCounter1];
					a [loopCounter1] = temp;
					*/
					
					Student temp = arr1;
					arr.set (loopCounter, arr2);
					arr.set (loopCounter1, temp);
				}
			}
		}
	}
}