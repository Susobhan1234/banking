/*
You are given a number N. Write a program to print all sequences of consecutive 
numbers whose sum is equal to N. Take input from STDIN and display output to STDOUT without any additional text.
Example: Input: N=15
Output: 8 7 6 5 4 5 4 3 2 1
*/

public class ConsecutiveNumberSum
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		int number = Integer.parseInt (inputString);
		int loopCounter1 = 0, loopCounter2 = 0, sum = 0;
		String numbers = "";
		
		for (loopCounter1 = number - 1; loopCounter1 >= 1; loopCounter1--)  
		{
			numbers = "";
			sum = 0;
		 
			for (loopCounter2 = loopCounter1; loopCounter2 < number; loopCounter2++)
			{
				sum = sum + loopCounter2;
				
				numbers = numbers + " " + loopCounter2; 
				
				if (sum == number)
				{
					System.out.print (numbers);
				}
			}
			
			System.out.println ("");
		}
	}	
}