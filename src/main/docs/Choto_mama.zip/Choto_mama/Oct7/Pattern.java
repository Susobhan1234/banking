/*
1	2	3	4	5	6	7
	8	9	10	11	12
		13	14	15
			16
*/

public class Pattern
{
	public static void main (String [] args)
	{
		int number = 1, loopCounter1 = 0, loopCounter2 = 0, range = 7, loopCounter3 = 0;
		
		for (loopCounter1 = 1; loopCounter1 <= 4; loopCounter1++)
		{
			for (loopCounter3 = 1; loopCounter3 <= loopCounter1 - 1; loopCounter3++)
			{
				System.out.print ("\t");
			}
			
			for (loopCounter2 = loopCounter1; loopCounter2 <= range ; loopCounter2++)
			{
				System.out.print (number + "\t");
				number++;
			}
			
			range--;
			System.out.println ("");
		}
	}
}