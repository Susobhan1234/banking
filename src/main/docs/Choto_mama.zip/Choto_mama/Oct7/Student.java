public class Student
{
	
	// Bellow four variable are called class lavel variable.
	
	int rollNumber;
	int marks;
	String subject;
	String studentName;
	
	public void setRollNumber (int number)
	{
		rollNumber = number;
	}
	
	public int getRollNumber ()
	{
		return rollNumber;
	}
	
	public void setStudentName (String name)
	{
		studentName = name;
	}
	
	public String getStudentName ()
	{
		return studentName;
	}
	
	public void setSubject (String subjectName)
	{
		subject = subjectName;
	}
	
	public String getSubject ()
	{
		return subject;
	}
	
	public void setMarks (int studentMarks)
	{
		marks = studentMarks;
	}
	
	public int getMarks ()
	{
		return marks;
	}
}