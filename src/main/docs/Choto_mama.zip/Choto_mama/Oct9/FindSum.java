/*
Write a C program that, given an array A[] of n numbers and another number K, find the
pair of all elements in A whose sum is exactly K. Take input from STDIN.
For Example:
If Input:
A[]={1, 4, 15, 6, 10, 2}, K=16
Output:
(1, 15)
(6, 10)
*/

public class FindSum
{
	public static void main (String [] args)
	{
		String inputString1 = args [0];
		String inputString2 = args [1];
		int k = Integer.parseInt (inputString2);
		int [] a = new int [10];
		String [] arr = inputString1.split (",");
		int loopCounter = 0, counter = 0, loopCounter1 = 0, loopCounter2 = 0;
		
		for (loopCounter = 0; loopCounter < arr.length; loopCounter++)
		{
			int number = Integer.parseInt (arr [loopCounter].trim ());
			a [counter] = number;
			counter++;
		}
		
		for (loopCounter1 = 0; loopCounter1 < a.length; loopCounter1++)
		{
			for (loopCounter2 = loopCounter1 + 1; loopCounter2 < a.length; loopCounter2++)
			{
				if (a [loopCounter1] + a [loopCounter2] == k)
				{	
					System.out.println(a [loopCounter1] + " " + a[loopCounter2] + " ");
				}
			}
		}
	}
}