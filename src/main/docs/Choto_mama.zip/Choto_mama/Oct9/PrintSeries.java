/*
C program to display the series 1, 3, 5, 7, 9, …utpo nth term. Input ‘n’ should be taken from
command line.
Test Cases:
-----------
1. VALID INPUT:
a) Only one argument will be given as input. (e.g. 8 or 15)
b) 1<= n <= 100
2. INVALID INPUT:
a) More than one argument or No argument.
b) Negative number as input.
c) Fraction Number as input.
d) String
3. OUTPUT:
a) Print only the terms separated by a space to the STDOUT without any additional text.
b) If error print 'ERROR' to the STDOUT without any additional text.
*/

public class PrintSeries
{
	public static void main (String [] args)
	{
		String inputString = "";
		
		if (args.length != 1)
		{
			System.out.println ("ERROR");
			return;
		}
		
		try
		{
			inputString = args [0];
			int number = Integer.parseInt (inputString);
			int loopCounter = 0, value = 0;
			int n = 1;
			
			if ((number >= 1) && (number <= 100))
			{
				for (loopCounter = 1; loopCounter <= number; loopCounter++)
				{
					value = ((2 * n) - 1);
					n++;
					System.out.print (value + " ");
				}
			}
			else
			{
				System.out.println ("ERROR");
			}
		}
		catch (Exception ex)
		{
			System.out.println ("ERROR");
		}
	}
}