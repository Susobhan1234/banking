import java.util.Scanner;

public class Avarage
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		String inputString = sc.nextLine ();
		int number = Integer.parseInt (inputString);
		
		double [] doubleArr = new double [number];
		int loopCounter = 0;
		double sum = 0;
		
		for (int loopCounter2 = 0; loopCounter2 < number; loopCounter2++)
		{
			String inputNumbers = sc.nextLine ();
			double numbers = Double.parseDouble (inputNumbers);
			
			doubleArr [loopCounter] = numbers;
			loopCounter++;
		}
		
		for (int loopCounter1 = 0; loopCounter1 < number; loopCounter1++)
		{
			sum = sum + doubleArr [loopCounter1];
		}
		
		double avg = sum / number;
		
		System.out.println (avg);
	}
}