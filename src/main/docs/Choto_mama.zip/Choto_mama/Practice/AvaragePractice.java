import java.util.Scanner;

public class AvaragePractice
{
	public static void main (String [] args)
	{
		int N = 10;
		
		double [] doubleArr = new double [N];
		int counter = 0, loopCounter = 0, loopCounter1 = 0;
		double sum = 0, avg = 0;
		
		for (loopCounter = 0; loopCounter < N; loopCounter++)
		{
			Scanner sc = new Scanner (System.in);
			String inputNumbers = sc.nextLine ();
			
			if (inputNumbers.equals ("quite"))
			{
				break;
			}
			
			else
			{
				double numbers = Double.parseDouble (inputNumbers);
				
				doubleArr [counter] = numbers;
				counter++;
			}
		}
		
		for (loopCounter1 = 0; loopCounter1 < N; loopCounter1++)
		{
			sum = sum + doubleArr [loopCounter1];
		}
		
	    avg = sum / loopCounter;
		
		System.out.println (avg);
	}
}