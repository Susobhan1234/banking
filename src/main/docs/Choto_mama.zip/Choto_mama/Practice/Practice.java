import java.util.Arrays;

public class Practice
{
	public static void main (String [] args)
	{
		int [] intArray = new int [100];
		
		intArray [0] = 15;
		intArray [1] = 25;
		intArray [3] = 35;
		intArray [4] = 65;
		intArray [5] = 0;
		intArray [6] = 200;
		
		Arrays.sort (intArray);
		
		for (int loopCounter = 0; loopCounter < intArray.length; loopCounter++)
		{
			System.out.print (intArray [loopCounter] + " ");
		}
	}
}