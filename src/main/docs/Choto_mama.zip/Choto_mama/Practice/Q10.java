/*
10. Read a number from STDIN, then display the sequence given below:
Input: 52934
Output: A5, B2, C9, D3, E4 
*/


public class Q10
{
	public static void main (String [] args)
	{
		String inputString = args [0]; 
		char [] inputCharArray = inputString.toCharArray ();
		
		int  loopCounter = 0;
		int asciiValue = 65;
		
		for (loopCounter = 0; loopCounter < inputCharArray.length; loopCounter++)
		{
			char firstChar = (char) asciiValue;
			
			String newString = firstChar + "" + inputCharArray [loopCounter];
			System.out.print (newString + " ");
			asciiValue = asciiValue + 1;
		}
	}
}