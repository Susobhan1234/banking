// 12. C program to display prime numbers between two intervals.

public class Q12
{
	public static void main (String [] args)
	{
		int startingValue = 10, endingValue = 50, loopCounter = 0, loopCounter1 = 0, loopCounter2 = 0;
		int [] arr = new int [100];
		
		for (loopCounter = startingValue; loopCounter <= endingValue; loopCounter++)
		{
			boolean returnValue = prime (loopCounter);
			
			if (returnValue == true)
			{
				arr [loopCounter1] = loopCounter;
				loopCounter1++;
			}
		}
		
		for (loopCounter2 = 0; loopCounter2 < arr.length; loopCounter2++)
		{
			if (arr [loopCounter2] != 0)
			{
				System.out.print (arr [loopCounter2] + " ");
			}
		}
	}
	
	public static boolean  prime (int number)
	{
		int loopCounter = 0;
		
		for (loopCounter = 2; loopCounter < number; loopCounter++)
		{
			if (number % loopCounter == 0)
			{
				return false;
			}
		}
		
		return true;
	}
}