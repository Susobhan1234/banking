// 15. C program to display factors of a number.


public class Q15
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		int number = Integer.parseInt (inputString);
		int [] arr = new int [20];
		int loopCounter1 = 0;
		
		factor (arr, number);
		
		for (loopCounter1 = 0; loopCounter1 < arr.length; loopCounter1++)
		{
			if (arr [loopCounter1] != 0)
			{
				System.out.print (arr [loopCounter1] + " ");
			}
		}
	}
	
	public static void factor (int [] arr, int number)
	{
		int loopCounter1 = 0, loopCounter2 = 0;
		
		for (loopCounter1 = 2; loopCounter1 < number; loopCounter1++)
		{
			if (number % loopCounter1 == 0)
			{
				int result = number / loopCounter1;
				arr [loopCounter2] = loopCounter1;
				loopCounter2++;
				
				number = result;
				loopCounter1 = 1;
			}
		}
		
		arr [loopCounter2] = number;
	}
}