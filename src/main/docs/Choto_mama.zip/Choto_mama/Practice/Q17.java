// 17. C program to check whether a number can be expressed as sum of two prime numbers.



public class Q17
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		int [] arr = new int [100];
		int number = Integer.parseInt (inputString);
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, sum = 0, loopCounter4 = 0;
		
		for (loopCounter1 = 1; loopCounter1 < number; loopCounter1++)
		{
			boolean returnVlaue = prime (loopCounter1);
			
			if (returnVlaue == true)
			{
				arr [loopCounter2] = loopCounter1;
				loopCounter2++;
			}
		}
		
		for (loopCounter3 = 0; loopCounter3 < arr.length; loopCounter3++)
		{			
			for (loopCounter4 = loopCounter3 + 1; loopCounter4 < arr.length; loopCounter4++)
			{
				sum = arr [loopCounter3] + arr [loopCounter4];
				
				if (sum == number)
				{
					System.out.println (arr [loopCounter3] + " " + arr [loopCounter4]);
				}
			}
		}
	}
	
	public static boolean  prime (int number)
	{
		int loopCounter = 0;
		
		for (loopCounter = 2; loopCounter < number; loopCounter++)
		{
			if (number % loopCounter == 0)
			{
				return false;
			}
		}
		
		return true;
	}
}