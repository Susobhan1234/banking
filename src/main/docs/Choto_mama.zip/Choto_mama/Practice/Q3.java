// 3. C program to display the sequence AMM, COO, EQQ,……….


public class Q3
{
	public static void main (String [] args)
	{
		int range = 5, firstValue = 65, secondValue = 77, loopCounter = 0;
		char firstValueChar = (char) firstValue;
		char secondValueChar = (char) secondValue;
		
		System.out.print (firstValueChar + "" + secondValueChar + "" + secondValueChar + " ");
		
		for (loopCounter = 1; loopCounter < range; loopCounter++)
		{
			firstValue = firstValue + 2;
			secondValue = secondValue + 2;
			char firstValueChar2 = (char) firstValue;
			char secondValueChar2 = (char) secondValue;
			System.out.print (firstValueChar2 + "" + secondValueChar2 + "" + secondValueChar2 + " ");
		}
	}
}