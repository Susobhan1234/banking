// 4. C program to display the sequence ABA, BCB, CDC, DED, ……………….


public class Q4
{
	public static void main (String [] args)
	{
		int range = 4, firstValue = 65, secondValue = firstValue + 1, loopCounter = 0;
		
		for (loopCounter = 1; loopCounter <= range; loopCounter++)
		{
			char firstValueChar = (char) firstValue;
			char secondValueChar = (char) secondValue;
			
			System.out.print (firstValueChar + "" + secondValueChar + "" + firstValueChar + " ");
			firstValue = firstValue + 1;
			secondValue = firstValue + 1;
		}
	}
}