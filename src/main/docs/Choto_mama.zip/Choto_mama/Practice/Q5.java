// 5. C program to count number of digits in an integer.


public class Q5
{
	public static void main (String [] args)
	{
		int number = 1546978, loopCounter = 0, count = 0;
		String newString = "" + number;
		char [] charArr = newString.toCharArray ();
		
		System.out.println (charArr.length);
	}
}