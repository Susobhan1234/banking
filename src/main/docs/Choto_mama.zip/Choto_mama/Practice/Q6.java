// 6. C program to reverse a number.


public class Q6
{
	public static void main (String [] args)
	{
		int number = 56478, loopCounter = 0;
		String newString = "" + number;
		char [] newChar = newString.toCharArray ();
		
		for (loopCounter = newChar.length - 1; loopCounter >= 0; loopCounter--)
		{
			System.out.print (newChar [loopCounter]);
		}
	}
}