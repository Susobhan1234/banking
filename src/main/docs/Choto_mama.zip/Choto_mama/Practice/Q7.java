//  7. C program to check whether a number is palindrome or not.


public class Q7
{
	public static void main (String [] args)
	{
		int number = 787, loopCounter = 0;
		String newString = "" + number;
		char [] charArr = newString.toCharArray ();
		String newString2 = "";
		
		for (loopCounter = charArr.length - 1; loopCounter >= 0; loopCounter--)
		{
			newString2 = newString2 + charArr [loopCounter];
		}
		
		if (newString2.equals (newString))
		{
			System.out.println ("Palindrome number.");
		}
		else
		{
			System.out.println ("Not Palindrome number.");
		}
	}
}