// C program to check whether a number is prime or not.


public class Q8
{
	public static void main (String [] args)
	{
		int number = 8, loopCounter = 0;
		
		for (loopCounter = 2; loopCounter < number; loopCounter++)
		{
			if (number % loopCounter == 0)
			{
				System.out.println ("Not prime number.");
				return;
			}
		}
		
		System.out.println ("prime number.");
	}	
}