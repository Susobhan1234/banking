// 9. C program to find the sum of first n prime numbers.


public class Q9
{
	public static void main (String [] args)
	{
		int n = 10, sum = 0, loopCounter = 0, loopCounter2 = 0, loopCounter1 = 0;
		int [] arr = new int [10];
		
		for (loopCounter2 = 2; ; loopCounter2++)
		{
			boolean returnValue = prime (loopCounter2);
			
			if (returnValue == true)
			{				
				if (loopCounter == 10)
				{
					break;
				}
				
				arr [loopCounter] = loopCounter2;
				
				loopCounter++;
			}
		}
		
		for (loopCounter1 = 0; loopCounter1 < arr.length; loopCounter1++)
		{
			System.out.println (arr [loopCounter1] + " ");
		}
		
		for (loopCounter1 = 0; loopCounter1 < arr.length; loopCounter1++)
		{
			sum = sum + arr [loopCounter1];
		}
		
		System.out.println (sum);
	}
	
	public static boolean prime (int number)
	{
		int loopCounter2 = 0;

		for (loopCounter2 = 2; loopCounter2 < number; loopCounter2++)
		{
			if (number % loopCounter2 == 0)
			{
				return false;
			}
		}
		
		return true;
	}
}