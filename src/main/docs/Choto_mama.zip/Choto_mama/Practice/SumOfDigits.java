// 1. Write a C program to find the sum of digit of a number.


public class SumOfDigits
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		char [] charArr = inputString.toCharArray ();
		int loopCounter = 0, sum = 0;
		
		for (loopCounter = 0; loopCounter < charArr.length; loopCounter++)
		{
			String newString = "" + charArr [loopCounter];
			int newInt = Integer.parseInt (newString);
			sum = sum + newInt;
		}
		
		System.out.println (sum);
	}
}