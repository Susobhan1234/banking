// Adding Eatch value Of a String // 9


public class AddEachnumber 
{
	public static void main (String [] args)
	{
		String number = "";
		
		if (args.length != 1)
		{
			System.out.println ("You must enter only one argument.");
			return;
		}
				
		number = args [0];
		
		int redius = Integer.parseInt (number);
		
		double pie = (22 / 7);
		double area = (pie * (redius * redius));
		
		System.out.println (area);
	}
}