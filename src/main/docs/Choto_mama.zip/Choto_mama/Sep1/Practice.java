// Adding Eatch value Of a String // 9


public class Practice 
{
	public static void main (String [] args)
	{
		String firstNumber = "";
		String secondNumber = "";
		
		if (args.length != 2)
		{
			System.out.println ("You must enter only two arguments.");
			return;
		}
		
		firstNumber = args [0];
		secondNumber = args [1];
		
		double doubleFirstNumber = Double.parseDouble (firstNumber);
		int intSecondNumber = Integer.parseInt (secondNumber);
		
		double avg = ((doubleFirstNumber + intSecondNumber) / 2);
		
		System.out.println (avg);
	}
}