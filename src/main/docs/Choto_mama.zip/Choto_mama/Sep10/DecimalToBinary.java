/* program to convert decimal number to binary number. Use array to store the result. Take input from STDIN. Write the output to STDOUT without any other additional text.

12/2 =0
6/2 =0
3/2 =1
1
*/

public class DecimalToBinary
{
	public static void main (String [] args)
	{
		int number = 13;
		int [] newArray = new int [10];
				
		int counter = 0, loopCounter = 0, loopCounter1 = 0;
		
		for (;;)
		{
			int divisionResult = number / 2; // 6,3,1
			
			int divisionRemainder = number % 2; // 0,0,1
			
			newArray [counter] = divisionRemainder;
			counter++;
			
			if (divisionResult == 1)
			{
				newArray [counter] = 1;
				break;
			}
			
			number = divisionResult;
		}
		
		// System.out.println (counter);
		
		int [] binaryArray = new int [counter + 1];
		
		for (loopCounter = 0; loopCounter < binaryArray.length; loopCounter++)
		{
			binaryArray [loopCounter] = newArray [loopCounter];
		}
		
		for (loopCounter1 = binaryArray.length - 1; loopCounter1 >= 0; loopCounter1--)
		{
			System.out.print (binaryArray [loopCounter1]);
		}
	}
}