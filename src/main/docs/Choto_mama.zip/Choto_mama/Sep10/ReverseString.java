/* Write a C Program to reverse every word of given String with reversing the characters but don’t use any library function. Take input from command line argument.
Example:
Input: Computer Science
Output: ecneicS retupmoC
*/

public class ReverseString
{
	public static void main (String [] args)
	{
		String stringName = args [0];
		int loopCounter = 0;
		
		char [] charArry = stringName.toCharArray ();
		
		for (loopCounter = charArry.length - 1; loopCounter >= 0; loopCounter--)
		{
			System.out.print (charArry [loopCounter]);
		}
	}
}