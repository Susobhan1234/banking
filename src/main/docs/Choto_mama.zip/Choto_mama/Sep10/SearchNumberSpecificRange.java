/* Write a program to find all the numbers within a specific range which contain the given digit d. Take input from STDIN and display output to STDOUT without any additional text.
Example:
Input:
n1=5 n2=50 d=5
Output:
5 15 25 35 45 50 */

public class SearchNumberSpecificRange
{
	public static void main (String [] args)
	{
		int n1 = 5, n2 = 100, searchNumber = 5;
		int loopCounter = 0;
		
		String searchNumberStrig = "" + searchNumber;
		
		for (loopCounter = n1; loopCounter <= n2; loopCounter++)
		{
			String stringValue = "" + loopCounter; // 15
			int returnValue = stringValue.indexOf (searchNumberStrig);
			
			if (returnValue != -1)
			{
				System.out.println (stringValue);
			}
		}
	}
}