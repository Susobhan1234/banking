/* There is an array of single digit element from 0 to 9, with every element repeated twice or thrice except one. Find that element? 
Take input from STDIN and display output to STDOUT without any additional text.
Examples:
Input:
{1, 1, 2, 2, 3, 4, 4, 5, 5, 5}
Output:
3 */

public class SearchingNuberOfOccurenceOne
{
	public static void main (String [] args)
	{
		int [] intArray = new int [10];
		
		intArray [0] = 1;
		intArray [1] = 1;
		intArray [2] = 2;
		intArray [3] = 2;
		intArray [4] = 3;
		intArray [5] = 4;
		intArray [6] = 4;
		intArray [7] = 5;
		intArray [8] = 5;
		intArray [9] = 1;
		
		int loopCounter1 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < intArray.length; loopCounter1++)
		{
			int searchnumber = intArray [loopCounter1];
			
			int returnValue = search (intArray, searchnumber);
			
			// System.out.println (returnValue);
			
			if (returnValue == 1)
			{
				System.out.println (searchnumber);
			}
		}
	}
	
	public static int search (int [] whereToSearch, int whatToSearch)
	{
		int loopCounter = 0, counter = 0;
		
		for (loopCounter = 0; loopCounter < whereToSearch.length; loopCounter++)
		{		
			if (whereToSearch [loopCounter] == whatToSearch)
			{
				counter++;
			}
		}
		
		return counter;
	}
}