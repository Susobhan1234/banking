/* Find the sum of the following series.
S=1+x+x 3 + x 5 +x 7 +… up to n terms.
Take input X and n from STDIN and display output to STDOUT without any additional text. Input format is first X then n.
Example:
Input: 2 4
Output: 43 */

// 2 * 1 + (n - 1) * 2

public class SumOfSeries
{
	public static void main (String [] args)
	{
		int X = 2, n = 4, loopCounter = 0, sum = 0;
		
		for (loopCounter = 1; loopCounter < n; loopCounter++)
		{
			sum = sum + power (X, (2 * loopCounter - 1));
		}
		
		sum = sum + 1;
		System.out.println (sum);
	}
	
	public static int power (int X, int N)
	{
		int loopCounter1 = 0;
		int power = 1;
		
		for (loopCounter1 = 1; loopCounter1 <= N; loopCounter1++)
		{
			power = power * X;
		}
		
		return power;
	}
}