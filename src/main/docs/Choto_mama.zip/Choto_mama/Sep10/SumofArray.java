public class SumofArray
{
	public static void main (String [] args)
	{
		int [] intArray = new int [10];
		
		intArray [0] = 12;
		intArray [1] = 96;
		intArray [2] = 89;
		intArray [3] = 15;
		intArray [4] = 63;
		intArray [5] = 56;
		intArray [6] = 23;
		intArray [7] = 32;
		intArray [8] = 45;
		intArray [9] = 20;
		
		int number = 5, loopCounter = 0, sum = 0;
		
		for (loopCounter = 0; loopCounter < number; loopCounter++)
		{
			sum = sum + intArray[loopCounter];
		}
		
		System.out.println (sum);
	}
}