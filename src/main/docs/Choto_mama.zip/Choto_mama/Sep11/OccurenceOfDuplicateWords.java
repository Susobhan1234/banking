/* Write a program to find the duplicate words and their number of occurrences in a string? Take input from command line argument.
Examples:
Input: Super Man Bat Man Spider Man
Output: Man: 3
Input: Bread butter and jam
Output: No duplicate
Test Cases:
1. VALID INPUT:
a) Only one argument will be given as input.
2. INVALID inputs:
a) No argument b) Two or more than two arguments.
3. You should generate output as follows:
a) Print to the STDOUT.
b) If error print 'ERROR' to the STDOUT without any additional text. */

public class OccurenceOfDuplicateWords
{
	public static void main (String [] args)
	{
		String stringName = "";
		
		if (args.length != 1)
		{
			System.out.println ("ERROR");
			return;
		}
		
		stringName = args [0];
		String [] splitString = stringName.split (" ");
		int loopCounter1 = 0;
		boolean duplicateWordFound = false;
		
		for (loopCounter1 = 0; loopCounter1 < splitString.length; loopCounter1++)
		{
			String searchingString = splitString [loopCounter1];
			
			int returnValue = searching (splitString, searchingString);
			
			if (returnValue > 1)
			{
				duplicateWordFound = true;
				System.out.println (searchingString + ": " + returnValue);
			}
		}
		
		if (duplicateWordFound == false)
		{
			System.out.println ("No duplicate");
		}
	}
	
	public static int searching (String [] whereToSearch, String whatToSearch)
	{
		int loopCounter2 = 0, counter = 0;
		
		for (loopCounter2 = 0; loopCounter2 < whereToSearch.length; loopCounter2++)
		{
			if (whereToSearch [loopCounter2].equals (whatToSearch))
			{
				counter++;
			}
		}
		
		return counter;
	}
}