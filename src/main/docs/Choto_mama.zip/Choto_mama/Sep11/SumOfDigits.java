/* Find out sum of digits of a number using recursion. Take input from STDIN and display output to STDOUT without any additional text.
Examples:
Input:
648
Output:
18
Input:
123
Output:
6 */

public class SumOfDigits
{
	public static void main (String [] args)
	{
		String number = args [0];
		
		String [] numberArray = number.split ("");

		int loopCounter = 0, sum = 0;
		
		for (loopCounter = 0; loopCounter < numberArray.length; loopCounter++)
		{
			int intNumber = Integer.parseInt (numberArray [loopCounter]);
			sum = sum + intNumber;
		}
		
		System.out.println (sum);
	}
}