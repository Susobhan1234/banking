// Write a program to calculate the number of days in a month given the date in dd-mm-yyyy format. Take input from command line argument.

public class CheckDate
{
	public static void main (String [] args)
	{
		String date = args [0];
		String [] dateSplit = date.split ("-");
		String dayString = dateSplit [0];
		int day = Integer.parseInt (dayString);
		String monthString = dateSplit [1];
		int month =  Integer.parseInt (monthString);
		String yearString = dateSplit [2];
		int year = Integer.parseInt (yearString);
		
		dateCheck (month, year);
	}
	
	public static void dateCheck (int month, int year)
	{
		if ((month == 1) || (month == 3) || (month == 5) || (month == 7) || (month == 8) || (month == 10) || (month == 12))
		{
			System.out.println ("The number of days in a month of given the date is = 31");
		}
		else if ((month == 4) || (month == 6) || (month == 9) || (month == 11))
		{
			System.out.println ("The number of days in a month of given the date is = 30");
		}
		else if (month == 2)
		{
			if (((year % 4 == 0) && (year % 100 != 0)) || ((year % 100 == 0) && (year % 400 == 0)))
			{
				System.out.println ("The number of days in a month of given the date is = 29");
			}
			else
			{
				System.out.println ("The number of days in a month of given the date is = 28");
			}
		}
		
		else
		{
			System.out.println ("Invalid Date");
		}
	}
}


// 1,3,5,7,8,10,12
// 4,6,9,11