public class Factorial
{
	public static void main (String [] args)
	{
		try
		{
			String number = "";
			
			if (args.length != 1)
			{
				System.out.println ("ERROR");
				return;
			}
			
			number = args [0];
			int intNumber = Integer.parseInt (number);
			
			if (intNumber < 0)
			{
				System.out.println ("ERROR");
			}
			else
			{
				int loopCounter = 0, factorial = 1;
				
				for (loopCounter = 1; loopCounter <= intNumber; loopCounter++)
				{
					factorial = factorial * loopCounter;
				}
				
				System.out.println (factorial);
			}
		}
		
		catch (Exception ex)
		{
			System.out.println ("ERROR");
		}
	}
}