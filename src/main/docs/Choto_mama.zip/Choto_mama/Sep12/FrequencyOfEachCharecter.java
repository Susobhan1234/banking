/*
Given a string, count the frequency of each character in that string. Take input from command line.
Example:
Input:
academy
Output:
a 2
c 1
d 1
e 1
m 1
y 1
*/

public class FrequencyOfEachCharecter
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		char [] newchar = inputString.toCharArray ();
		int loopCounter1 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < newchar.length; loopCounter1++)
		{
			char searchingChar = newchar [loopCounter1];
			int returnValue = search (newchar, searchingChar);
			
			System.out.println (searchingChar + " " + returnValue);
		}
	}
	
	public static int search (char [] whereToSearch, char whatToSearch)
	{
		int loopCounter2 = 0, counter = 0;
		
		for (loopCounter2 = 0; loopCounter2 < whereToSearch.length; loopCounter2++)
		{
			if (whereToSearch [loopCounter2] == whatToSearch)
			{
				counter++;
			}
		}
		
		return counter;
	}
}