/*
Given a sentence, write a program to count the number of palindrome words in it. Take input from command line argument. // my mom is verry good

// ramakanakamar
ramakanakamar
*/

public class PalindromeCheck
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		String [] stringArray = inputString.split (" ");
		
		int loopCounter = 0;
		int palindromeCounter = 0;
		
		for (loopCounter = 0; loopCounter < stringArray.length; loopCounter++)
		{
			char [] charArray = stringArray [loopCounter].toCharArray ();
			int loopCounter2 = 0;
			String reverseString = "";
			
			for (loopCounter2 = charArray.length - 1; loopCounter2 >= 0; loopCounter2--)
			{
				reverseString = reverseString + charArray [loopCounter2];
			}
			
			if (reverseString.equals (stringArray [loopCounter]))
			{
				palindromeCounter++;
			}
		}
		
		System.out.println (palindromeCounter);
	}
}
