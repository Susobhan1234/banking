/*
1  2  3  4
12       5
11       6
10 9  8  7
*/

public class Pattern
{
	public static void main (String [] args)
	{
		System.out.println ("1\t\t2		3		4");
		System.out.println ("12						5");
		System.out.println ("11						6");
		System.out.println ("10		9		8		7");
	}
}