/*
Write a C program to print the digits of a given integer in word [If the input is 250,
then output should be TWO FIVE ZERO].Take input from STDIN and display output to
STDOUT without any additional text.
*/

public class PrintIntToWord
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		char [] charArray = inputString.toCharArray ();
		int loopCounter = 0;
		
		for (loopCounter = 0; loopCounter < charArray.length; loopCounter++)
		{
			String newtring = "" + charArray [loopCounter];
			int intValue = Integer.parseInt (newtring);
			
			if (intValue == 0)
			{
				System.out.print ("ZERO ");
			}
			else if (intValue == 1)
			{
				System.out.print ("ONE ");
			}
			else if (intValue == 2)
			{
				System.out.print ("TWO ");
			}
			else if (intValue == 3)
			{
				System.out.print ("THREE ");
			}else if (intValue == 4)
			{
				System.out.print ("FOUR ");
			}
			else if (intValue == 5)
			{
				System.out.print ("FIVE ");
			}
			else if (intValue == 6)
			{
				System.out.print ("SIX ");
			}
			else if (intValue == 7)
			{
				System.out.print ("SEVEN ");
			}
			else if (intValue == 8)
			{
				System.out.print ("EIGHT ");
			}
			else if (intValue == 9)
			{
				System.out.print ("NINE ");
			}
		}
	}
}
