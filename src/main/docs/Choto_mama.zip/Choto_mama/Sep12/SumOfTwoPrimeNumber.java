/*
Given a number n. Express this number as sum of other two prime numbers. Take input from STDIN and display output to STDOUT.
Examples:
Input: 24
Output: 11 13
Input: 12
Output: 5 7
Input: 11 
Output: can’t express as sum of two prime numbers
*/

public class SumOfTwoPrimeNumber
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		int newInt = Integer.parseInt (inputString);
		int loopCounter1 = 0, sum = 0;
		String numbers = "";
		boolean found = false; // flag variable
		
		int counter = 0;
		
		for (loopCounter1 = 2; loopCounter1 < newInt; loopCounter1++) // 5
		{
			boolean returnValue = primeCheck (loopCounter1);
			
			if (returnValue == true)
			{
				counter++; // 1
				
				sum = sum + loopCounter1;
				
				numbers = numbers + " " + loopCounter1;
				
				if (sum == newInt)
				{
					System.out.println (numbers);
					found = true;
				}
				
				else if (counter % 2 == 0)
				{
					sum = 0;
					numbers = "";
					
					loopCounter1--;
				}
			}
		}
				
		if (found == false)
		{
			System.out.println ("can not express as sum of two prime numbers");
		}
	}
	
	public static boolean primeCheck (int intNumber)
	{
		int loopCounter = 0;
		
		for (loopCounter = 2; loopCounter < intNumber; loopCounter++)
		{
			if (intNumber % loopCounter == 0)
			{
				return false;
			}
		}
		
		return true;
	}
}