// Write a program to calculate the summation of first 10 natural numbers using recursion. Print to the STDOUT without any additional text.

public class SumUsingRecursion
{
	public static void main (String [] args)
	{
		int sum = 0;
		
		sum = add (1, sum);
		
		System.out.println (sum);
	}
	
	public static int add (int number, int sum)
	{
		if (number > 10)
		{
			return sum;
		}
		
		sum = sum + number; // 45
		number++; // 10
		
		sum = add (number, sum);
		
		return sum;
	}
}

// 12345678910