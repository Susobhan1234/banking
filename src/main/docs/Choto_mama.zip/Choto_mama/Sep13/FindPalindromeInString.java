/*
Given a string "academy", find minimum number of deletion that can make the string palindrome. Take input from command line.
Examples:
Input: academy
Output: 4

academy
demyaca
deacamy
*/

public class FindPalindromeInString
{
	public static void main (String [] args)
	{
		String inputString = "";
		
		if (args.length != 1)
		{
			System.out.println ("ERROR");
			return;
		}
		
		inputString = args [0];
				
		int firstLoopCounter = 0, secondLoopCounter = 0, thirdLoopCounter = 0;
		
		// academy
		
		for (firstLoopCounter = 1; firstLoopCounter < inputString.length () - 1; firstLoopCounter++)
		{
			String partialString = inputString.substring (firstLoopCounter, inputString.length ());
			
			// System.out.println (partialString +  " " + firstLoopCounter);
			
			boolean returnValue = palindromeCheck (partialString);
			
			if (returnValue == true)
			{
				System.out.println (firstLoopCounter + " extra1");
			}
		}

		for (secondLoopCounter = inputString.length () - 1; secondLoopCounter >= 2; secondLoopCounter--)
		{
			String partialString = inputString.substring (0, secondLoopCounter);
			
			boolean returnValue = palindromeCheck (partialString);
			
			if (returnValue == true)
			{
				System.out.println ((secondLoopCounter + 1) + " extra2");
			}
		}
		
		for (thirdLoopCounter = 1; thirdLoopCounter < inputString.length () / 2; thirdLoopCounter++)
		{
			String partialString = inputString.substring (thirdLoopCounter, inputString.length () - thirdLoopCounter);
			
			boolean returnValue = palindromeCheck (partialString);
			
			if (returnValue == true)
			{
				System.out.println ((thirdLoopCounter) + " extra3");
			}
		}
	}
	
	public static boolean palindromeCheck (String anyString)
	{
		int loopCounter1 = 0, loopCounter2 = 0;
		char [] charArray = anyString.toCharArray ();
		String newString = "";
				
		for (loopCounter2 = charArray.length -1; loopCounter2 >= 0; loopCounter2--)
		{
			newString = newString + charArray [loopCounter2];
		}
		
		if (newString.equals (anyString))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}