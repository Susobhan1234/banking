/*
Find Second largest element in an array. Given an array of integers, your task is to write a program that efficiently finds the second largest element present in the array. There should be at least two elements in the array. Take input from STDIN. Display output to STDIN.
Examples:
Input : arr[] = {2, 25, 1, 10, 14, 1}
Output : The second largest element is 14.
Input : arr[] = {10, 15, 10}
Output : The second largest element is 10.
Input : arr[] = {10, 10, 10}
Output : The second largest does not exist.
*/

public class FindSecondLargestNumber
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		String [] stringArray = inputString.split (",");
		int counter = 0;
		int [] intArray = new int [stringArray.length];
		
		for (counter = 0; counter < stringArray.length; counter++)
		{
			intArray [counter] = Integer.parseInt (stringArray [counter]);
		}
		
		if (intArray.length >= 2)
		{
			sort (intArray);
			
			System.out.println (intArray [1]);
		}
		else
		{
			System.out.println ("ERROR");
		}
	}
	
	public static void sort (int [] intArray) //2 25 1
	{
		int loopCounter1 = 0, loopCounter2 = 0;
		int temp = 0;
		
		for (loopCounter1 = 0; loopCounter1 < intArray.length; loopCounter1++)
		{			
			for (loopCounter2 = loopCounter1 + 1; loopCounter2 < intArray.length; loopCounter2++)
			{				
				if (intArray [loopCounter1] < intArray [loopCounter2])
				{
					temp = intArray [loopCounter1];
					intArray [loopCounter1] = intArray [loopCounter2];
					intArray [loopCounter2] = temp;
				}
			}
		}
	}
}