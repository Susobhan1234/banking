public class Practice
{
	public static void main (String [] args)
	{
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, loopCounter4 = 0, loopCounter5 = 0, loopCounter6 = 0, loopCounter7 = 0, loopCounter8 = 0;
		
		for (loopCounter1 = 1; loopCounter1 <= 3; loopCounter1++)
		{
			for (loopCounter3 = 1; loopCounter3 <= loopCounter1; loopCounter3++) 
			{
				System.out.print ("*");
				System.out.print ("\t");
			}
			
			int numberOfEmptyTab = (7 - (2 * loopCounter1));
				
			for (loopCounter4 = 1; loopCounter4 <= numberOfEmptyTab; loopCounter4++)
			{
				System.out.print ("\t");
			}
			
			for (loopCounter3 = 1; loopCounter3 <= loopCounter1; loopCounter3++)
			{
				System.out.print ("*");
				System.out.print ("\t");
			}

			System.out.println ("");
		}	
		
		for (loopCounter5 = 1; loopCounter5 <= 7; loopCounter5++)
		{
			System.out.print ("*");
			System.out.print ("\t");
		}
		
		System.out.println ("");
		
		for (loopCounter2 = 1; loopCounter2 <= 3; loopCounter2++)
		{
			for (loopCounter6 = 3; loopCounter6 >= loopCounter2; loopCounter6--)
			{
				System.out.print ("*");
				System.out.print ("\t");
			}
			
			int numberOfEmptyTab = ((2 * loopCounter2) - 1);
			
			for (loopCounter7 = 1; loopCounter7 <= numberOfEmptyTab; loopCounter7++)
			{
				System.out.print ("\t");
			}
			
			for (loopCounter8 = 3; loopCounter8 >= loopCounter2; loopCounter8--)
			{
				System.out.print ("*");
				System.out.print ("\t");
			}
			
			System.out.println ("");
		}
	}
}
