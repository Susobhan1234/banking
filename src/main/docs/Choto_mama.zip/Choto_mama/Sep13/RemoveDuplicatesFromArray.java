/*
Remove duplicates from an array Given an array, the task is to remove the duplicate elements from the array. Display the array in sorted order. Take input from STDIN and display output to STDOUT without any additional text.
Examples:
Input: arr[] = {2, 2, 2, 2, 2}
Output: arr[] = {2}
Input: arr[] = {1, 6, 3, 4, 4, 4, 5, 5}
Output: arr[] = {1, 3, 4, 5, 6}
*/

public class RemoveDuplicatesFromArray 
{
	public static void main (String [] args)
	{
		int [] intArray = new int [10];
		int [] newInt = new int [10];
		
		intArray [0] = 1;
		intArray [1] = 6;
		intArray [2] = 3;
		intArray [3] = 4;
		intArray [4] = 4;
		intArray [5] = 4;
		intArray [6] = 5;
		intArray [7] = 5;
		intArray [8] = 1;
		intArray [9] = 6;
		
		int loopCounter = 0, counter = 0;
		
		for (loopCounter = 0; loopCounter < intArray.length; loopCounter++)
		{
			int searchingNumber = intArray [loopCounter];
			
			boolean returnValue = search (newInt, searchingNumber);
			
			if (returnValue == false)
			{
				newInt [loopCounter] = intArray [loopCounter];
			}			
		}

		sort (newInt);
		for (counter = 0; counter < newInt.length; counter++)
		{
			System.out.println (newInt [counter]);
		}
	}
	
	public static boolean search (int [] whereToSearch, int whatToSearch)
	{
		int loopCounter1 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < whereToSearch.length; loopCounter1++)
		{
			if (whereToSearch [loopCounter1] == whatToSearch)
			{
				return true;
			}
		}
		
		return false;
	}
	
	public static void sort (int [] newInt)
	{
		int firstLoopCounter = 0, secondLoopCounter = 0;
		
		for (firstLoopCounter = 0; firstLoopCounter < newInt.length; firstLoopCounter++)
		{
			for (secondLoopCounter = firstLoopCounter + 1; secondLoopCounter < newInt.length; secondLoopCounter++)
			{
				if (newInt [firstLoopCounter] > newInt [secondLoopCounter])
				{
					int temp = newInt [firstLoopCounter];
					newInt [firstLoopCounter] = newInt [secondLoopCounter];
					newInt [secondLoopCounter] = temp;
				}
			}
		}
	}
}