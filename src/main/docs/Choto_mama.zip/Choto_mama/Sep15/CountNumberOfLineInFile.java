/*
Program to count number of lines, words and characters in a file. Take file name from
STDIN and display output to STDOUT separated by space without any additional text.
*/
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;

public class CountNumberOfLineInFile
{
	
	public static void main (String [] args)
	{
		try
		{
			File fileObject = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Sep15\\NewFile.txt");
			FileReader readerObject = new FileReader (fileObject);
			BufferedReader bufferObject = new BufferedReader (readerObject);
			
			String lineString = "";
			int numberOfLine = 0, loopCounter = 0, numberOfWord = 0, numberOfChar = 0;
			
			while ((lineString = bufferObject.readLine ()) != null)
			{				
				numberOfLine++;
				String [] splitArray = lineString.split (" ");
				
				numberOfChar = numberOfChar + lineString.length ();
				
				numberOfWord = numberOfWord + splitArray.length;
			}
			
			System.out.println ("Number of line : " + numberOfLine);
			System.out.println ("Number of word : " + numberOfWord);
			System.out.println ("Number of char : " + numberOfChar);
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
	}
}
