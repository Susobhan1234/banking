/*
Given a number n. Find the difference of largest and smallest numbers using the same
set of digits of n. Take input from STDIN and display output to STDOUT without any
additional text.
*/

public class FindLargeAndSmallDifference
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		char [] charArray = inputString.toCharArray ();
		int intArray [] = new int [charArray.length];
		int loopCounter = 0, loopCounter3 = 0, loopCounter4 = 0;
		String firstString = "", secondString = "";
		
		for (loopCounter = 0; loopCounter < charArray.length; loopCounter++)
		{
			String newString = "" + charArray [loopCounter];
			int newInt = Integer.parseInt (newString);
			intArray [loopCounter] = newInt;
		}
		
		descendingSort (intArray);
		
		for (loopCounter3 = 0; loopCounter3 < intArray.length; loopCounter3++)
		{
			firstString = firstString + intArray [loopCounter3];
		}
		
		int desendingInt = Integer.parseInt (firstString);
		
		ascendingSort (intArray);
		
		for (loopCounter4 = 0; loopCounter4 < intArray.length; loopCounter4++)
		{
			secondString = secondString + intArray [loopCounter4];
		}
		
		int ascendingInt = Integer.parseInt (secondString);
		
		System.out.println (desendingInt - ascendingInt);
	}
	
	public static void descendingSort (int [] numberArray)
	{
		int loopCounter1 = 0, loopCounter2 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < numberArray.length; loopCounter1++)
		{
			for (loopCounter2 = 0; loopCounter2 < numberArray.length; loopCounter2++)
			{
				if (numberArray [loopCounter1] > numberArray [loopCounter2])
				{
					int temp = numberArray [loopCounter1];
					numberArray [loopCounter1] = numberArray [loopCounter2];
					numberArray [loopCounter2] = temp;
				}
			}
		}
	}
	
	public static void ascendingSort (int [] numberArray)
	{
		int loopCounter1 = 0, loopCounter2 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < numberArray.length; loopCounter1++)
		{
			for (loopCounter2 = 0; loopCounter2 < numberArray.length; loopCounter2++)
			{
				if (numberArray [loopCounter1] < numberArray [loopCounter2])
				{
					int temp = numberArray [loopCounter1];
					numberArray [loopCounter1] = numberArray [loopCounter2];
					numberArray [loopCounter2] = temp;
				}
			}
		}
	}
}