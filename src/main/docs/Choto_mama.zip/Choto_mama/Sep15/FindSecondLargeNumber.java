/*
1. Take input from commandline. (String variable)
2. Sort the number in descnding order. 
	a. Convert string variable to char array.
	b. Convert the char value to string.
	c. Convert the string to integer.
	d. Assign the integer to integer array.
	e. Sort the integer array.
	
3. Swap the last index to second last index.

5631
after sorting : 6531

*/

public class FindSecondLargeNumber
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		char [] charArray = inputString.toCharArray ();
		int intArray [] = new int [charArray.length];
		int loopCounter = 0, loopCounter3 = 0;
		
		for (loopCounter = 0; loopCounter < charArray.length; loopCounter++)
		{
			String newString = "" + charArray [loopCounter];
			int newInt = Integer.parseInt (newString);
			intArray [loopCounter] = newInt;
		}
		
		sort (intArray);
		
		int temp = intArray [intArray.length - 1];
		intArray [intArray.length - 1] = intArray [intArray.length - 2];
		intArray [intArray.length - 2] = temp;
		
		for (loopCounter3 = 0; loopCounter3 < charArray.length; loopCounter3++)
		{
			System.out.print (intArray [loopCounter3]);
		}
	}
	
	public static void sort (int [] numberArray)
	{
		int loopCounter1 = 0, loopCounter2 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < numberArray.length; loopCounter1++)
		{
			for (loopCounter2 = 0; loopCounter2 < numberArray.length; loopCounter2++)
			{
				if (numberArray [loopCounter1] > numberArray [loopCounter2])
				{
					int temp = numberArray [loopCounter1];
					numberArray [loopCounter1] = numberArray [loopCounter2];
					numberArray [loopCounter2] = temp;
				}
			}
		}
	}
}