public class CaseChange
{
	public static void main (String [] args)
	{
		String stringValue = "";
		
		if (args.length != 1)
		{
			System.out.println ("ERROR");
			return;
		}
		
		stringValue = args [0];
		int loopCounter = 0;
		
		char [] charValue = stringValue.toCharArray ();
		
		for (loopCounter = 0; loopCounter < charValue.length; loopCounter++)  
		{
			int asciiValue = charValue [loopCounter];
			
			if ((asciiValue >= 65) && (asciiValue <= 90))
			{
				String newString = "" + charValue [loopCounter];
				String lowerCase = newString.toLowerCase ();
				System.out.print (lowerCase);
			}
			
			else if ((asciiValue >= 97) && (asciiValue <= 122))
			{
				String newString2 = "" + charValue [loopCounter];
				String upperCase = newString2.toUpperCase ();
				System.out.print (upperCase);
			}
			
			else
			{
				System.out.print (charValue [loopCounter]);
			}
		}
	}
}
