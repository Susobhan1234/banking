public class SquareRoot
{
	public static void main (String [] args)
	{
		int number = 132, loopCounter = 0, newNumber = 0, loopCounter1 = 0;
		int [] intArray = new int [10];
		
		for (loopCounter = 2; loopCounter < number; loopCounter++)
		{
			if (number % loopCounter == 0)
			{
				number = number / loopCounter;
				
				intArray [loopCounter1] = loopCounter;
				loopCounter1++;
				loopCounter = 2;
			}
		}
		
		intArray [loopCounter1] = number;
		
		for (loopCounter1 = 0; loopCounter1 < intArray.length; loopCounter1++)
		{
			if (intArray [loopCounter1] != 0)
			{
				System.out.print (intArray [loopCounter1] + " ");
			}
		}
	}
}