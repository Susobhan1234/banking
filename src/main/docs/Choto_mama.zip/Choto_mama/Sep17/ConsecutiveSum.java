/*
You are given a number N. Write a program to print all sequences of consecutive numbers whose sum is equal to N. 
Take input from STDIN and display output to STDOUT without any additional text.
Example: Input: N=15
Output: 8 7 6 5 4 5 4 3 2 1
*/

public class ConsecutiveSum
{
	public static void main (String [] args)
	{
		String inputNumber = args [0];
		int number = Integer.parseInt (inputNumber);
		int loopCounter1 = 0, loopCounter2 = 0, add = 0;
		String numbers = "";
		
		for (loopCounter1 = 1; loopCounter1 < number; loopCounter1++)  
		{
			numbers = "";
			add = 0;
		 
			for (loopCounter2 = loopCounter1; loopCounter2 < number; loopCounter2++)
			{
				add = add + loopCounter2;
				
				numbers = numbers + " " + loopCounter2; 
				
				if (add == number)
				{
					System.out.print (numbers);
				}
			}
			
			System.out.println ("");
		}
	}	
}
