/*
1	2	3	4	5	6	7
	8	9	10	11	12
		13	14	15
			16
*/

public class Pattern
{
	public static void main (String [] args)
	{
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 1, counter = 1;
		
		for (loopCounter1 = 1; loopCounter1 <= 4; loopCounter1++) // loopCounter1=2
		{
			for (loopCounter2 = 1; loopCounter2 <= 7; loopCounter2++)
			{
				if (((loopCounter1 == 2) && (loopCounter2 == 1)) ||
				((loopCounter1 == 2) && (loopCounter2 == 7)) ||
				((loopCounter1 == 3) && (loopCounter2 == 1)) ||
				((loopCounter1 == 3) && (loopCounter2 == 2)) ||
				((loopCounter1 == 3) && (loopCounter2 == 6)) ||
				((loopCounter1 == 3) && (loopCounter2 == 7)) ||
				((loopCounter1 == 4) && (loopCounter2 == 1)) ||
				((loopCounter1 == 4) && (loopCounter2 == 2)) ||
				((loopCounter1 == 4) && (loopCounter2 == 3)) ||
				((loopCounter1 == 4) && (loopCounter2 == 5)) ||
				((loopCounter1 == 4) && (loopCounter2 == 6)) ||
				((loopCounter1 == 4) && (loopCounter2 == 7)))
				{
					System.out.print ("\t");
				}	
				else
				{
					System.out.print (counter);
					System.out.print ("\t");
					counter++;
				}
			}
			
			System.out.println ("");
		}
	}
}