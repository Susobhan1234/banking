/*
C program to display Fibonacci sequence 0, 1, 1, 2, 3, 5, 8,…utpo nth term. Input ‘n’ should
be taken from command line.
Test Cases:
-----------
1. VALID INPUT:
a) Only one argument will be given as input. (e.g. 8 or 15)
b) 1<= n <= 20
2. INVALID INPUT:
a) More than one argument or No argument.
b) Negative number as input.
c) Fractional number as input.
d) String (e.g. "ab" or "t" or "e2")
3. OUTPUT:
a) Print only the terms separated by a space to the STDOUT without any additional text.
b) If error print 'ERROR' to the STDOUT without any additional text.
*/

public class FibonacciSeries
{
	public static void main (String [] args)
	{
		String inputNumber = args [0];
		
		try 
		{
			int intNumber = Integer.parseInt (inputNumber);
			
			if  ((intNumber >= 1) && (intNumber <= 20))
			{
				fibonacci (intNumber);
			}
			else
			{
				System.out.println ("Enter number should be with in 1 to 20");
			}
		}
		catch (Exception ex)
		{
			System.out.println ("You must entered an integer number.");
		}
	}
	
	public static void fibonacci (int number)
	{
		int firstNumber = 0, secondNumber = 1, newNumber = 0, loopCounter = 0;
		String series = "";
		series = firstNumber + " " + secondNumber;
		
		for (loopCounter = 2; loopCounter <= number; loopCounter++)
		{
			newNumber = firstNumber + secondNumber;
			series = series +  " " + newNumber;
			
			firstNumber = secondNumber;
			secondNumber = newNumber;
		}
		
		System.out.print (series);
	}
}