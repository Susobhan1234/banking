/*
Write a program to display prime numbers between two intervals. Take input from
STDIN.
For example:
If input: n1=2 n2=10
Output: 2 3 5 7
*/

public class PrimeNumbers
{
	public static void main (String [] args)
	{
		String firstNumber = args [0];
		int intFirstNumber = Integer.parseInt (firstNumber);
		String secondNumber = args [1];
		int intSecondNumber = Integer.parseInt (secondNumber);
		String primeNumber = "";
		
		int loopCounter1 = 0;
		
		for (loopCounter1 = intFirstNumber; loopCounter1 <= intSecondNumber; loopCounter1++)
		{
			boolean returnValue = checkPrimeNumber (loopCounter1);
			
			if (returnValue == true)
			{
				primeNumber = primeNumber + " " + loopCounter1;
			}
		}
		
		System.out.println (primeNumber);
	}
	
	public static boolean checkPrimeNumber (int loopCounter1)
	{
		int loopCounter2 = 0;
		
		for (loopCounter2 = 2; loopCounter2 < loopCounter1; loopCounter2++)
		{
			if (loopCounter1 % loopCounter2 == 0)
			{
				return false;
			}
		}
		
		return true;
	}
}