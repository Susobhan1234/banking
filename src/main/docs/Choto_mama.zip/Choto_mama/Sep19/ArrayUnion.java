/*
Given three arrays sorted in non-decreasing order, print all common elements in these
arrays.
Take input from STDIN.
For Example:
If Input:
ar1[] = {1, 5, 10, 20, 40, 80}
ar2[] = {6, 7, 20, 80, 100}
ar3[] = {3, 4, 15, 20, 30, 70, 80, 120}
Output: 20, 80
*/
public class ArrayUnion
{
	public static void main (String [] args)
	{
		int loopCounter1 = 0;
		
		int [] arr1 = new int [6];
		arr1 [0] = 1;
		arr1 [1] = 5;
		arr1 [2] = 10;
		arr1 [3] = 20;
		arr1 [4] = 40;
		arr1 [5] = 80;
		
		int [] arr2 = new int [5];
		arr2 [0] = 6;
		arr2 [1] = 7;
		arr2 [2] = 20;
		arr2 [3] = 80;
		arr2 [4] = 100;
		
		int [] arr3 = new int [8];
		arr3 [0] = 3;
		arr3 [1] = 4;
		arr3 [2] = 15;
		arr3 [3] = 20;
		arr3 [4] = 30;
		arr3 [5] = 70;
		arr3 [6] = 80;
		arr3 [7] = 120;		
		
		for (loopCounter1 = 0; loopCounter1 < arr1.length; loopCounter1++)
		{
			boolean returnValue = searching (arr2, arr1 [loopCounter1]);
			boolean returnValue2 = searching (arr3, arr1 [loopCounter1]);
			
			if ((returnValue == true) && (returnValue2 == true))
			{
				System.out.print (arr1 [loopCounter1] + " ");
			}
		}
	}
	
	public static boolean searching (int [] whereToSearch, int whatToSearch)
	{
		int loopCounter = 0;
		
		for (loopCounter = 0; loopCounter < whereToSearch.length; loopCounter++)
		{
			if (whereToSearch [loopCounter] == whatToSearch)
			{
				return true;
			}
		}
		
		return false;
	}
}