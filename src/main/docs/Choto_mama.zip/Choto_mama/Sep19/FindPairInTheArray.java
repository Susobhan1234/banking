/*
Write a C program that, given an array A[] of n numbers and another number K, find the
pair of all elements in A whose sum is exactly K. Take input from STDIN.
For Example:
If Input:
A[]={1, 4, 15, 6, 10, 2}, K=16
Output:
(1, 15)
(6, 10)
*/

public class FindPairInTheArray
{
	public static void main (String [] args)
	{
		int [] a = new int [6];
		
		a [0] = 1;
		a [1] = 4;
		a [2] = 15;
		a [3] = 6;
		a [4] = 10;
		a [5] = 2;
				
		int k = 16, loopCounter1 = 0, loopCounter2 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < a.length; loopCounter1++)
		{
			for (loopCounter2 = loopCounter1 + 1; loopCounter2 < a.length; loopCounter2++)
			{
				if (a [loopCounter1] + a [loopCounter2] == k)
				{
					
					System.out.println(a [loopCounter1] + " " + a[loopCounter2] + " ");
				}
			}
		}
	}
}