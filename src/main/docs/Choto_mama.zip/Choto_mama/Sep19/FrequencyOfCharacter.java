/*
Given a string, find the second most frequent character in it. Take input from STDIN.
For Example:
Input:
str = "aabababa";
Output:
Second most frequent character is 'b'
*/

public class FrequencyOfCharacter
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		char [] inputChar = inputString.toCharArray ();
		int loopCOunter1 = 0, loopCOunter2 = 0, loopCOunter3 = 0, counter = 0, loopCOunter4 = 0;
		
		int [] intArray = new int [10];
		
		for (loopCOunter1 = 0; loopCOunter1 < inputChar.length; loopCOunter1++) // To go eatch character in the array.
		{
			counter = 0;
			
			for (loopCOunter2 = 0; loopCOunter2 < inputChar.length; loopCOunter2++) // Inside loopCOunter1 again go to eatch charecter again
			{
				if (inputChar [loopCOunter1] == inputChar [loopCOunter2]) // Checking if first character found in the array and increase the counter value
				{
					counter++;
				}
			}
			
			int searchingNumber = counter;
			boolean returnValue = searching (intArray, searchingNumber); //  searching for if the number is already in the intArray
			
			if (returnValue == false) // If not found then add the counter value in the intArray
			{
				intArray [loopCOunter3] = counter;
				loopCOunter3++;
			}
		}
		
		sort (intArray); // Sorting the intArray in desending order
			
		for (loopCOunter4 = 0; loopCOunter4 < intArray.length; loopCOunter4++) // For remove the zero
		{
			if (intArray [loopCOunter4] != 0)
			{
				System.out.print (intArray [loopCOunter4] + " ");
			}
		}
		
		int secondOccurenceCount = 0;
		secondOccurenceCount = intArray [1]; // For define the second large number in the array
		
		for (loopCOunter1 = 0; loopCOunter1 < inputChar.length; loopCOunter1++)
		{
			counter = 0;
			
			for (loopCOunter2 = 0; loopCOunter2 < inputChar.length; loopCOunter2++)
			{
				if (inputChar [loopCOunter1] == inputChar [loopCOunter2])
				{
					counter++;
				}
			}
			
			if (counter == secondOccurenceCount)
			{
				System.out.println (inputChar [loopCOunter1]);
				break;
			}
		}
	}
	
	public static void sort (int [] intArray)
	{
		int loopCOunter = 0, secondLoopCOunter = 0;
		
		for (loopCOunter = 0; loopCOunter < intArray.length; loopCOunter++)
		{
			for (secondLoopCOunter = loopCOunter + 1; secondLoopCOunter < intArray.length; secondLoopCOunter++)
			{
				if (intArray [loopCOunter] < intArray [secondLoopCOunter])
				{
					int temp = intArray [loopCOunter];
					intArray [loopCOunter] = intArray [secondLoopCOunter];
					intArray [secondLoopCOunter] = temp;
				}
			}
		}
	}
	
	public static boolean searching (int [] whereSearching, int whatSearching)
	{
		int newLoopCounter = 0;
		
		for (newLoopCounter = 0; newLoopCounter < whereSearching.length; newLoopCounter++)
		{
			if (whereSearching [newLoopCounter] == whatSearching)
			{
				return true;
			}
		}
		
		return false;
	}	
}