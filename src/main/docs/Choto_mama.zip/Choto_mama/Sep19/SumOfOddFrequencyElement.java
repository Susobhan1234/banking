/*
Find the total sum of odd frequency elements in an array. Take input from STDIN.
Examples:
Input : arr[] = {1, 1, 2, 2, 3, 3, 3}
Output : 9
Explanation : The odd occurring element is 3, and it's number of occurrence is 3.Therefore
sum of all 3's in the array = 9.
Input : arr[] = {10, 20, 30, 40, 40}
Output : 60
Explanation : Elements with odd frequency are 10, 20 and 30. Sum = 60.
*/

public class SumOfOddFrequencyElement
{
	public static void main (String [] args)
	{
		int [] arr = new int [10];
		
		arr [0] = 1;
		arr [1] = 1;
		arr [2] = 2;
		arr [3] = 2;
		arr [4] = 2;
		arr [5] = 3;
		arr [6] = 3;
		arr [7] = 3;
		arr [8] = 3;
		arr [9] = 3;
		
		int loopCounter = 0, loopCounter1 = 0, sum = 0;
		
		for (loopCounter = 0; loopCounter < arr.length; loopCounter++)
		{
			int searchingNumber = arr [loopCounter];
			
			int returnValue = search (arr, searchingNumber);
			
			if (returnValue % 2 != 0)
			{
				for (loopCounter1 = 1; loopCounter1 <= returnValue; loopCounter1++)
				{
					sum = sum + searchingNumber;
					break;
				}
			}
		}
		
		System.out.println (sum);
	}
	
	public static int search (int [] whereToSearch, int whatToSearch)
	{
		int newLoopCounter = 0, counter = 0;
		
		for (newLoopCounter = 0; newLoopCounter < whereToSearch.length; newLoopCounter++)
		{
			if (whereToSearch [newLoopCounter] == whatToSearch)
			{
				counter++;
			}
		}
		
		return counter;
	}
}