/*
Find the maximum difference between two array elements of an array such that larger
element appears after the smaller number. Take input from STDIN.
Example:
Input: arr = {2, 3, 10, 6, 4, 8, 1}
Output: 8
Explanation: The maximum difference is between 10 and 2.
Input: arr = {7, 9, 5, 6, 3, 2}
Output: 2
Explanation: The maximum difference is between 9 and 7.
*/

public class ValidMaxDifferenceInArray
{
	public static void main (String [] args)
	{
		int [] arr = new int [7];
		
		arr [0] = 2;
		arr [1] = 3;
		arr [2] = 10;
		arr [3] = 6;
		arr [4] = 4;
		arr [5] = 8;
		arr [6] = 1;
		
		int [] newArray = new int [100];
		
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < arr.length; loopCounter1++)
		{
			for (loopCounter2 = loopCounter1 + 1; loopCounter2 < arr.length; loopCounter2++)
			{
				if (arr [loopCounter1] < arr [loopCounter2])
				{
					int difference = arr [loopCounter2] - arr [loopCounter1];
					newArray [loopCounter3] = difference;
					loopCounter3++;
				}
			}
		}
		
		sort (newArray);
		System.out.println (newArray [0]);
	}
	
	public static void sort (int [] intArray)
	{
		int firstLoopCOunter = 0, secondLoopCOunter = 0;
		
		for (firstLoopCOunter = 0; firstLoopCOunter < intArray.length; firstLoopCOunter++)
		{
			for (secondLoopCOunter = firstLoopCOunter + 1; secondLoopCOunter < intArray.length; secondLoopCOunter++)
			{
				if (intArray [firstLoopCOunter] < intArray [secondLoopCOunter])
				{
					int temp = intArray [firstLoopCOunter];
					intArray [firstLoopCOunter] = intArray [secondLoopCOunter];
					intArray [secondLoopCOunter] = temp;
				}
			}
		}
	}
}