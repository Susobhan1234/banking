/*
Remove duplicates character from a given string. Take input from command line.
Input String: engineering
Output String: engir
Test Cases:
1. Valid Input:
a) Only string of character will be given as input.
2. Invalid inputs:
a) No command line arguments
b) Two or more command line arguments
c) Integer
d) Fraction
3. You should generate output as follows:
a) For right output print just the string to STDOUT without any other text.
b) If any error: print 'ERROR' to the STDOUT without any other text.
*/

public class RemoveDuplicate
{
	public static void main (String [] args)
	{
		String inputString = "";
		
		if (args.length != 1)
		{
			System.out.println ("Error");
		}
		
		inputString = args [0];
		char [] charArray = inputString.toCharArray ();
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0;
		char [] newArray = new char [10];
		
		for (loopCounter1 = 0; loopCounter1 < charArray.length; loopCounter1++)
		{
			char searchIngChar = charArray [loopCounter1];
			
			boolean returnValue = search (newArray, searchIngChar);
			
			if (returnValue == false)
			{
				newArray [loopCounter2] = searchIngChar;
				loopCounter2++;
			}
		}
		
		for (loopCounter3 = 0; loopCounter3 < newArray.length; loopCounter3++)
		{
			System.out.print (newArray [loopCounter3]);
		}
	}
	
	public static boolean search (char [] whereToSearch, char whatToSearch)
	{
		int loopCounter = 0;
		
		for (loopCounter = 0; loopCounter < whereToSearch.length; loopCounter++)
		{
			if (whereToSearch [loopCounter] == whatToSearch)
			{
				return true;
			}
		}
		
		return false;
	}
}