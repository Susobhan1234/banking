/*
Write a C program to convert a number belonging to one base into its corresponding equivalent belonging to any other base. For e.g. binary number (Base 2) to Decimal (Base 10).
Test Cases:
----------
1. VALID INPUT:
a) Three positive integers will be given as input. First input is the given number second input is its current base and third input is the base of the converted number.
2. INVALID INPUT:
a) 0
b) Negative
c) Fraction
d) String
e) Two or less command line arguments
3. OUTPUT:
a) For valid input print only the output to the STDOUT without any other additional text.
b) If any error: print ERROR to the STDOUT without any other additional text.
For example:
If input:
17 10 2
Output:
10001
*/

public class DecimalTobinaryAndBinaryToDecimal
{
	public static void main (String [] args)
	{
		String inputString1 = "";
		String inputString2 = "";
		String inputString3 = "";
		
		if (args.length != 3)
		{
			System.out.println ("Error");
			return;
		}
		
		inputString1 = args [0];
		inputString2 = args [1];
		inputString3 = args [2];
		
		int number = Integer.parseInt (inputString1);
		int inputBase = Integer.parseInt (inputString2);
		int convertedBase = Integer.parseInt (inputString3);
		
		if (number > 0)
		{
			if (inputBase == 10)
			{
				decimalToBinary (number);
			}
			else if (inputBase == 2)
			{
				binaryToDecimal (number);
			}
		}
		
		else
		{
			System.out.println ("Error");
		}
	}
	
	public static void decimalToBinary (int number)
	{		
		int newArray [] = new int [10];
		int loopCounter1 = 0, loopCounter2 = 0; 
		
		for (;;)
		{
			int divisionValue = number / 2;
			int remainder = number % 2;
			
			newArray [loopCounter1] = remainder;
			loopCounter1++;
			
			number = divisionValue;
			
			if (number == 1) 
			{
				newArray [loopCounter1] = 1;
				break;				
			}
		}
		
		for (loopCounter2 = newArray.length - 1; loopCounter2 >= 0; loopCounter2--)
		{
			System.out.print (newArray [loopCounter2]);
		}
	}
	
	public static void binaryToDecimal (int number)
	{
		String newString = "" + number;
		char [] charArray = newString.toCharArray (); // 1001
		int lengthOfCharArray = charArray.length - 1;
		
		int loopCounter1 = 0, loopCounter2 = 0;
		int decimalNumber = 0;
		
		for (loopCounter1 = charArray.length - 1; loopCounter1 >= 0; loopCounter1--) // 1000
		{
			String newString2 = "" + charArray [loopCounter1];
			int newInt = Integer.parseInt (newString2);
			
			int powerResult = power (loopCounter2);
			decimalNumber = decimalNumber + (newInt * powerResult);
			loopCounter2++;
		}
		
		System.out.print (decimalNumber);
	}
	
	public static int power (int powerValue)
	{
		int loopCounter = 0, powerResult = 1;
		
		for (loopCounter = 1; loopCounter <= powerValue; loopCounter++)
		{
			powerResult = powerResult * 2;
		}
		
		return powerResult;
	}
}