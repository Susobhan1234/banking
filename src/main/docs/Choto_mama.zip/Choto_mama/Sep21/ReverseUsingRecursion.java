/*
program to reverse a String Using Recursion.
Input String:
margorp emosewa
Output String:
awesome program
Test Cases:
-----------
1. VALID INPUTS:
a) Only String will be given as input through STDIN.
2. INVALID INPUTS:
a) Characters other than alphabet.
3. OUTPUT:
a) Write the output to STDOUT without any other additional text.
b) In case of invalid input print 'ERROR' to the STDOUT without any other additional text and terminate.
*/