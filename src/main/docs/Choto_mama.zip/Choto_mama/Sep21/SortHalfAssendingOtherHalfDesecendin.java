/*
Given an array of integers, sort the first half of the array in ascending order and second half in descending order. Take input from STDIN. If odd number of input is given then second half will have even number of elements.
Examples:
Input: arr[] = {5, 2, 4, 7, 9, 3, 1, 6, 8}
Output: arr[] = {1, 2, 3, 4, 9, 8, 7, 6, 5}
Input: arr[] = {1, 2, 3, 4, 5, 6}
Output: arr[] = {1, 2, 3, 6, 5, 4}
*/

public class SortHalfAssendingOtherHalfDesecendin
{
	public static void main (String [] args)
	{
		int [] intArray = new int [8];
		
		intArray [0] = 5;
		intArray [1] = 2;
		intArray [2] = 4;
		intArray [3] = 7;
		intArray [4] = 9;
		intArray [5] = 3;
		intArray [6] = 1;
		intArray [7] = 6;
		// intArray [8] = 8;
		
		int [] newArray = new int [8];
		int loopCounter1 = 0, loopCounter2, loopCounter = 0, loopCounter3 = 0;
		
		ascendingSort (intArray);
		
		for (loopCounter1 = 0; loopCounter1 < intArray.length / 2; loopCounter1++)
		{
			newArray [loopCounter] = intArray [loopCounter1];
			loopCounter++;
		}
		
		descendingSort (intArray);
		
		if (intArray.length % 2 == 0)
		{
			for (loopCounter2 = 0; loopCounter2 < intArray.length / 2; loopCounter2++)
			{
				newArray [loopCounter] = intArray [loopCounter2];
				loopCounter++;
			}
		}
		else
		{
			for (loopCounter2 = 0; loopCounter2 <= intArray.length / 2; loopCounter2++)
			{
				newArray [loopCounter] = intArray [loopCounter2];
				loopCounter++;
			}
		}
		
		for (loopCounter3 = 0; loopCounter3 < newArray.length; loopCounter3++)
		{
			System.out.print (newArray [loopCounter3]);
		}
	}
	
	public static void ascendingSort (int [] intArray)
	{
		int loopCounter1 = 0, loopCounter2 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < intArray.length; loopCounter1++)
		{
			for (loopCounter2 = loopCounter1 + 1; loopCounter2 < intArray.length; loopCounter2++)
			{
				if (intArray [loopCounter1] > intArray [loopCounter2])
				{
					int temp = intArray [loopCounter1];
					intArray [loopCounter1] = intArray [loopCounter2];
					intArray [loopCounter2] = temp;
				}
			}
		}	
	}	
	
	public static void descendingSort (int [] intArray)
	{
		int loopCounter1 = 0, loopCounter2 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < intArray.length; loopCounter1++)
		{
			for (loopCounter2 = loopCounter1 + 1; loopCounter2 < intArray.length; loopCounter2++)
			{
				if (intArray [loopCounter1] < intArray [loopCounter2])
				{
					int temp = intArray [loopCounter1];
					intArray [loopCounter1] = intArray [loopCounter2];
					intArray [loopCounter2] = temp;
				}
			}
		}	
	}	
}