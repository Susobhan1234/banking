/*
Given two arrays of n numbers each, form a pair of numbers taking one number from array1
and the other from array2 such that the sum of the pair of this numbers is the maximum
possible for the given arrays. Take input from STDIN. Don’t use any sorting technique.
Example:
Input:
2 1 5 7 10
3 6 8 1 2
Output:
18
*/

public class FindHighesSumOfPair
{
	public static void main (String [] args)
	{
		int [] firstIntArray = new int [5];
		int [] secondIntArray = new int [5];
		int [] newArray = new int [50];
		
		firstIntArray [0] = 2;
		firstIntArray [1] = 1;
		firstIntArray [2] = 5;
		firstIntArray [3] = 7;
		firstIntArray [4] = 10;
		
		secondIntArray [0] = 3;
		secondIntArray [1] = 6;
		secondIntArray [2] = 8;
		secondIntArray [3] = 1;
		secondIntArray [4] = 2;
		
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, loopCounter4 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < firstIntArray.length; loopCounter1++)
		{
			for (loopCounter2 = 0; loopCounter2 < secondIntArray.length; loopCounter2++)
			{
				newArray [loopCounter3] = firstIntArray [loopCounter1] + secondIntArray [loopCounter2];
				loopCounter3++;
			}
		}
		
		sorting (newArray);
		System.out.print (newArray [0] );
	}
	
	public static void sorting (int [] intArray)
	{
		int loopCounter1 = 0, loopCounter2 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < intArray.length; loopCounter1++)
		{
			for (loopCounter2 = loopCounter1 + 1; loopCounter2 < intArray.length; loopCounter2++)
			{
				if (intArray [loopCounter1] < intArray [loopCounter2])
				{
					int temp = intArray [loopCounter1];
					intArray [loopCounter1] = intArray [loopCounter2];
					intArray [loopCounter2] = temp;
				}
			}
		}
	}
}