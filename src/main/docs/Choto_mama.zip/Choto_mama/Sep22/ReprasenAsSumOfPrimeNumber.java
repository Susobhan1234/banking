/*
You're given a number N and a positive integer K. Tell if N can be represented as a sum of K prime numbers (not necessarily distinct).
Input Format
The first line contains a single integer T, denoting the number of test cases.
Each of the next T lines contains two positive integers, N & K, separated by a single space.
Output Format
For every test case, output "Yes" or "No".
Input
2
10 2
1 6
Output
Yes
No
Test Cases:
1. VALID INPUTS:
a) Only integer will be given as input from STDIN.
Constraints
1 <= T <= 5000
1 <= N <= 1000
1 <= K <= 1000
2. INVALID INPUTS:
a) String.
b) Fraction.
c) Negative number.
3. OUTPUT:
a) Write the output to STDOUT without any other additional text.
b) In case of invalid input print 'ERROR' to the STDOUT without any other additional text and terminate.
*/

public class ReprasenAsSumOfPrimeNumber
{
	public static void main (String [] args)
	{
		String firstInputString = args [0];
		String secondInputString = args [1];
		
		int N = Integer.parseInt (firstInputString);
		int K = Integer.parseInt (secondInputString);
		int [] newArray = new int [10];
		
		int loopCounter1 = 0, sum = 0, loopCounter2 = 0, newLoopCounter = 0, loopCounter3 = 0;
		
		for (newLoopCounter = 1; newLoopCounter < N; newLoopCounter++)
		{
			boolean returnValue = prime (newLoopCounter); 
			
			if (returnValue == false)
			{
				newArray [loopCounter3] = newLoopCounter;
				loopCounter3++;
			}
		}
		
		boolean isFound = false;
		
		for (loopCounter1 = 0; loopCounter1 < newArray.length; loopCounter1++)
		{
			sum = 0;
			
			for (loopCounter2 = loopCounter1 + 1; loopCounter2 < newArray.length; loopCounter2++)
			{
				sum = newArray [loopCounter1] + newArray [loopCounter2];
				
				if (sum == N)
				{
					isFound = true;
					System.out.println ("Yes");
				}
			}
		}
		
		if (isFound == false)
		{
			System.out.println ("No");
		}
	}
	
	public static boolean prime (int number)
	{
		int loopCounter2 = 0;
		
		for (loopCounter2 = 2; loopCounter2 < number; loopCounter2++)
		{
			if (number % loopCounter2 == 0)
			{
				return true;
			}
		}
		
		return false;
	}
}