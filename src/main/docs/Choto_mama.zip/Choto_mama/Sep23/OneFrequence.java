/*
Write a C program to display all the unique (non-redundant) elements of an array. Take input from STDIN.
Example:
Input:
arr[]={2,1,2,3,4,1}
Output:
3, 4
*/

public class OneFrequence
{
	public static void main (String [] args)
	{
		int arr [] = new int [10];
		
		arr [0] = 2;
		arr [1] = 1;
		arr [2] = 2;
		arr [3] = 3;
		arr [4] = 4;
		arr [5] = 1;
		
		int loopCounter = 0;
		
		for (loopCounter = 0; loopCounter < arr.length; loopCounter++)
		{
			int searchingNumber = arr [loopCounter];
			int returnValue = searching (arr, searchingNumber);
			
			if (returnValue == 1)
			{
				System.out.println (searchingNumber);
			}
		}
	}
	
	public static int searching (int [] whereToSearch, int whatToSearch)
	{
		int loopCounter1 = 0, counter = 0;
		
		for (loopCounter1 = 0; loopCounter1 < whereToSearch.length; loopCounter1++)
		{
			if (whereToSearch [loopCounter1] == whatToSearch)
			{
				counter++;
			}
		}
		
		return counter;
	}
}