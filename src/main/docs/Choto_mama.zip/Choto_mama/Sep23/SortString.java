/*
Define a function to input a list of names and store them in an array and 
then perform bubble sort on the name list. Take input from command line argument.
Example:
Input:
Babar
Akbar
Nayan
Sayak
Ram
Amit

Output:
Akbar
Amit
Babar
Nayan
Ram
Sayak
*/

import java.util.Arrays;

public class SortString
{
	public static void main (String [] args)
	{
		String [] stringArray = new String [6];
		
		stringArray [0] = "Babar";
		stringArray [1] = "Akbar";
		stringArray [2] = "Nayan";
		stringArray [3] = "Sayak";
		stringArray [4] = "Ram";
		stringArray [5] = "Amit";
		
		int loopCounter = 0;
		
		Arrays.sort (stringArray);
		
		for (loopCounter = 0; loopCounter < stringArray.length; loopCounter++)
		{
			System.out.println (stringArray [loopCounter]);
		}
	}
}