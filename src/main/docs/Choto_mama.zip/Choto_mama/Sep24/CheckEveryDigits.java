/*
Write a program to check for a given integer, every digit and its neighbor digit differs by +1 or -
1. Take input from STDIN and display output Yes or No to STDOUT without any additional
text.
Examples:
Input:
7878
Output:
Yes
Input:
4554
Output:
No
*/


public class CheckEveryDigits
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		char [] charArr = inputString.toCharArray ();
		int [] intArr = new int [charArr.length];
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, loopCounter4 = 0;
		boolean flag = false;
		
		for (loopCounter1 = 0; loopCounter1 < charArr.length; loopCounter1++)
		{
			String newString = "" + charArr [loopCounter1];
			int newInt = Integer.parseInt (newString);
			intArr [loopCounter2] = newInt;
			loopCounter2++;
		}
		
		for (loopCounter3 = 1; loopCounter3 < intArr.length - 1; loopCounter3++)
		{
			int nextDigit = intArr [loopCounter3 + 1];
			int previousDigit = intArr [loopCounter3 - 1];
			
			if (((nextDigit == intArr [loopCounter3] + 1) || 
		     	(nextDigit == intArr [loopCounter3] - 1)) && 
				((previousDigit == intArr [loopCounter3] + 1) || 
				(previousDigit == intArr [loopCounter3] - 1)))
			{
				flag = true;
			}
		}
		
		if (flag == true)
		{
			System.out.println ("Yes");
		}
		else
		{
			System.out.println ("No");
		}
	}
}