/*
Given two positive numbers x and y, check if y is a power of x or not. Take input from STDIN
and display output Yes or No to STDOUT.
Examples:
Input: x=20, y=1
Output: Yes
Input: x=4, y=64 // for loop upto y
Output: Yes
Input: x=5, y=624
Output: No
*/


public class CheckPower
{
	public static void main (String [] args)
	{
		String firstInputString = args [0];
		int x = Integer.parseInt (firstInputString);
		String seceondInputString = args [1];
		int y = Integer.parseInt (seceondInputString);
		int loopCounter1 = 0, result = 1;
		boolean flag = false;
		
		for (loopCounter1 = 1; loopCounter1 < y; loopCounter1++)
		{			
			result = result * x;
			
			if (result == y)
			{
				flag = true;
			}
		}
		
		if (flag == true)
		{
			System.out.println ("Yes");
		}
		else
		{
			System.out.println ("No");
		}
	}
}
