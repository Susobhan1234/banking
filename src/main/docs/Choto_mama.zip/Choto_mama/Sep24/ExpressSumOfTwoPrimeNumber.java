/*
Given a number n. Express this number as sum of other two prime numbers. Take input from
STDIN and display output to STDOUT.
Examples:
Input: 24
Output: 11 13
Input: 12
Output: 5 7
Input: 11
Output: Can’t express as sum of two prime numbers
*/


public class ExpressSumOfTwoPrimeNumber
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		int intValue = Integer.parseInt (inputString);
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, loopCounter4 = 0, sum = 0;
		int [] intArr = new int [20];
		
		for (loopCounter1 = 1; loopCounter1 < intValue; loopCounter1++)
		{
			int number = loopCounter1;
			boolean returnValue = checkPrimeNumber (number);
			
			if (returnValue == true)
			{
				intArr [loopCounter2] = number;
				loopCounter2++;
			}
		}
		
		for (loopCounter3 = 0; loopCounter3 < intArr.length; loopCounter3++)
		{
			for (loopCounter4 = loopCounter3 + 1; loopCounter4 < intArr.length; loopCounter4++)
			{
				sum =  intArr [loopCounter3] + intArr [loopCounter4];
				
				if (sum == intValue)
				{
					System.out.print (intArr [loopCounter3] + " " + intArr [loopCounter4]);
				}
			}
		}
	}
	
	public static boolean checkPrimeNumber (int number)
	{
		int loopCounter2 = 0;
		
		for (loopCounter2 = 2; loopCounter2 < number; loopCounter2++)
		{
			if (number % loopCounter2 == 0)
			{
				return false;
			}
		}
		
		return true;
	}
}