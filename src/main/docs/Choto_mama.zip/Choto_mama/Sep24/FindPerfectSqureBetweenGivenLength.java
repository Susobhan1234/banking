/*
Given two given numbers x and y where 1<=x<y, find all the numbers which are perfect square
between x and y (x and y inclusive). Take input from STDIN and display output to STDOUT
without any additional text.
Example:
Input:
x=9
y=25
Output:
9 16 25
*/

public class FindPerfectSqureBetweenGivenLength
{
	public static void main (String [] args)
	{
		String firstInputString = args [0];
		String secondInputString = args [1];
		
		int firstInt = Integer.parseInt (firstInputString);
		int secondInt = Integer.parseInt (secondInputString);
		
		if ((firstInt >= 1) && (firstInt < secondInt))
		{
			int loopCounter1 = 0;
			
			for (loopCounter1 = firstInt; loopCounter1 <= secondInt; loopCounter1++)
			{
				boolean returnValue = findPerfectSquare (loopCounter1);
				
				if (returnValue == true)
				{
					System.out.print (loopCounter1 + " ");
				}
			}
		}		
		else 
		{
			System.out.println ("ERROR");
		}
	}
	
	public static boolean findPerfectSquare (int number)
	{
		int loopCounter = 0;
		
		for (loopCounter = 1; loopCounter <= number; loopCounter++)
		{
			int perfectSquare = loopCounter * loopCounter;
			
			if (perfectSquare == number)
			{
				return true;
			}
		}
		
		return false;
	}
}

// 9 to 10.30