/*
You are given a list of n-1 integers and these integers are in the range of 1 to n. There are no
duplicates in list. One of the integers is missing in the list. Write an efficient code to find the
missing integer. Take input from STDIN and display output to STDOUT without any additional
text.
Example:
Input:
{1, 2, 5, 6, 3, 4, 8}
Output:
7
*/


public class FoundMissingInteger
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		String [] stringArr = inputString.split (",");
		int [] intArr = new int [10];
		int [] intArr2 = new int [10];
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, loopCounter4 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < stringArr.length; loopCounter1++)
		{
			int intValue = Integer.parseInt (stringArr [loopCounter1]);
			intArr [loopCounter2] = intValue;
			loopCounter2++;
		}
		
		sort (intArr);
		int range = intArr [0];
		
		for (loopCounter3 = 1; loopCounter3 <= range; loopCounter3++)
		{
			intArr2 [loopCounter4] = loopCounter3;
			loopCounter4++;
		}
		
		for (int loopCounter5 = 0; loopCounter5 < intArr2.length; loopCounter5++)
		{
			int searchingNumber = intArr2 [loopCounter5];
			boolean returnvalue = search (intArr, searchingNumber);
			
			if (returnvalue == false)
			{
				System.out.println (searchingNumber);
			}
		}
	}
	
	public static void sort (int [] intArr)
	{
		int loopCounter1 = 0, loopCounter2 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < intArr.length; loopCounter1++)
		{
			for (loopCounter2 = loopCounter1 + 1; loopCounter2 < intArr.length; loopCounter2++)
			{
				if (intArr [loopCounter1] < intArr [loopCounter2])
				{
					int temp = intArr [loopCounter1];
					intArr [loopCounter1] = intArr [loopCounter2];
					intArr [loopCounter2] = temp;
				}
			}
		}
	}
	
	public static boolean search (int [] whereToSearch, int whatToSearch)
	{
		int loopCounter1 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < whereToSearch.length; loopCounter1++)
		{
			if (whereToSearch [loopCounter1] == whatToSearch)
			{
				return true;
			}
		}
		
		return false;
	}
}