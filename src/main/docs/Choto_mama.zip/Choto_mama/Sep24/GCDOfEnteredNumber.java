/*
Write a program to find GCD of its digits of a given number n. Take input from STDIN and
display output to STDOUT without any additional text.
Examples:
Input:
523
Output:
1
Input:
428
Output:
2
*/

public class GCDOfEnteredNumber
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		char [] charArr = inputString.toCharArray ();
		int [] intArr = new int [5]
		int loopCouner1 = 0, loopCouner2 = 0;
		
		for (loopCouner1 = 0; loopCouner1 < charArr.length; loopCouner1++)
		{
			String newString = "" + charArr [loopCouner1];
			int newInt = Integer.parseInt (newString);
			intArr [loopCouner2] = newInt;
			loopCouner2++;
		}
		
		for (loopCouner3 = 0; loopCouner3 < intArr.length; loopCouner3++)
		{
			
		}
	}
}