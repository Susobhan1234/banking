/*
Write a C program to merge two sorted array such that the output will be in sorted order. Take input from STDIN.
Example:
Input:
arr1[] = {1,3,4,5}
arr2[] = {-5,0,2,4}
Output:
{-5,0,1,2,3,4,4,5}
*/

public class MergeAndSortTwoArray 
{
	public static void main (String [] args)
	{
		int [] arr1 = new int [4];
		int [] arr2 = new int [4];
		int [] newArr = new int [8];
		arr1 [0] = 1;
		arr1 [1] = 3;
		arr1 [2] = 4;
		arr1 [3] = 5;
		
		arr2 [0] = -5;
		arr2 [1] = 0;
		arr2 [2] = 2;
		arr2 [3] = 4;
		
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < arr1.length; loopCounter1++)
		{
			newArr [loopCounter3] = arr1 [loopCounter1];
			loopCounter3++;
		}
		
		for (loopCounter2 = 0; loopCounter2 < arr2.length; loopCounter2++)
		{
			newArr [loopCounter3] = arr2 [loopCounter2];
			loopCounter3++;
		}
		
		sort (newArr);
		
		for (int counter = 0; counter < newArr.length; counter++)
		{
			System.out.print (newArr [counter] + " ");
		}
	}
	
	public static void sort (int [] arr)
	{
		int loopCounter = 0, loopCounter1 = 0;
		
		for (loopCounter = 0; loopCounter < arr.length; loopCounter++)
		{
			for (loopCounter1 = loopCounter + 1; loopCounter1 < arr.length; loopCounter1++)
			{
				if (arr [loopCounter] > arr [loopCounter1])
				{
					int temp = arr [loopCounter];
					arr [loopCounter] = arr [loopCounter1];
					arr [loopCounter1] = temp;
				}
			}
		}
	}
}