/*
Given two arrays, print all elements in sorted order that are not common of these arrays. Take
input from STDIN and display output to STDOUT without any additional text.
Example:
Input:
arr1[] = {3, 1, 5, 6, 11}
arr2[] = {5, 3, 7, 8}
Output:
{1, 6, 7, 8, 11}
*/

public class RemoveCommonInTwoArray
{
	public static void main (String [] args)
	{
		int [] arr1 = new int [5];
		int [] arr2 = new int [4];
		int [] newArr = new int [10];
		int loopCounter = 0, loopCounter2 = 0, loopCounter3 = 0, loopCounter4 = 0;
		
		arr1 [0] = 3;
		arr1 [1] = 1;
		arr1 [2] = 5;
		arr1 [3] = 6;
		arr1 [4] = 11;
		
		arr2 [0] = 5;
		arr2 [1] = 3;
		arr2 [2] = 7;
		arr2 [3] = 8;
		
		for (loopCounter = 0; loopCounter < arr1.length; loopCounter++)
		{
			int searchNumber = arr1 [loopCounter];
			boolean returnValue = search (arr2, searchNumber);
			
			if (returnValue == false)
			{
				newArr [loopCounter2] = searchNumber;
				loopCounter2++;
			}
		}
		
		for (loopCounter4 = 0; loopCounter4 < arr2.length; loopCounter4++)
		{
			int searchNumber = arr2 [loopCounter4];
			boolean returnValue2 = search (arr1, searchNumber);
			
			if (returnValue2 == false)
			{
				newArr [loopCounter2] = searchNumber;
				loopCounter2++;
			}
		}
		
		sort (newArr);
		
		for (loopCounter3 = 0; loopCounter3 < newArr.length; loopCounter3++)
		{
			if (newArr [loopCounter3] != 0)
			{
				System.out.print (newArr [loopCounter3] + " ");
			}
		}
	}
	
	public static boolean search (int [] whereToSearch, int whatToSearch)
	{
		int loopCounter1 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < whereToSearch.length; loopCounter1++)
		{
			if (whereToSearch [loopCounter1] == whatToSearch)
			{
				return true;
			}
		}
		
		return false;
	}
	
	public static void sort (int [] arr)
	{
		int loopCounter = 0, loopCounter1 = 0;
		
		for (loopCounter = 0; loopCounter < arr.length; loopCounter++)
		{
			for (loopCounter1 = loopCounter + 1; loopCounter1 < arr.length; loopCounter1++)
			{
				if (arr [loopCounter] > arr [loopCounter1])
				{
					int temp = arr [loopCounter];
					arr [loopCounter] = arr [loopCounter1];
					arr [loopCounter1] = temp;
				}
			}
		}
	}
} 