/*
Write a C program to remove consonants and digits from a String. Take input from command
line argument.
Example:
Input:
Academy1
Output:
cdmy
Test Cases:
-----------
1. VALID inputs:
a) Only one argument will be given as input.
2. INVALID inputs:
a) No argument
b) Two or more than two arguments.
3. Generate output as follows:
a) Print the string to the STDOUT.
b) If error print 'ERROR' to the STDOUT without any additional text.
*/

public class RemoveConsonant
{
	public static void main (String [] args)
	{
		String inputString = "";
		
		if (args.length != 1)
		{
			System.out.println ("ERROR");
			return;
		}
		
		inputString = args [0];
		char [] charArray = inputString.toCharArray ();
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0;
		char [] newCharArray = new char [20];
		
		for (loopCounter1 = 0; loopCounter1 < charArray.length; loopCounter1++)
		{
			if ((charArray [loopCounter1] != 'A') || 
			(charArray [loopCounter1] != 'E') || 
			(charArray [loopCounter1] != 'I') || 
			(charArray [loopCounter1] != 'O') || 
			(charArray [loopCounter1] != 'U') ||
			(charArray [loopCounter1] != 'a') || 
			(charArray [loopCounter1] != 'e') ||
			(charArray [loopCounter1] != 'i') ||
			(charArray [loopCounter1] != 'o') ||
			(charArray [loopCounter1] != 'u'))
			{
				newCharArray [loopCounter2] = charArray [loopCounter1];
				loopCounter2++;
			}
		}
		
		for (loopCounter3 = 0; loopCounter3 < newCharArray.length; loopCounter3++)
		{
			System.out.print (newCharArray [loopCounter3]);
		}
	}
}