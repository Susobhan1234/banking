/*
Write a C program to display all the array elements in ascending order after removing duplicate elements. Take input from STDIN.
Example:
Input:
arr[]={2, 1, 2, 3, 4, 1}
Output:
1, 2, 3, 4
*/


public class RemoveDuplicateAndPrintAsscending
{
	public static void main (String [] args)
	{
		int [] arr = new int [6];
		arr [0] = 2;
		arr [1] = 1;
		arr [2] = 2;
		arr [3] = 3;
		arr [4] = 4;
		arr [5] = 1;
		
		int [] newArr = new int [6];
		int loopCounter = 0, loopCounter2 = 0, loopCounter1 = 0;
		
		for (loopCounter = 0; loopCounter < arr.length; loopCounter++)
		{
			int searchingNumber = arr [loopCounter];
			boolean returnValue = search (newArr, searchingNumber);
			
			if (returnValue == false && searchingNumber != 0)
			{
				newArr [loopCounter1] = searchingNumber;
				loopCounter1++;
			}
		}
		
		sort (newArr);
		
		for (loopCounter2 = 0; loopCounter2 < newArr.length; loopCounter2++)
		{
			if (newArr [loopCounter2] != 0)
			{
				System.out.print (newArr [loopCounter2] + " ");
			}
		}
	}
	
	public static boolean search (int [] whereToSearch, int whatToSearch)
	{
		int loopCounter1 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < whereToSearch.length; loopCounter1++)
		{
			if (whereToSearch [loopCounter1] == whatToSearch)
			{
				return true;
			}
		}
		
		return false;
	}
	
	public static void sort (int [] arr)
	{
		int loopCounter = 0, loopCounter1 = 0;
		
		for (loopCounter = 0; loopCounter < arr.length; loopCounter++)
		{
			for (loopCounter1 = loopCounter + 1; loopCounter1 < arr.length; loopCounter1++)
			{
				if (arr [loopCounter] > arr [loopCounter1])
				{
					int temp = arr [loopCounter];
					arr [loopCounter] = arr [loopCounter1];
					arr [loopCounter1] = temp;
				}
			}
		}
	}
}