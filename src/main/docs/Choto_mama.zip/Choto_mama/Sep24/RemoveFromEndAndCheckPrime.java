/*
Write a program to count the number of prime numbers formed by removing digits from that
number from the back. (Including the number itself) Take input from STDIN and display output
to STDOUT without any additional text.
Example:
Input:
135
Output:
1
Explanation: 135 is not prime, 13 (by removing 5 from last) is prime, but 1 is not prime
*/


public class RemoveFromEndAndCheckPrime
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		int counter = 1, loopCounter1 = 0, newCounter = 0;
		
		for (loopCounter1 = 0; loopCounter1 < inputString.length () - 1; loopCounter1++)
		{
			String newString = inputString.substring (0, inputString.length () - counter);
			counter++;
			
			int newInt = Integer.parseInt (newString);
			
			boolean returnValue = checkPrimeNumber (newInt);
			
			if (returnValue == true)
			{
				newCounter++;
			}
		}
		
		System.out.println (newCounter);
	}
	
	public static boolean checkPrimeNumber (int number)
	{
		int loopCounter1 = 0;
		
		if (number == 1)
		{
			return false;
		}
		
		for (loopCounter1 = 2; loopCounter1 < number; loopCounter1++)
		{
			if (number % loopCounter1 == 0)
			{
				return false;
			}
		}
		
		return true;
	}
}