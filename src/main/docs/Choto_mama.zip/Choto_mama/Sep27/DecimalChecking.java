public class DecimalChecking
{
	public static void main (String [] args)
	{
		String inputString = args [0];
		
		try 
		{
			int number = Integer.parseInt (inputString);
			System.out.println ("This is an integer number");
		}
		catch (Exception ex)
		{
			int indexNumber = inputString.indexOf (".");
			
			// System.out.println (indexNumber);
			
			try
			{
				String firstSubString = inputString.substring (0, indexNumber);
				
				System.out.println (firstSubString);
				
				int firstIntValue = Integer.parseInt (firstSubString);
				
				String secondSubString = inputString.substring (indexNumber + 1, inputString.length ());
				
				System.out.println (secondSubString);
				
				int secondIntValue = Integer.parseInt (secondSubString);
				
				System.out.println ("This is a decimal number");
			}
			catch (Exception e)
			{
				System.out.println ("Invalid input");
			}
		}
	}
}