// C program to display the sequence 1, 4, 9, 16, 25, 36, 49,………………


public class DisplayNewSequence
{
	public static void main (String [] args)
	{
		int range = 7, loopCounter = 0;
		
		for (loopCounter = 1; loopCounter <= range; loopCounter++)
		{
			int number = loopCounter * loopCounter;
			System.out.print (number + ", ");
		}
	}
}