// program to display the sequence 1, 2, 2, 4, 8, 32, 256,……………….


public class DisplaySequence
{
	public static void main (String [] args)
	{
		int range = 7, loopCounter = 0;
		int firstNumber = 1, secondNumber = 2;
		
		System.out.print (firstNumber + " " + secondNumber + " ");
		
		for (loopCounter = 3; loopCounter <= range; loopCounter++)
		{
			int number = firstNumber * secondNumber;
			firstNumber = secondNumber; 
			secondNumber = number;
			
			System.out.print (number + " ");
		}
	}
}