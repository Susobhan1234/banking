// program to display the sequence 1, 2, 4, 8, 16, 32, 64,…



public class DisplaySequence2
{
	public static void main (String [] args)
	{
		int range = 7, loopCounter = 0, number = 1;
		System.out.print (number + " ");
		
		for (loopCounter = 2; loopCounter <= range; loopCounter++)
		{
			number = number * 2;
			System.out.print (number + " ");
		}
	}
}