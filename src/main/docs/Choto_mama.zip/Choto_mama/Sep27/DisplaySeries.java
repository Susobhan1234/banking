//program to display the series 0,0,2,1,4,2,6,3,8,4

public class DisplaySeries
{
	public static void main (String [] args)
	{
		int range = 4, loopCounter1 = 0, loopCounter2 = 0, value = 1, value2 = 1;
		
		System.out.print ("0 ");
		System.out.print ("0 ");
		
		for (loopCounter1 = 1; loopCounter1 <= range; loopCounter1++)
		{
			value = loopCounter1 * 2;
			value2 = loopCounter1 * 1;
			System.out.print (value + " " + value2 + " ");
		}
	}
}