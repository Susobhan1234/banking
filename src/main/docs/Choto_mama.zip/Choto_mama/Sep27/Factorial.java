// program to find factorial of a number.


public class Factorial
{
	public static void main (String [] args)
	{
		String inputString = "";
		
		if (args.length != 1)
		{
			System.out.println ("Error");
			return;
		}
		
		inputString = args [0];
		int number = Integer.parseInt (inputString);
		
		int loopCounter = 0, factorial = 1;
		
		for (loopCounter = 1; loopCounter <= number; loopCounter++)
		{
			factorial = factorial * loopCounter;
		}
		
		System.out.println (factorial);
	}
}