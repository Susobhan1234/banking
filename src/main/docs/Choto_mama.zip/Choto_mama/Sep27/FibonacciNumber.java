//program to display Fibonacci sequence 0, 1, 1, 2, 3, 5, 8,…………


public class FibonacciNumber
{
	public static void main (String [] args)
	{
		int range = 10, firstNumber = 0, secondNumber = 1;
		int loopCounter = 0;
		
		System.out.print (firstNumber + " " + secondNumber + " ");
		
		for (loopCounter = 3; loopCounter <= range; loopCounter++)
		{
			int number = firstNumber + secondNumber;
			firstNumber = secondNumber;
			secondNumber = number;
			
			System.out.print (number + " ");
		}
	}
}