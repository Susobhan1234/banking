import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;

public class FileProcessing
{
	public static void main (String [] args)
	{
		try
		{
			File fileObject = new File ("C:\\Users\\Rana\\Desktop\\Choto_mama\\Sep27\\NewFile.txt");
			FileReader readerObject = new FileReader (fileObject);
			BufferedReader bufferObject = new BufferedReader (readerObject);
			
			String lineString = "";
			int totalNumberOfChar = 0, numberOfLine = 0, numberOfWord = 0;
			
			while ((lineString = bufferObject.readLine ()) != null)
			{
				totalNumberOfChar = totalNumberOfChar + lineString.length ();
				numberOfLine = numberOfLine + 1;
				String [] stringArr = lineString.split (" ");
				numberOfWord = numberOfWord + stringArr.length;
			}
			
			System.out.println ("Number of charecter " + totalNumberOfChar);
			System.out.println ("Number of line " + numberOfLine);
			System.out.println ("Number of word " + numberOfWord);
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
	}
}
