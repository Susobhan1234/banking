public class LCM
{
	public static void main (String [] args)
	{
		int x = 25;
		int [] arr1 = new int [20];
		factor (x, arr1);
		
		int y = 9;
		int [] arr2 = new int [20];
		factor (y, arr2);
		
		int [] newArr1 = new int [100];
		int [] newArr2 = new int [100];
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, loopCounter4 = 0, lcm = 1, loopCounter5 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < arr1.length; loopCounter1++)
		{
			newArr1 [loopCounter2] = arr1 [loopCounter1];
			loopCounter2++;
		}
		
		for (loopCounter3 = 0; loopCounter3 < arr2.length; loopCounter3++)
		{
			int searchingNumber = arr2 [loopCounter3];
			
			int occuranceSearchingNuberInArr1 = searchingOccurance (arr1, searchingNumber);
			int occuranceSearchingNuberInArr2 = searchingOccurance (arr2, searchingNumber);
			
			boolean returnValue = numberSearching (newArr2, searchingNumber);
			
			if (returnValue == false)
			{
				newArr2 [loopCounter4] = searchingNumber;
				loopCounter4++;
				
				if (occuranceSearchingNuberInArr2 > occuranceSearchingNuberInArr1)
				{
					int range = occuranceSearchingNuberInArr2 - occuranceSearchingNuberInArr1;
					int loopCounter = 0;
					
					for (loopCounter = 1; loopCounter <= range; loopCounter++)
					{
						newArr1 [loopCounter2] = searchingNumber;
						loopCounter2++;
					}
				}
			}
		}
		
		for (loopCounter5 = 0; loopCounter5 < newArr1.length; loopCounter5++)
		{
			if ( newArr1 [loopCounter5] != 0)
			{
				lcm = lcm * newArr1 [loopCounter5];
			}
		}
		
		System.out.println (lcm);
	}
	
	public static void factor (int number, int [] arr)
	{
		int loopCounter1 = 0, loopCounter2 = 0;
		
		for (loopCounter1 = 2; loopCounter1 < number; loopCounter1++)
		{
			if (number % loopCounter1 == 0)
			{
				int result = number / loopCounter1;
				
				arr [loopCounter2] = loopCounter1;
				loopCounter2++;
				
				number = result;
				loopCounter1 = 1;
			}
		}
		
		arr [loopCounter2] = number;
	}
	
	public static int searchingOccurance (int [] whereToSearch, int whatTosearch)
	{
		int loopCounter1 = 0, counter = 0;
		
		for (loopCounter1 = 0; loopCounter1 < whereToSearch.length; loopCounter1++)
		{
			if (whereToSearch [loopCounter1] == whatTosearch)
			{
				counter++;
			}	
		}
		
		return counter;
	}
	
	public static boolean numberSearching (int [] whereToSearch, int whatTosearch)
	{
		int loopCounter1 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < whereToSearch.length; loopCounter1++)
		{
			if (whereToSearch [loopCounter1] == whatTosearch)
			{
				return true;
			}	
		}
		
		return false;
	}
}