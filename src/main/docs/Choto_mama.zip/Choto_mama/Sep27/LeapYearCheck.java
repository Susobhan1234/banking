// program to check leap year.

public class LeapYearCheck
{
	public static void main (String [] args)
	{
		String inputString = "";
		
		if (args.length != 1)
		{
			System.out.println ("Error");
			return;
		}
		
		try 
		{
			inputString = args [0];
			int year = Integer.parseInt (inputString);
			
			if (((year % 4 == 0) && (year % 100 != 0)) || ((year % 100 == 0) && (year % 400 == 0)))
			{
				System.out.println ("Leap Year");
			}
			else
			{
				System.out.println ("Not Leap Year");
			}
		}
		catch (Exception ex)
		{
			System.out.println ("Invalid Input");
		}
	}
}