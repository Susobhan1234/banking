// program to display the sequence BCA1, BCB2, BCC3, BCD4, ……………


public class NewSequence10
{
	public static void main (String [] args)
	{
		int range = 69, loopCounter = 0, count = 0;
		for (loopCounter = 65; loopCounter < 69; loopCounter++)
		{
			char charValue = (char) loopCounter;
			count++;
			
			System.out.print ("BC" + charValue + "" + count + " ");
		}
	}
}