// program to display the sequence 1, 2, 4, 7,11,……………



public class NewSequence4 
{
	public static void main (String [] args)
	{
		int range = 5, loopCounter = 0, number = 1;
		System.out.print (number + " ");
		
		for (loopCounter = 1; loopCounter < range; loopCounter++)
		{
			number = number + loopCounter;
			
			System.out.print (number + " ");
		}
	}
}