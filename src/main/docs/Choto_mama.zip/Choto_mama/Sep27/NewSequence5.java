// program to display the sequence 1, 1, 5, 5, 9, 9, 13, 13, ………………………


public class NewSequence5 
{
	public static void main (String [] args)
	{
		int range = 8, loopCounter = 0, number = 1;
		System.out.print (number + " " + number + " ");
		
		for (loopCounter = 2; loopCounter <= range / 2; loopCounter++)
		{
			number = number + 4;
			System.out.print (number + " " + number + " ");
		}
	}
}