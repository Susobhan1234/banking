// program to display the sequence 21, 9, 21, 11, 21, 13, 21, .................


public class NewSequence6
{
	public static void main (String [] args)
	{
		int range = 7, loopCounter = 0, firstNumber = 21, secondNumber = 9;
		
		System.out.print (firstNumber + " " + secondNumber + " ");
		
		for (loopCounter = 2; loopCounter <= range / 2; loopCounter++)
		{
			secondNumber = secondNumber + 2;
			System.out.print (firstNumber + " " + secondNumber + " ");
		}
		
		System.out.print (firstNumber);
	}
}