// program to display the sequence 14, 28, 20, 40, 32, 64, 


public class NewSequence7
{
	public static void main (String [] args)
	{
		int range = 10, loopCounter = 0, firstNumber = 14;
		int secondNumber = firstNumber * 2;
		System.out.print (firstNumber+ " " + secondNumber + " ");
		
		for (loopCounter = 1; loopCounter < range / 2; loopCounter++)
		{
			firstNumber = firstNumber + (6 * loopCounter);
			secondNumber = firstNumber * 2;
			System.out.print (firstNumber + " " + secondNumber + " ");
		}
	}
}