// program to display the sequence A1, B2, C4, D8, E16, F32, .................


public class NewSequence8
{
	public static void main (String [] args)
	{
		int range = 10, loopCounter1 = 0, value = 1;
		
		for (loopCounter1 = 65; loopCounter1 < 65 + range; loopCounter1++)
		{
			char charvalue = (char) loopCounter1;
			int number = value;
			System.out.print (charvalue + "" + number + " ");
			value = number * 2;
		}
	}
}