// program to display the sequence A1, B2, C3, …., Y25,Z26, A1, B2,…



public class NewSequence9
{
	public static void main (String [] args)
	{
		int range = 90, loopCounter = 0, count = 0;
		
		for (loopCounter = 65; loopCounter <= 90; loopCounter++)
		{
			char charValue = (char) loopCounter;
			count++;
			
			System.out.print (charValue + "" + count + " ");
		}
	}
}