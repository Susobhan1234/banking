// program to display the series 1, 3, 5, 7, 9,


public class OddNumber
{
	public static void main (String [] args)
	{
		int range = 10;
		int loopCounter = 0;
		
		for (loopCounter = 1; loopCounter <= range; loopCounter++)
		{
			int number = ((2 * loopCounter) - 1);
			System.out.print (number + " ");
		}
	}
}