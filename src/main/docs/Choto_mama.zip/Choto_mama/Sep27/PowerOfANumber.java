// program to calculate the power of a number

public class PowerOfANumber
{
	public static void main (String [] args)
	{
		int x = 5, y = 4, power = 1;
		
		int loopCounter = 0;
		
		for (loopCounter = 1; loopCounter <= y; loopCounter++)
		{
			power = power * x;
		}
		
		System.out.println (power);
	}
}