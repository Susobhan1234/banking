// program to calculate the sum of n natural numbers.


public class SumOfNaturalNumber
{
	public static void main (String [] args)
	{
		int range = 10;
		int loopcounter = 0, sum = 0;
		
		for (loopcounter = 1; loopcounter <= range; loopcounter++)
		{
			sum = sum + loopcounter;
		}
		
		System.out.print (sum);
	}
}