/*
1	1	1	1
1	1	1	1
1	1	1	1
1	1	1	1
*/


public class Q1
{
	public static void main (String [] args)
	{
		int loopCountr1 = 0, loopCountr2 = 0;
		
		for (loopCountr1 = 1; loopCountr1 <= 4; loopCountr1++)
		{
			for (loopCountr2 = 1; loopCountr2 <= 4; loopCountr2++)
			{
				System.out.print ("1\t");
			}
			
			System.out.println ("");
		}
	}
}