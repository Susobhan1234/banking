/*
9	10	11	12
6	7	8
5	4
3
*/

public class Q10
{
	public static void main (String [] args)
	{
		int loopCounter1 = 0, loopCounter2 = 0, number = 9, range = 4, loopCounter3 = 0;
		int number2 = number - 3;
		
		for (loopCounter1 = 1; loopCounter1 <= 1; loopCounter1++)
		{
			for (loopCounter2 = 1; loopCounter2 <= range; loopCounter2++)
			{
				System.out.print (number + "\t");
				number++;
			}
			
			System.out.println ("");
			
			for (loopCounter3 = 1; loopCounter3 <= range - 1; loopCounter3++)
			{
				System.out.print (number2 + "\t");
				number2++;
			}
		}
		
		
	}
}