/*
1	2	3	4
5	6	7	8	
9	10	11	12
13	14	15	16
*/


public class Q11
{
	public static void main (String [] args)
	{
		int loopCounter1 = 0, loopCounter2 = 0, number = 1;
		
		for (loopCounter1 = 1; loopCounter1 <= 4; loopCounter1++)
		{
			for (loopCounter2 = 1; loopCounter2 <= 4; loopCounter2++)
			{
				System.out.print (number + "\t");
				number++;
			}
			
			System.out.println ("");
		}
	}
}