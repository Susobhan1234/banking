/*

*
*	*
*	*	*
*	*	*	*
*	*	*	
*	*
*

*/

public class Q14
{
	public static void main (String [] args)
	{
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, loopCounter4 = 0, range = 3;
		
		for (loopCounter1 = 1; loopCounter1 <= 4; loopCounter1++)
		{
			for (loopCounter2 = 1; loopCounter2 <= loopCounter1; loopCounter2++)
			{
				System.out.print ("*\t");
			}
			
			System.out.println ("");
		}
		
		for (loopCounter3 = 1; loopCounter3 <= 3; loopCounter3++)
		{
			for (loopCounter4 = 1; loopCounter4 <= range; loopCounter4++)
			{
				System.out.print ("*\t");
			}
			
			range--;
			System.out.println ("");n
		}
	}
}