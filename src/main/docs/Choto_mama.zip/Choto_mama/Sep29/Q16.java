/*
			*
		*	*
	*	*	*
*	*	*	*
	*	*	*
		*	*
			*
*/



public class Q16
{
	public static void main (String [] args)
	{
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, loopCounter4 = 0, loopCounter5 = 0,loopCounter6 = 0;
		
		for (loopCounter1 = 1; loopCounter1 <= 4; loopCounter1++)
		{
			for (loopCounter2 = 1; loopCounter2 <= 4 - loopCounter1; loopCounter2++)
			{
				System.out.print ("\t");
			}
			
			for (loopCounter3 = 1; loopCounter3 <= loopCounter1; loopCounter3++)
			{
				System.out.print ("*\t");
			}
			
			System.out.println ("");
		}
		
		for (loopCounter4 = 1; loopCounter4 <= 3; loopCounter4++)
		{
			for (loopCounter5 = 1; loopCounter5 <= loopCounter4; loopCounter5++)
			{
				System.out.print ("\t");
			}
			
			for (loopCounter6 = 3; loopCounter6 >= loopCounter4; loopCounter6--)
			{
				System.out.print ("*\t");
			}
			
			System.out.println ("");
		}
	}
}