/*

				*
			*	*	*
		*	*	*	*	*
	*	*	*	*	*	*	*
*	*	*	*	*	*	*	*	*
	*	*	*	*	*	*	*
		*	*	*	*	*
			*	*	*
				*
				
*/


public class Q19
{
	public static void main (String [] args)
	{
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, loopCounter4 = 0, loopCounter5 = 0, loopCounter6 = 0, range = 5 , range2 = 7;
		
		for (loopCounter1 = 1; loopCounter1 <= 5; loopCounter1++)
		{
			for (loopCounter2 = 1; loopCounter2 <= range - loopCounter1; loopCounter2++)
			{
				System.out.print ("\t");
			}
			
			for (loopCounter3 = 1; loopCounter3 <= (2 * loopCounter1) - 1; loopCounter3++)
			{
				System.out.print ("*\t");
			}
			
			System.out.println ("");
		}
		
		for (loopCounter4 = 1; loopCounter4 <= 4; loopCounter4++)
		{
			for (loopCounter5 = 1; loopCounter5 <= loopCounter4; loopCounter5++)
			{
				System.out.print ("\t");
			}
			
			for (loopCounter6 = 1; loopCounter6 <= range2; loopCounter6++)
			{
				System.out.print ("*\t");
			}
			
			range2 = range2 - 2;
			System.out.println ("");
		}
	}
}