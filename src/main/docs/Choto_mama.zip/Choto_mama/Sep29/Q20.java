/*


*						*
*	*				*	*
*	*	*		*	*	*
*	*	*	*	*	*	*
*	*	*		*	*	*
*	*				*	*	
*						*


*/

public class Q20
{
	public static void main (String [] args)
	{
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, range = 5, loopCounter4 = 0;
		int loopCounter5 = 0, loopCounter6 = 0, loopCounter7 = 0, range2 = 3, loopCounter8 = 0;
		
		for (loopCounter1 = 1; loopCounter1 <= 4; loopCounter1++)
		{
			for (loopCounter2 = 1; loopCounter2 <= loopCounter1; loopCounter2++)
			{
				System.out.print ("*\t");
			}
			
			for (loopCounter3 = 1; loopCounter3 <= range; loopCounter3++)
			{
				System.out.print ("\t");
			}
			
			for (loopCounter4 = 1; loopCounter4 <= loopCounter1; loopCounter4++)
			{
				if (loopCounter4 != 4)
				{
					System.out.print ("*\t");
				}
			}
			
			range = range - 2;
			System.out.println ("");
		}
		
		for (loopCounter5 = 1; loopCounter5 <= 3; loopCounter5++)
		{
			for (loopCounter6 = 1; loopCounter6 <= range2; loopCounter6++)
			{
				System.out.print ("*\t");
			}
			
			for (loopCounter7 = 1; loopCounter7 <= (2 * loopCounter5) - 1; loopCounter7++)
			{
				System.out.print ("\t");
			}
			
			for (loopCounter8 = 1; loopCounter8 <= range2; loopCounter8++)
			{
				System.out.print ("*\t");
			}
			
			range2 = range2 - 1;
			System.out.println ("");
		}
	}
}