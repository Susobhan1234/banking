/*
			1			
		2		2
	3		3		3
4		4		4		4	
*/		



public class Q5
{
	public static void main (String [] args)
	{
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, number = 1;
		
		for (loopCounter1 = 1; loopCounter1 <= 4; loopCounter1++)
		{
			for (loopCounter2 = 1; loopCounter2 <= 4 - loopCounter1; loopCounter2++)
			{
				System.out.print ("\t");
			}
			
			for (loopCounter3 = 1; loopCounter3 <= number; loopCounter3++)
			{
				System.out.print (number + "\t\t");
			}
			
			System.out.println ("");
			number++;
		}
	}
}