/*
1
2	3
4	5	6
7	8	9	10
*/


public class Q6
{
	public static void main (String [] args)
	{
		int loopCounter = 0, loopCounter2 = 0, number = 1;
		
		for (loopCounter = 1; loopCounter <= 4; loopCounter++)
		{
			for (loopCounter2 = 1; loopCounter2 <= loopCounter; loopCounter2++)
			{
				System.out.print (number + "\t");
				number++;
			}
			
			System.out.println ("");
		}
	}
}