/*
6	6	6	6
5	5	5
4	4
3
*/



public class Q7
{
	public static void main (String [] args)
	{
		int loopCounter1 = 0, loopCounter2 = 0, number = 6, range = 4;
		
		for (loopCounter1 = 1; loopCounter1 <= 4; loopCounter1++)
		{
			for (loopCounter2 = 1; loopCounter2 <= range; loopCounter2++)
			{
				System.out.print (number + "\t");
				
			}
			
			System.out.println ("");
			number--;
			range--;
		}
	}
}