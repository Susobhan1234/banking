/*

*	*	*	*	*	*	*	*	*
	*	*	*	*	*	*	*
		*	*	*	*	*
			*	*	*
				*
*/

public class Q17
{
	public static void main ()
	{
		int loopCounter1 = 0, loopCounter2 = 0, loopCounter3 = 0, range = 9;
		
		for (loopCounter1 = 1; loopCounter1 <= 5; loopCounter1++)
		{
			for (loopCounter2 = 1; loopCounter2 <= loopCounter1 - 1; loopCounter2++)
			{
				System.out.print ("\t");
			}
			
			for (loopCounter3 = 1; loopCounter3 <= range; loopCounter3++)
			{
				System.out.print ("*\t");
			}
			
			range = range - 2;
			System.out.println ("");
		}
	}
}