// factorial // int number using try catch;

public class Factorial
{
	public static void main (String [] args)
	{
		String firstString = ""; 
		
		if (args.length != 1)
		{
			System.out.println ("You must enter only one argument.");
			return;
		}
		
		firstString = args [0];
		int fact = 1, loopCounter = 0;
		
		try
		{
			int number = Integer.parseInt (firstString);
			
			for (loopCounter = 1; loopCounter <= number; loopCounter++)
			{
				fact = fact * loopCounter;
			}
			
			System.out.println (fact);
		}
		catch (Exception e)
		{
			System.out.println ("Error");
		}
	}
}
