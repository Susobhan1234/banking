public class FindLastTwoChar
{
	public static void main (String [] args)
	{
		String firstString = ""; 
		
		if (args.length != 1)
		{
			System.out.println ("You must enter only one argument.");
			return;
		}
		
		firstString = args [0];
		int counter = 0;
		
		String [] firstStringSplit = firstString.split (" ");
		
		String lastWord = firstStringSplit [firstStringSplit.length - 1];
		
		if (lastWord.length() < 2)
		{
			System.out.println ("ERROR");
		}
		
		else if (lastWord.length() == 2)
		{
			System.out.println (lastWord);
		}
		else
		{
			String lastTwoChar = lastWord.substring (lastWord.length() - 2, lastWord.length ());
			System.out.println (lastTwoChar);
		}
		
		for (counter = 0; counter < firstStringSplit.length; counter++)
		{
			if (counter == firstStringSplit.length - 1)
			{
				String lastString = firstStringSplit [counter];
				
				char [] lastStringChar = lastString.toCharArray ();
				int loopCounter = 0;
		
				for (loopCounter = lastStringChar.length - 2; loopCounter < lastStringChar.length; loopCounter++)
				{
					System.out.print (lastStringChar[loopCounter]);
				}
			}
		}
	}
}