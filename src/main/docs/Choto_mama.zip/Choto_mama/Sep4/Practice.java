//  My name is Susobhan    

public class Practice
{
	public static void main (String [] args)
	{
		String firstString = ""; 
		String secondString = "";
		
		if (args.length != 2)
		{
			System.out.println ("You must enter only two argument.");
			return;
		}
		
		firstString = args [0];
		secondString = args [1];
		
		try
		{
			double firstStringDouble = Double.parseDouble (firstString);
			double secondStringDouble = Double.parseDouble (secondString);
			
			double avg = ((firstStringDouble + secondStringDouble) / 2);
			
			System.out.println (avg);
		}
		catch (Exception e)
		{
			System.out.println ("Error");
		}
	}
}