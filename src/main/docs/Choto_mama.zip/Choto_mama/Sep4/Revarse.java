//  My name is Susobhan    

public class Reverse
{
	public static void main (String [] args)
	{
		String firstString = ""; 
		
		if (args.length != 1)
		{
			System.out.println ("You must enter only one argument.");
			return;
		}
		
		firstString = args [0];
		
		String [] firstStringSplit = firstString.split (" ");
		
		System.out.println (firstStringSplit.length);
	}
}