/*Input:
Original string: Abcdabxabxaycdy
Substring: abxay
Output: Present
Input:
Original string: Abcdabxabxaycdy
Substring: abxayd
Output: Not Present */


public class Practice
{
	public static void main (String [] args)
	{
		String firstString = args [0];
		String secondString = args [1];
		
		int index = firstString.indexOf (secondString);
		
		if (index == -1)
		{
			System.out.println ("Not Present");
		}
		else
		{
			System.out.println("Present");
		}
	}
}