public class Sorting
{
	public static void main (String [] args)
	{
		int [] intArray = new int [10];
		
		intArray [0] = 5;
		intArray [1] = 4;
		intArray [2] = 3;
		intArray [3] = 2;
		intArray [4] = 1;
		intArray [5] = 0;
		intArray [6] = 9;
		intArray [7] = 8;
		intArray [8] = 7;
		intArray [9] = 6;
		
		int loopCounter = 0;
		
		sortingNumbers (intArray);
		
		for (loopCounter = 0; loopCounter < intArray.length; loopCounter++)
		{
			System.out.println (intArray [loopCounter]);
		}
	}

	public static void sortingNumbers (int [] numberArray) // 8 4 1 7
	{
		int firstCounter = 0;
		int secoundCounter = 0;

		for (firstCounter = 0; firstCounter < numberArray.length; firstCounter++)
		{
			for (secoundCounter = firstCounter + 1; secoundCounter < numberArray.length; secoundCounter++)
			{
				if (numberArray [firstCounter] < numberArray [secoundCounter])
				{
					int temp = numberArray [firstCounter];
					numberArray [firstCounter] = numberArray [secoundCounter];
					numberArray [secoundCounter] = temp;
				}
			}
		}
	}
}

