// Susobhan
// su
public class IndexOfmethod
{
	public static void main (String [] args)
	{
		String firstString = "";
		String secondString = "";
		
		if (args.length != 2)
		{
			System.out.println ("You must enter only two string.");
			return;
		}
		
		firstString = args [0];
		secondString = args [1];
		
		int returnValue = searching (firstString, secondString);
		
		if (returnValue == -1)
		{
			System.out.println ("Not found");
		}
		else
		{
			System.out.println ("Found");
		}
	}
	
	public static int searching (String whereSearching, String searchingString)
	{
		
		int indexNumber = whereSearching.indexOf (searchingString);
		return indexNumber;
	}
}