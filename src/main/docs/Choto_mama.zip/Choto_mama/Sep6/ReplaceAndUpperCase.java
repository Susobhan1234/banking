/* program to replace a word in a sentence by another given word. Convert first character of each word to uppercase before displaying the output. Take input from command line.
Example:
Input:
string[] = "be-- Never re--"
oldWord[] = "--"
newWord[] = "st"
Output: Best Never Rest */

 // First char of every word in a string should be uppercase
 
public class ReplaceAndUpperCase
{
	public static void main (String [] args)
	{
		String mainString = args [0];
		String whatReplaceing = args [1];
		String replaceingBy = args [2];
		
		String newString = mainString.replaceAll (whatReplaceing, replaceingBy);
		
		System.out.println (newString);
		
		String [] splitString = newString.split (" ");
		
		int loopCounter = 0;
		
		for (loopCounter = 0; loopCounter < splitString.length; loopCounter++)
		{
			char [] charArray = splitString [loopCounter].toCharArray ();
			String stringValue = "" + charArray [0];
			String upperCaseValue = stringValue.toUpperCase ();
			
			String subStringValue = splitString [loopCounter].substring (1, charArray.length);
			
			String finishValue = upperCaseValue + subStringValue;
			
			System.out.print (finishValue + " ");	
		}
	}
}