import java.util.Arrays;

public class Sorting
{
	public static void main (String [] args)
	{
		String [] villages = new String [10];
		
		villages [0] = "Chandkuri";
		villages [1] = "Chandkura";
		villages [2] = "Ratuliya";
		villages [3] = "Sabang";
		villages [4] = "Debra";
		villages [5] = "Balichak";
		villages [6] = "Panskura";
		villages [7] = "Barasat";
		villages [8] = "Shyamchack";
		villages [9] = "Kalikadihi";
		
		Arrays.sort (villages);
		
		int loopCounter;
		
		for (loopCounter = villages.length - 1; loopCounter >= 0; loopCounter--)
		{
			System.out.println (villages [loopCounter]);
		}
	}
}