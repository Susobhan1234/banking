/* Given two given numbers x and y where 1<=x<y, find all the numbers which are perfect square between x and y (x and y inclusive). Take input from STDIN and display output to STDOUT without any additional text.
Example:
Input:
x=9 b=25
Output:
9 16 25
*/

public class CheckingPerfectSqure
{
	public static void main (String [] args)
	{
		String firstString = args [0];
		String secondString = args [1];
		
		int firstInt = Integer.parseInt (firstString);
		int secondInt = Integer.parseInt (secondString);
		
		if ((firstInt >= 1) && (firstInt < secondInt))
		{
			int loopCounter1 = 0;
			
			for (loopCounter1 = firstInt; loopCounter1 <= secondInt; loopCounter1++)
			{
				boolean returnValue = perfectSquareCheck (loopCounter1);
				
				if (returnValue == true)
				{
					System.out.print (loopCounter1 + " ");
				}
			}
		}
	}
	
	public static boolean perfectSquareCheck (int number)
	{
		int loopCounter = 0;
		
		for (loopCounter = 1; loopCounter <= number; loopCounter++)
		{
			int perfectSquare = loopCounter * loopCounter;
			
			if (perfectSquare == number)
			{
				return true;
			}
		}
		
		return false;
	}
}

