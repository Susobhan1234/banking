/* 3. Given an array of integers, task is to print the array in the order – smallest number, Largest number, 2nd smallest number, 2nd largest number, 3rd smallest number, 3rd largest number and so on…..
Examples:
Input:
arr[] = [5, 8, 1, 4, 2, 9, 3, 7, 6]
Output:
arr[] = {1, 9, 2, 8, 3, 7, 4, 6, 5}
Input:
arr[] = [1, 2, 3, 4]
Output:
arr[] = {1, 4, 2, 3}
*/

public class Practice
{
	public static void main (String [] args)
	{
		String firstString = args [0];
		
		String [] firstStringSplit = firstString.split (",");
		
		int [] sortingArray = new int [firstStringSplit.length];
		
		int loopCounter = 0, counter = 0, count = 0;
		
		for (loopCounter = 0; loopCounter < firstStringSplit.length; loopCounter++)
		{
			int intNumber = Integer.parseInt (firstStringSplit [loopCounter]);
			
			sortingArray [loopCounter] = intNumber;
		}
		
		sorting (sortingArray);
		
		/* for (count = 0; count < sortingArray.length; count++)
		{
			System.out.println (sortingArray [count]);
		} */
		
		// 1 5 12 25 26 85 98
		
		for (counter = 0; counter < sortingArray.length / 2; counter++)
		{
			System.out.println (sortingArray [counter]);
			System.out.println (sortingArray [sortingArray.length - (counter + 1)]);
		}
		
		if (sortingArray.length % 2 != 0)
		{
			System.out.println (sortingArray [(sortingArray.length / 2)]);
		}
	}
	
	public static void sorting (int [] intArray)
	{
		int loopCounter1 = 0, loopCounter2 = 0;
		
		for (loopCounter1 = 0; loopCounter1 < intArray.length; loopCounter1++)
		{
			for (loopCounter2 = loopCounter1 + 1; loopCounter2 < intArray.length; loopCounter2++)
			{
				if (intArray [loopCounter1] > intArray [loopCounter2])
				{
					int temp = intArray [loopCounter1];
					intArray [loopCounter1] = intArray [loopCounter2];
					intArray [loopCounter2] = temp;
				}
			}
		}
	}
}

