/* Given two arrays, print all elements in sorted order that are not common of these arrays. Take input from STDIN and display output to STDOUT without any additional text.
Example:
Input:
arr1[] = {3, 1, 5, 6, 11}
arr2[] = {5, 3, 7, 8}
Output:
{1, 6, 7, 8, 11} */

public class ArrayUnion
{
	public static void main (String [] args)
	{
		p
	}
}