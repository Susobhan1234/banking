/* You are given a number N. Write a program to print all sequences of consecutive numbers whose sum is equal to N. Take input from STDIN and display output to STDOUT without any additional text.
Example: Input: N=15
Output: 8 7 6 5 4 5 4 3 2 1 */

public class ConsecutiveNumberSum
{
	public static void main (String [] args)
	{
		int N = 20;
		int loopCounter = 0, loopCounter1 = 0, add = 0;
		String numbers = "";
		
		for (loopCounter1 = N - 1; loopCounter1 >= 1; loopCounter1--)  
		{
			numbers = "";
			add = 0;
		 
			for (loopCounter = loopCounter1; loopCounter >= 1; loopCounter--)
			{
				add = add + loopCounter;
				
				numbers = numbers + " " + loopCounter; 
				
				if (add == N)
				{
					System.out.print (numbers.trim ());
				}
			}
		}
	}	
}
