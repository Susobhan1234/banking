/* Given an unsorted array of non-negative integers and a number x, find a continuous sub-array whose sum is exactly x. Take input from STDIN and display output to STDOUT without any additional text.
Example:
Input:
a[]={2, 12, 4, 7, 5 ,6, 10, 3, 18}
x=16
Output:
12 4
4 7 5
10 6 */

public class ContinuousSum
{
	public static void main (String [] args)
	{
		int intArray [] = new int [10];
		
		intArray [0] = 2;
		intArray [1] = 12;
		intArray [2] = 4;
		intArray [3] = 7;
		intArray [4] = 5;
		intArray [5] = 6;
		intArray [6] = 10;
		intArray [7] = 3;
		intArray [8] = 18;
		intArray [9] = 13;
		
		int x = 16, loopCounter = 0, loopCounter2 = 0, sum = 0;
		
		String numbers = "";
		
		for (loopCounter = 0; loopCounter < intArray.length; loopCounter++)
		{
			sum = 0;
			numbers = "";
			
			for (loopCounter2 = loopCounter; loopCounter2 < intArray.length; loopCounter2++)
			{
				sum = sum + intArray [loopCounter2];
				
				numbers = numbers + " " + intArray [loopCounter2];
				
				if (sum == x)
				{
					System.out.println (numbers);
				}
			}
		}
	}
}