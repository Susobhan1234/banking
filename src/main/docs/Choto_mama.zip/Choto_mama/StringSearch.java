public class StringSearch
{
	public static void main (String [] args)
	{
		String searchingString = args [0];
		System.out.println ("The string which you wanted to search is : " + searchingString);
	}
}